namespace Benchmarks.csharp_1.Mistral
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static (int sum, int product) SumProduct(List<int> numbers)
    {
        int sum = numbers.Sum();
        int product = numbers.Aggregate(1, (acc, val) => acc * val);
        return (sum, product);
    }
}
}
