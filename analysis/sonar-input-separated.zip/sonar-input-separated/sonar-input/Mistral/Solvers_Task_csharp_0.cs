namespace Benchmarks.csharp_0.Mistral
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static bool BelowZero(List<int> operations)
    {
        int balance = 0;
        foreach (int op in operations)
        {
            balance += op;
            if (balance < 0)
            {
                return true;
            }
        }
        return false;
    }
}
}
