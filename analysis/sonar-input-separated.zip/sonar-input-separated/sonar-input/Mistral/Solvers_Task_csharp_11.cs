namespace Benchmarks.csharp_11.Mistral
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static int PrimeFib(int n)
    {
        int count = 0;
        int a = 1, b = 1, c = 0;
        while (count < n)
        {
            c = a + b;
            a = b;
            b = c;
            if (IsPrime(c))
            {
                count++;
            }
        }
        return c;
    }

    private static bool IsPrime(int num)
    {
        if (num <= 1) return false;
        if (num == 2) return true;
        if (num % 2 == 0) return false;
        for (int i = 3; i * i <= num; i += 2)
        {
            if (num % i == 0)
                return false;
        }
        return true;
    }
}
}
