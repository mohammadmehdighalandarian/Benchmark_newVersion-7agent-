namespace Benchmarks.csharp_21.Claude
{
using System;

public class Solver
{
    public static int Fib(int n)
    {
        if (n <= 1) return n == 1 ? 1 : 0;
        int a = 1, b = 1;
        for (int i = 2; i < n; i++) { int c = a + b; a = b; b = c; }
        return b;
    }
}
}
