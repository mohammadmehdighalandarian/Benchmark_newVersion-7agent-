namespace Benchmarks.csharp_4.Claude
{
public class Solver
{
    public static int GreatestCommonDivisor(int a, int b)
    {
        while (b != 0) { int t = b; b = a % b; a = t; }
        return a;
    }
}
}
