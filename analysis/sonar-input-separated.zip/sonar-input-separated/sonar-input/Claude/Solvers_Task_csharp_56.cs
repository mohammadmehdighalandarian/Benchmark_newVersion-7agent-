namespace Benchmarks.csharp_56.Claude
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static string Intersection(List<int> interval1, List<int> interval2)
    {
        int start = Math.Max(interval1[0], interval2[0]);
        int end = Math.Min(interval1[1], interval2[1]);
        if (start > end) return "NO";
        int len = end - start;
        if (len < 2) return "NO";
        for (int i = 2; i <= Math.Sqrt(len); i++)
            if (len % i == 0) return "NO";
        return "YES";
    }
}
}
