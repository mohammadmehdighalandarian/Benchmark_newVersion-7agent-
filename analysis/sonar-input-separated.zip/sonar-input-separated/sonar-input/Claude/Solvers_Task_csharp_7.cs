namespace Benchmarks.csharp_7.Claude
{
using System;
public class Solver {
    public static string FlipCase(string string0) {
        var result = new char[string0.Length];
        for (int i = 0; i < string0.Length; i++)
            result[i] = char.IsUpper(string0[i]) ? char.ToLower(string0[i]) : char.ToUpper(string0[i]);
        return new string(result);
    }
}
}
