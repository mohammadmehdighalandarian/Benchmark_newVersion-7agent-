namespace Benchmarks.csharp_12.Claude
{
using System.Collections.Generic;

public class Solver
{
    public static bool TriplesSumToZero(List<int> l)
    {
        for (int i = 0; i < l.Count - 2; i++)
            for (int j = i + 1; j < l.Count - 1; j++)
                for (int k = j + 1; k < l.Count; k++)
                    if (l[i] + l[j] + l[k] == 0) return true;
        return false;
    }
}
}
