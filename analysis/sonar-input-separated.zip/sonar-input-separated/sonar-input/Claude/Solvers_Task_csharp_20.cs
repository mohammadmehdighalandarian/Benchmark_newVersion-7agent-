namespace Benchmarks.csharp_20.Claude
{
    using System.Linq;

    public class Solver
    {
        public static bool SameChars(string s0, string s1)
        {
            var set0 = new System.Collections.Generic.HashSet<char>(s0);
            var set1 = new System.Collections.Generic.HashSet<char>(s1);
            return set0.SetEquals(set1);
        }
    }
}
