namespace Benchmarks.csharp_75.Claude
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static string IntToMiniRoman(int number)
    {
        var vals = new[] {1000,900,500,400,100,90,50,40,10,9,5,4,1};
        var syms = new[] {"m","cm","d","cd","c","xc","l","xl","x","ix","v","iv","i"};
        var result = "";
        for(int i=0;i<vals.Length;i++)
            while(number>=vals[i]){result+=syms[i];number-=vals[i];}
        return result;
    }
}
}
