namespace Benchmarks.csharp_52.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int MaxFill(List<List<int>> grid, int capacity)
    {
        return grid.Sum(row => (int)Math.Ceiling((double)row.Sum() / capacity));
    }
}
}
