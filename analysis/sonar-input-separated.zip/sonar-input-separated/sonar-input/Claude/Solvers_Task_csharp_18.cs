namespace Benchmarks.csharp_18.Claude
{
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool BelowThreshold(List<int> l, int t) => l.All(x => x < t);
}
}
