namespace Benchmarks.csharp_31.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool IsMultiplyPrime(int a)
    {
        bool IsPrime(int n) {
            if (n < 2) return false;
            for (int i = 2; i * i <= n; i++)
                if (n % i == 0) return false;
            return true;
        }
        
        for (int i = 2; i < a; i++)
            for (int j = 2; j < a; j++)
                for (int k = 2; k < a; k++)
                    if (IsPrime(i) && IsPrime(j) && IsPrime(k) && i*j*k == a)
                        return true;
        return false;
    }
}
}
