namespace Benchmarks.csharp_45.Claude
{
using System;

public class Solver
{
    public static int ChooseNum(int x, int y)
    {
        if (y < x) return -1;
        return y % 2 == 0 ? y : (y - 1 >= x ? y - 1 : -1);
    }
}
}
