namespace Benchmarks.csharp_77.Claude
{
using System;
using System.Linq;

public class Solver
{
    public static string Solve(string s)
    {
        if (!s.Any(char.IsLetter))
            return new string(s.Reverse().ToArray());
        return new string(s.Select(c => char.IsLetter(c) ? (char.IsUpper(c) ? char.ToLower(c) : char.ToUpper(c)) : c).ToArray());
    }
}
}
