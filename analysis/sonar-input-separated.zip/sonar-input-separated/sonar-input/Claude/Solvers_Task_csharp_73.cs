namespace Benchmarks.csharp_73.Claude
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static string StrongestExtension(string class_name, List<string> extensions)
        {
            string best = extensions[0];
            int bestStrength = int.MinValue;
            foreach (var ext in extensions)
            {
                int cap = ext.Count(char.IsUpper);
                int sm = ext.Count(char.IsLower);
                int strength = cap - sm;
                if (strength > bestStrength)
                {
                    bestStrength = strength;
                    best = ext;
                }
            }

            return $"{class_name}.{best}";
        }
    }
}
