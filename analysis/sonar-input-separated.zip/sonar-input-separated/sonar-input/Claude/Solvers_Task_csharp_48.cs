namespace Benchmarks.csharp_48.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> EvenOddPalindrome(int n)
    {
        int even = 0, odd = 0;
        for (int i = 1; i <= n; i++)
        {
            var s = i.ToString();
            if (s == new string(s.Reverse().ToArray()))
            {
                if (i % 2 == 0) even++;
                else odd++;
            }
        }
        return new List<int> { even, odd };
    }
}
}
