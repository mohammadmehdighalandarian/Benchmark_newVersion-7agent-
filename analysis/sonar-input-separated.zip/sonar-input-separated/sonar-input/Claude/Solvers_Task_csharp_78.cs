namespace Benchmarks.csharp_78.Claude
{
using System;
using System.Security.Cryptography;
using System.Text;

public class Solver
{
    public static object StringToMd5(string text)
    {
        if (string.IsNullOrEmpty(text)) return null;
        using var md5 = MD5.Create();
        var hash = md5.ComputeHash(Encoding.UTF8.GetBytes(text));
        return BitConverter.ToString(hash).Replace("-", "").ToLower();
    }
}
}
