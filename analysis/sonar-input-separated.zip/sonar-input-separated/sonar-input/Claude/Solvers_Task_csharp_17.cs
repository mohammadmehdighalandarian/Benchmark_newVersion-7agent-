namespace Benchmarks.csharp_17.Claude
{
using System;
using System.Text.RegularExpressions;

public class Solver
{
    public static string RemoveVowels(string text)
    {
        return Regex.Replace(text, "[aeiouAEIOU]", "");
    }
}
}
