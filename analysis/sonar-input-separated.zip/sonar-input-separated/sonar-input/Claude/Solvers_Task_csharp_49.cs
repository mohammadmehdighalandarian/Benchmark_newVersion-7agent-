namespace Benchmarks.csharp_49.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool MoveOneBall(List<int> arr)
    {
        if (arr.Count == 0) return true;
        int drops = 0;
        for (int i = 0; i < arr.Count; i++)
            if (arr[i] > arr[(i + 1) % arr.Count]) drops++;
        return drops <= 1;
    }
}
}
