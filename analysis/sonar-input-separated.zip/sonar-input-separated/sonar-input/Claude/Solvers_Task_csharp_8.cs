namespace Benchmarks.csharp_8.Claude
{
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> GetPositive(List<int> l) => l.Where(x => x > 0).ToList();
}
}
