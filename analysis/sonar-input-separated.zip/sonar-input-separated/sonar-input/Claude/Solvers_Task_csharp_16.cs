namespace Benchmarks.csharp_16.Claude
{
using System;

public class Solver
{
    public static bool IsPalindrome(string text)
    {
        if (string.IsNullOrEmpty(text)) return true;
        var rev = new string(text.ToCharArray().Reverse().ToArray());
        return text == rev;
    }
}
}
