namespace Benchmarks.csharp_41.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool CheckDictCase(Dictionary<object, string> dict)
    {
        if (dict.Count == 0) return false;
        var keys = dict.Keys.ToList();
        if (keys.Any(k => !(k is string))) return false;
        var strKeys = keys.Cast<string>().ToList();
        return strKeys.All(k => k == k.ToLower()) || strKeys.All(k => k == k.ToUpper());
    }
}
}
