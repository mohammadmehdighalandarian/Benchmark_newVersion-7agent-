namespace Benchmarks.csharp_2.Claude
{
using System;
using System.Linq;

public class Solver
{
    public static string StringXor(string a, string b)
    {
        return new string(a.Zip(b, (x, y) => x == y ? '0' : '1').ToArray());
    }
}
}
