namespace Benchmarks.csharp_64.Claude
{
using System;

public class Solver
{
    public static int SpecialFactorial(int n)
    {
        int result = 1;
        int fact = 1;
        for (int i = 1; i <= n; i++)
        {
            fact *= i;
            result *= fact;
        }
        return result;
    }
}
}
