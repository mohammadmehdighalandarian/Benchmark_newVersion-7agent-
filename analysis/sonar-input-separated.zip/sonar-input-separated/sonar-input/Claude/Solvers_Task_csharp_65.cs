namespace Benchmarks.csharp_65.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static string WordsInSentence(string sentence)
    {
        bool IsPrime(int n) {
            if (n < 2) return false;
            for (int i = 2; i * i <= n; i++)
                if (n % i == 0) return false;
            return true;
        }
        return string.Join(" ", sentence.Split(' ').Where(w => IsPrime(w.Length)));
    }
}
}
