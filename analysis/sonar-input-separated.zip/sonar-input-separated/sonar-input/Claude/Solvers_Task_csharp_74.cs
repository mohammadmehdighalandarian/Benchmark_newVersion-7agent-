namespace Benchmarks.csharp_74.Claude
{
using System;

public class Solver
{
    public static bool CycpatternCheck(string a, string b)
    {
        string doubled = b + b;
        for (int i = 0; i < b.Length; i++)
        {
            string rotation = doubled.Substring(i, b.Length);
            if (a.Contains(rotation)) return true;
        }
        return false;
    }
}
}
