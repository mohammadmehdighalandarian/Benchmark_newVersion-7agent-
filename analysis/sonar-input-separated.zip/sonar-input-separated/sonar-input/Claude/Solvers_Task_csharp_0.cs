namespace Benchmarks.csharp_0.Claude
{
using System.Collections.Generic;

public class Solver
{
    public static bool BelowZero(List<int> operations)
    {
        int balance = 0;
        foreach (var op in operations)
        {
            balance += op;
            if (balance < 0) return true;
        }
        return false;
    }
}
}
