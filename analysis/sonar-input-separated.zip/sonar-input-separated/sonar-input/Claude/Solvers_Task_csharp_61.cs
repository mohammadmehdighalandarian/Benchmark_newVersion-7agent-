namespace Benchmarks.csharp_61.Claude
{
using System;

public class Solver
{
    public static bool CheckIfLastCharIsALetter(string txt)
    {
        if (string.IsNullOrEmpty(txt)) return false;
        char last = txt[txt.Length - 1];
        if (!char.IsLetter(last)) return false;
        if (txt.Length == 1) return true;
        return txt[txt.Length - 2] == ' ';
    }
}
}
