namespace Benchmarks.csharp_39.Claude
{
using System;
using System.Text.RegularExpressions;

public class Solver
{
    public static int IsBored(string S)
    {
        var sentences = Regex.Split(S.Trim(), @"[.?!]");
        int count = 0;
        foreach (var s in sentences)
            if (Regex.IsMatch(s.Trim(), @"^I\b"))
                count++;
        return count;
    }
}
}
