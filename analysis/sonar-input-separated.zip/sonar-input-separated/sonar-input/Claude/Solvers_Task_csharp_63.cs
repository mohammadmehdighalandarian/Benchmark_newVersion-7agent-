namespace Benchmarks.csharp_63.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<object> LargestSmallestIntegers(List<int> lst)
    {
        var negatives = lst.Where(x => x < 0).ToList();
        var positives = lst.Where(x => x > 0).ToList();
        object a = negatives.Any() ? (object)negatives.Max() : null;
        object b = positives.Any() ? (object)positives.Min() : null;
        return new List<object> { a, b };
    }
}
}
