namespace Benchmarks.csharp_37.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<List<int>> GetRow(List<List<int>> lst, int x)
    {
        var result = new List<List<int>>();
        for (int r = 0; r < lst.Count; r++)
        {
            var cols = lst[r].Select((val, col) => new { val, col })
                             .Where(a => a.val == x)
                             .OrderByDescending(a => a.col)
                             .Select(a => new List<int> { r, a.col });
            result.AddRange(cols);
        }
        return result;
    }
}
}
