namespace Benchmarks.csharp_40.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int Skjkasdkd(List<int> lst)
    {
        bool IsPrime(int n)
        {
            if (n < 2) return false;
            for (int i = 2; i * i <= n; i++)
                if (n % i == 0) return false;
            return true;
        }
        
        int largest = lst.Where(IsPrime).DefaultIfEmpty(0).Max();
        return largest.ToString().Sum(c => c - '0');
    }
}
}
