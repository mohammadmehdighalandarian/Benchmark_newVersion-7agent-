namespace Benchmarks.csharp_46.Claude
{
using System;

public class Solver
{
    public static object RoundedAvg(int n, int m)
    {
        if (n > m) return -1;
        int avg = (int)Math.Round((double)(n + m) / 2);
        return "0b" + Convert.ToString(avg, 2);
    }
}
}
