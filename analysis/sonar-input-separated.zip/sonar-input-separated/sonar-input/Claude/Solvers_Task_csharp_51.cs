namespace Benchmarks.csharp_51.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<object> ReverseDelete(string s, string c)
    {
        var result = new string(s.Where(ch => !c.Contains(ch)).ToArray());
        bool isPalindrome = result == new string(result.Reverse().ToArray());
        return new List<object> { result, isPalindrome };
    }
}
}
