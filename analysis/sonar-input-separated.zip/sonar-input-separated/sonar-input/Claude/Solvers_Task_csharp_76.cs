namespace Benchmarks.csharp_76.Claude
{
using System;

public class Solver
{
    public static bool RightAngleTriangle(int a, int b, int c)
    {
        return a*a + b*b == c*c || a*a + c*c == b*b || b*b + c*c == a*a;
    }
}
}
