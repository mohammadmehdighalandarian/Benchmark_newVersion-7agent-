namespace Benchmarks.csharp_13.Claude
{
using System.Collections.Generic;

public class Solver
{
    public static bool PairsSumToZero(List<int> l)
    {
        var seen = new HashSet<int>();
        foreach (var n in l)
        {
            if (seen.Contains(-n)) return true;
            seen.Add(n);
        }
        return false;
    }
}
}
