namespace Benchmarks.csharp_59.Claude
{
using System;

public class Solver
{
    public static bool IsNested(string string0)
    {
        int depth = 0, maxDepth = 0;
        foreach (char c in string0)
        {
            if (c == '[') { depth++; if (depth > maxDepth) maxDepth = depth; }
            else { depth = Math.Max(0, depth - 1); }
        }
        return maxDepth >= 2;
    }
}
}
