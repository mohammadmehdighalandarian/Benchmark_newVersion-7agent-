namespace Benchmarks.csharp_3.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static object Longest(List<string> strings)
    {
        if (strings == null || strings.Count == 0) return null;
        return strings.OrderByDescending(s => s.Length).First();
    }
}
}
