namespace Benchmarks.csharp_5.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static string SortNumbers(string numbers)
    {
        var order = new[] { "zero","one","two","three","four","five","six","seven","eight","nine" };
        if (string.IsNullOrWhiteSpace(numbers)) return "";
        return string.Join(" ", numbers.Split(' ').OrderBy(n => Array.IndexOf(order, n)));
    }
}
}
