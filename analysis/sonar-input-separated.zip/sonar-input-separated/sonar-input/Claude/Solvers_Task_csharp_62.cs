namespace Benchmarks.csharp_62.Claude
{
using System.Collections.Generic;

public class Solver
{
    public static int CanArrange(List<int> arr)
    {
        int result = -1;
        for (int i = 1; i < arr.Count; i++)
            if (arr[i] < arr[i-1]) result = i;
        return result;
    }
}
}
