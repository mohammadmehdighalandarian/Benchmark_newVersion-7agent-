namespace Benchmarks.csharp_47.Claude
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static List<int> F(int n)
    {
        var result = new List<int>();
        for (int i = 1; i <= n; i++)
        {
            if (i % 2 == 0)
            {
                int fact = 1;
                for (int j = 1; j <= i; j++) fact *= j;
                result.Add(fact);
            }
            else
            {
                result.Add(i * (i + 1) / 2);
            }
        }
        return result;
    }
}
}
