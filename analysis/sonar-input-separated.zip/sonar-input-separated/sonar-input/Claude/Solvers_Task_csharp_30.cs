namespace Benchmarks.csharp_30.Claude
{
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static bool WillItFly(List<int> q, int w)
        {
            var reversed = q.AsEnumerable().Reverse().ToList();
            bool isPalindrome = q.SequenceEqual(reversed);
            return isPalindrome && q.Sum() <= w;
        }
    }
}
