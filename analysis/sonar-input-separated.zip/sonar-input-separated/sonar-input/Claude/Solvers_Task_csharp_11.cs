namespace Benchmarks.csharp_11.Claude
{
using System;

public class Solver
{
    public static int PrimeFib(int n)
    {
        bool IsPrime(int num)
        {
            if (num < 2) return false;
            for (int i = 2; i * i <= num; i++)
                if (num % i == 0) return false;
            return true;
        }
        
        int count = 0, a = 1, b = 1;
        while (true)
        {
            int c = a + b;
            a = b;
            b = c;
            if (IsPrime(a) && ++count == n) return a;
        }
    }
}
}
