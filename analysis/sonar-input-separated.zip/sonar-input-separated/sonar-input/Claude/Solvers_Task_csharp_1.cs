namespace Benchmarks.csharp_1.Claude
{
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> SumProduct(List<int> numbers)
    {
        int sum = numbers.Sum();
        int product = numbers.Count == 0 ? 1 : numbers.Aggregate(1, (a, b) => a * b);
        return new List<int> { sum, product };
    }
}
}
