namespace Benchmarks.csharp_38.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static object NextSmallest(List<int> lst)
    {
        var distinct = lst.Distinct().OrderBy(x => x).ToList();
        return distinct.Count >= 2 ? (object)distinct[1] : null;
    }
}
}
