namespace Benchmarks.csharp_50.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static string Exchange(List<int> lst1, List<int> lst2)
    {
        int oddsInLst1 = lst1.Count(x => x % 2 != 0);
        int evensInLst2 = lst2.Count(x => x % 2 == 0);
        return evensInLst2 >= oddsInLst1 ? "YES" : "NO";
    }
}
}
