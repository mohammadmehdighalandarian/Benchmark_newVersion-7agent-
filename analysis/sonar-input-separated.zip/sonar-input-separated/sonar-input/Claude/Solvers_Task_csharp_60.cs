namespace Benchmarks.csharp_60.Claude
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static int SumSquares(List<object> lst)
        {
            return lst.Sum(x =>
            {
                double val = Convert.ToDouble(x);
                int ceiled = (int)Math.Ceiling(val);
                return ceiled * ceiled;
            });
        }
    }
}
