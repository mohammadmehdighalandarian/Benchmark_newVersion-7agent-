namespace Benchmarks.csharp_71.Claude
{
using System;

public class Solver
{
    public static int XOrY(int n, int x, int y)
    {
        if (n < 2) return y;
        for (int i = 2; i <= Math.Sqrt(n); i++)
            if (n % i == 0) return y;
        return x;
    }
}
}
