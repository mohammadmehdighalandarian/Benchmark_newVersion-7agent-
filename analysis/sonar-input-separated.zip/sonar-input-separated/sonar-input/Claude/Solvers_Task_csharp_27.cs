namespace Benchmarks.csharp_27.Claude
{
    using System;
    using System.Linq;

    public class Solver
    {
        public static int VowelsCount(string s)
        {
            string lower = s.ToLower();
            int count = lower.Count(c => "aeiou".Contains(c));
            if (lower.Length > 0 && lower[lower.Length - 1] == 'y') count++;
            return count;
        }
    }
}
