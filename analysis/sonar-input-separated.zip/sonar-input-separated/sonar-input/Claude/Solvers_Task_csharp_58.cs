namespace Benchmarks.csharp_58.Claude
{
using System;
using System.Linq;

public class Solver
{
    public static int Digits(int n)
    {
        var odd = n.ToString().Select(c => c - '0').Where(d => d % 2 != 0).ToList();
        return odd.Count == 0 ? 0 : odd.Aggregate(1, (a, b) => a * b);
    }
}
}
