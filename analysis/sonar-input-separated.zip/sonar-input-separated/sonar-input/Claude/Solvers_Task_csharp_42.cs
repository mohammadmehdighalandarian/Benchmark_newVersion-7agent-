namespace Benchmarks.csharp_42.Claude
{
using System;

public class Solver
{
    public static int ClosestInteger(string value)
    {
        decimal d = decimal.Parse(value);
        return (int)Math.Round(d, MidpointRounding.AwayFromZero);
    }
}
}
