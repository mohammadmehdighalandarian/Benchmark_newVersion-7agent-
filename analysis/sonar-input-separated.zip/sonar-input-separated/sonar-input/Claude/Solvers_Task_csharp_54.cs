namespace Benchmarks.csharp_54.Claude
{
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> Maximum(List<int> arr, int k)
    {
        return arr.OrderBy(x => x).TakeLast(k).ToList();
    }
}
}
