namespace Benchmarks.csharp_24.Claude
{
public class Solver
{
    public static int SumToN(int n) => n * (n + 1) / 2;
}
}
