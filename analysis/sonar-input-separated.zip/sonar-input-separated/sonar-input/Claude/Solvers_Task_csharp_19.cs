namespace Benchmarks.csharp_19.Claude
{
using System;

public class Solver
{
    public static int Add(int x, int y) => x + y;
}
}
