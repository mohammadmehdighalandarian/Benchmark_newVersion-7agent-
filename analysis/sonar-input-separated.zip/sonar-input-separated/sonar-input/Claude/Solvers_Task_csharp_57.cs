namespace Benchmarks.csharp_57.Claude
{
    using System;
    using System.Collections.Generic;

    public class Solver
    {
        public static List<object> Tri(int n)
        {
            var memo = new Dictionary<int, double>();

            double Compute(int k)
            {
                if (memo.ContainsKey(k)) return memo[k];
                double result;
                if (k == 1) result = 3;
                else if (k % 2 == 0) result = 1 + k / 2.0;
                else result = Compute(k - 1) + Compute(k - 2) + Compute(k + 1);
                memo[k] = result;
                return result;
            }

            var list = new List<object>();
            for (int i = 0; i <= n; i++)
            {
                double val = Compute(i);
                if (val == Math.Floor(val))
                    list.Add((int)val);
                else
                    list.Add(val);
            }

            return list;
        }
    }
}
