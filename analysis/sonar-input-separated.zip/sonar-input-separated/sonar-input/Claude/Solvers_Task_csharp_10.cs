namespace Benchmarks.csharp_10.Claude
{
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> Unique(List<int> l) => l.Distinct().OrderBy(x => x).ToList();
}
}
