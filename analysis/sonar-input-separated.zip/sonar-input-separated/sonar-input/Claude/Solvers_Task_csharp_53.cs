namespace Benchmarks.csharp_53.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<string> SelectWords(string s, int n)
    {
        if (string.IsNullOrEmpty(s)) return new List<string>();
        string vowels = "aeiouAEIOU";
        return s.Split(' ')
            .Where(w => w.Count(c => char.IsLetter(c) && !vowels.Contains(c)) == n)
            .ToList();
    }
}
}
