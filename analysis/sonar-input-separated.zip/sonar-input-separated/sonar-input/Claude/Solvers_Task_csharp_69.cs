namespace Benchmarks.csharp_69.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int GetMaxTriples(int n)
    {
        var a = Enumerable.Range(1, n).Select(i => i * i - i + 1).ToArray();
        int count = 0;
        for (int i = 0; i < n; i++)
            for (int j = i + 1; j < n; j++)
                for (int k = j + 1; k < n; k++)
                    if ((a[i] + a[j] + a[k]) % 3 == 0) count++;
        return count;
    }
}
}
