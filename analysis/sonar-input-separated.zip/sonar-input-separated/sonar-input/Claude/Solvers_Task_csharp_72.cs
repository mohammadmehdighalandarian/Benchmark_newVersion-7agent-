namespace Benchmarks.csharp_72.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int DoubleTheDifference(List<object> lst)
    {
        int sum = 0;
        foreach (var item in lst)
        {
            if (item is int i && i > 0 && i % 2 != 0) sum += i * i;
            else if (item is double d && d == Math.Floor(d) && d > 0 && (long)d % 2 != 0) sum += (int)(d * d);
        }
        return sum;
    }
}
}
