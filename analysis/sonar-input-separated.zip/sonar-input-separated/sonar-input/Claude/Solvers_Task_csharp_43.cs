namespace Benchmarks.csharp_43.Claude
{
    using System.Collections.Generic;

    public class Solver
    {
        public static List<int> MakeAPile(int n)
        {
            var result = new List<int>();
            for (int i = 0; i < n; i++)
                result.Add(n + i * 2);
            return result;
        }
    }
}
