namespace Benchmarks.csharp_35.Claude
{
using System;

public class Solver
{
    public static bool PrimeLength(string string0)
    {
        int n = string0.Length;
        if (n < 2) return false;
        for (int i = 2; i * i <= n; i++)
            if (n % i == 0) return false;
        return true;
    }
}
}
