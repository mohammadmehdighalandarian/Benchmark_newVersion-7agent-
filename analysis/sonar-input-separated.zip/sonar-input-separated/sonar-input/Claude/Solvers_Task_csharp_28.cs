namespace Benchmarks.csharp_28.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int Search(List<int> lst)
    {
        var freq = lst.GroupBy(x => x).ToDictionary(g => g.Key, g => g.Count());
        return freq.Where(kv => kv.Value >= kv.Key).Select(kv => kv.Key).DefaultIfEmpty(-1).Max();
    }
}
}
