namespace Benchmarks.csharp_68.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int SpecialFilter(List<int> nums)
    {
        int[] odd = {1,3,5,7,9};
        return nums.Count(n => {
            if (n <= 10) return false;
            string s = n.ToString();
            return odd.Contains(s[0]-'0') && odd.Contains(s[s.Length-1]-'0');
        });
    }
}
}
