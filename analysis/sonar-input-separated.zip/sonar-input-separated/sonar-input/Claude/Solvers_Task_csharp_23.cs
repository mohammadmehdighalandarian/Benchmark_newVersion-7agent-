namespace Benchmarks.csharp_23.Claude
{
    using System;

    public class Solver
    {
        public static int LargestPrimeFactor(int n)
        {
            int largest = 1;
            for (int i = 2; (long)i * i <= n; i++)
            {
                while (n % i == 0)
                {
                    largest = i;
                    n /= i;
                }
            }

            if (n > 1) largest = n;
            return largest;
        }
    }
}
