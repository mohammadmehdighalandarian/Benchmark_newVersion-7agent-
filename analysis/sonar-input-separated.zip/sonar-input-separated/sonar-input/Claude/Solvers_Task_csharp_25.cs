namespace Benchmarks.csharp_25.Claude
{
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static List<int> Derivative(List<int> xs)
        {
            return xs.Skip(1).Select((c, i) => c * (i + 1)).ToList();
        }
    }
}
