namespace Benchmarks.csharp_44.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static List<string> WordsString(string s)
    {
        return Regex.Split(s, @"[\s,]+").Where(w => w.Length > 0).ToList();
    }
}
}
