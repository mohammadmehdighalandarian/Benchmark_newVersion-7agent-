namespace Benchmarks.csharp_66.Claude
{
using System;

public class Solver
{
    public static bool Simplify(string x, string n)
    {
        var xp = x.Split('/');
        var np = n.Split('/');
        long num = long.Parse(xp[0]) * long.Parse(np[0]);
        long den = long.Parse(xp[1]) * long.Parse(np[1]);
        return num % den == 0;
    }
}
}
