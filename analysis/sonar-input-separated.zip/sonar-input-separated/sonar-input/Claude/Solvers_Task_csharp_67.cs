namespace Benchmarks.csharp_67.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> OrderByPoints(List<int> nums)
    {
        return nums.Select((n, i) => (n, i))
            .OrderBy(x => {
                var s = x.n.ToString();
                int sign = 1;
                if (s.StartsWith("-")) { sign = -1; s = s.Substring(1); }
                return sign * s[0] - '0' + s.Skip(1).Sum(c => c - '0');
            })
            .ThenBy(x => x.i)
            .Select(x => x.n)
            .ToList();
    }
}
}
