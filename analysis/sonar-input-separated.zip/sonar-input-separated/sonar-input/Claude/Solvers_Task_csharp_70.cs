namespace Benchmarks.csharp_70.Claude
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<string> Bf(string planet1, string planet2)
    {
        var planets = new List<string> { "Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune" };
        int i1 = planets.IndexOf(planet1);
        int i2 = planets.IndexOf(planet2);
        if (i1 == -1 || i2 == -1) return new List<string>();
        int lo = Math.Min(i1, i2);
        int hi = Math.Max(i1, i2);
        return planets.Skip(lo + 1).Take(hi - lo - 1).ToList();
    }
}
}
