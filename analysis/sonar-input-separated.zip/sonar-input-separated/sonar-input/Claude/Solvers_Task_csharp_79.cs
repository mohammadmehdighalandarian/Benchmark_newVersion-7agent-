namespace Benchmarks.csharp_79.Claude
{
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> GenerateIntegers(int a, int b)
    {
        int lo = System.Math.Min(a, b), hi = System.Math.Max(a, b);
        return Enumerable.Range(lo, hi - lo + 1).Where(x => x <= 9 && x % 2 == 0).ToList();
    }
}
}
