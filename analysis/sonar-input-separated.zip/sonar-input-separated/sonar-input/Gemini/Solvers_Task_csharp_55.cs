namespace Benchmarks.csharp_55.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Given a non-empty array of integers arr and an integer k, return
    /// the sum of the elements with at most two digits from the first k elements of arr.
    /// </summary>
    public static int AddElements(List<int> arr, int k)
    {
        int sum = 0;
        for (int i = 0; i < k; i++)
        {
            // A number has at most two digits if it is in the range [-99, 99]
            if (arr[i] > -100 && arr[i] < 100)
            {
                sum += arr[i];
            }
        }
        return sum;
    }
}
}
