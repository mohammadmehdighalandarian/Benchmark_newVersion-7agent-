namespace Benchmarks.csharp_34.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Converts a list of numerical GPAs into letter grades based on a specific grading scale.
    /// </summary>
    public static List<string> NumericalLetterGrade(List<object> grades)
    {
        List<string> letterGrades = new List<string>();

        foreach (var gradeObj in grades)
        {
            double g = Convert.ToDouble(gradeObj);

            if (g >= 4.0)
            {
                letterGrades.Add("A+");
            }
            else if (g > 3.7)
            {
                letterGrades.Add("A");
            }
            else if (g > 3.3)
            {
                letterGrades.Add("A-");
            }
            else if (g > 3.0)
            {
                letterGrades.Add("B+");
            }
            else if (g > 2.7)
            {
                letterGrades.Add("B");
            }
            else if (g > 2.3)
            {
                letterGrades.Add("B-");
            }
            else if (g > 2.0)
            {
                letterGrades.Add("C+");
            }
            else if (g > 1.7)
            {
                letterGrades.Add("C");
            }
            else if (g > 1.3)
            {
                letterGrades.Add("C-");
            }
            else if (g > 1.0)
            {
                letterGrades.Add("D+");
            }
            else if (g > 0.7)
            {
                letterGrades.Add("D");
            }
            else if (g > 0.0)
            {
                letterGrades.Add("D-");
            }
            else
            {
                letterGrades.Add("E");
            }
        }

        return letterGrades;
    }
}
}
