namespace Benchmarks.csharp_58.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Given a positive integer n, return the product of the odd Digits.
    /// Return 0 if all Digits are even.
    /// </summary>
    public static int Digits(int n)
    {
        int product = 1;
        bool hasOdd = false;

        // Convert to string to handle digits or use mathematical approach
        // Mathematical approach is generally more efficient
        while (n > 0)
        {
            int digit = n % 10;
            if (digit % 2 != 0)
            {
                product *= digit;
                hasOdd = true;
            }
            n /= 10;
        }

        return hasOdd ? product : 0;
    }
}
}
