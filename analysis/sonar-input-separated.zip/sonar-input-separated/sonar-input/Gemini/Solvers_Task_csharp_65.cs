namespace Benchmarks.csharp_65.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Returns a string containing words from the original sentence whose lengths are prime numbers.
    /// </summary>
    public static string WordsInSentence(string sentence)
    {
        if (string.IsNullOrEmpty(sentence))
        {
            return string.Empty;
        }

        // Split by space, keeping the original order.
        string[] words = sentence.Split(' ');
        
        // Filter words where the length of the word is a prime number.
        var primeLengthWords = words.Where(word => IsPrime(word.Length));
        
        // Join the result back with a single space.
        return string.Join(" ", primeLengthWords);
    }

    /// <summary>
    /// Helper method to determine if a number is prime.
    /// </summary>
    private static bool IsPrime(int n)
    {
        if (n < 2) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;
        
        int boundary = (int)Math.Floor(Math.Sqrt(n));
        
        for (int i = 3; i <= boundary; i += 2)
        {
            if (n % i == 0) return false;
        }
        
        return true;
    }
}
}
