namespace Benchmarks.csharp_17.Gemini
{
using System;
using System.Text.RegularExpressions;

public class Solver
{
    public static string RemoveVowels(string text)
    {
        if (text == null)
        {
            return text;
        }
        return Regex.Replace(text, "[aeiouAEIOU]", "");
    }
}
}
