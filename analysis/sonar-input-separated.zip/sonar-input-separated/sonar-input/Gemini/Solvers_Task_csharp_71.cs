namespace Benchmarks.csharp_71.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// A simple program which should return the value of x if n is 
    /// a prime number and should return the value of y otherwise.
    /// </summary>
    public static int XOrY(int n, int x, int y)
    {
        if (IsPrime(n))
        {
            return x;
        }
        return y;
    }

    private static bool IsPrime(int n)
    {
        if (n <= 1) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;

        var boundary = (int)Math.Floor(Math.Sqrt(n));

        for (int i = 3; i <= boundary; i += 2)
        {
            if (n % i == 0) return false;
        }

        return true;
    }
}
}
