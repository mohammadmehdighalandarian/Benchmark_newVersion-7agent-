namespace Benchmarks.csharp_16.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Checks if given string is a palindrome
    /// </summary>
    public static bool IsPalindrome(string text)
    {
        if (text == null)
        {
            return false;
        }

        int left = 0;
        int right = text.Length - 1;

        while (left < right)
        {
            if (text[left] != text[right])
            {
                return false;
            }
            left++;
            right--;
        }

        return true;
    }
}
}
