namespace Benchmarks.csharp_77.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// If s contains letters, reverse the case of each letter.
    /// If s contains no letters, reverse the entire string.
    /// </summary>
    public static string Solve(string s)
    {
        if (string.IsNullOrEmpty(s))
        {
            return s;
        }

        bool hasLetters = s.Any(char.IsLetter);

        if (hasLetters)
        {
            char[] result = new char[s.Length];
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (char.IsLower(c))
                {
                    result[i] = char.ToUpper(c);
                }
                else if (char.IsUpper(c))
                {
                    result[i] = char.ToLower(c);
                }
                else
                {
                    result[i] = c;
                }
            }
            return new string(result);
        }
        else
        {
            char[] charArray = s.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }
    }
}
}
