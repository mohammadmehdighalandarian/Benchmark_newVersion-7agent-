namespace Benchmarks.csharp_51.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
/// <summary>
/// Deletes all characters in s that are equal to any character in c
/// then checks if the result string is a palindrome.
/// Returns a list containing the result string and the palindrome check result.
/// </summary>
public static List<object> ReverseDelete(string s, string c)
{
HashSet<char> charsToRemove = new HashSet<char>(c);


    // Filter out characters found in c
    string resultStr = new string(s.Where(ch => !charsToRemove.Contains(ch)).ToArray());
    
    // Check for palindrome
    bool isPalindrome = true;
    for (int i = 0; i < resultStr.Length / 2; i++)
    {
        if (resultStr[i] != resultStr[resultStr.Length - 1 - i])
        {
            isPalindrome = false;
            break;
        }
    }
    
    return new List<object> { resultStr, isPalindrome };
}



}
}
