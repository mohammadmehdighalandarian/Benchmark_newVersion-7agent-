namespace Benchmarks.csharp_49.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Determines if it is possible to get an array sorted in non-decreasing order 
    /// by performing right shift operations.
    /// </summary>
    public static bool MoveOneBall(List<int> arr)
    {
        // If the array is empty or has only one element, it is considered sorted.
        if (arr == null || arr.Count <= 1)
        {
            return true;
        }

        int n = arr.Count;
        int decreaseCount = 0;

        // A cyclically sorted array with unique elements can have at most one 
        // point where the current element is greater than the next element 
        // (including the wrap-around from the last element to the first).
        for (int i = 0; i < n; i++)
        {
            if (arr[i] > arr[(i + 1) % n])
            {
                decreaseCount++;
            }
        }

        // If there is more than one decrease point, it cannot be sorted by shifts.
        return decreaseCount <= 1;
    }
}
}
