namespace Benchmarks.csharp_3.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Out of list of strings, return the Longest one. Return the first one in case of multiple
    /// strings of the same length. Return null (None) in case the input list is empty.
    /// </summary>
    public static object Longest(List<string> strings)
    {
        if (strings == null || strings.Count == 0)
        {
            return null;
        }

        string longestSoFar = strings[0];

        foreach (string s in strings)
        {
            if (s.Length > longestSoFar.Length)
            {
                longestSoFar = s;
            }
        }

        return longestSoFar;
    }
}
}
