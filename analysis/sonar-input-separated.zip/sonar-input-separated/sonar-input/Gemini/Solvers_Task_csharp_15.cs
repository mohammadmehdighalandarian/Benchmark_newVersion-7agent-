namespace Benchmarks.csharp_15.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Return Median of elements in the list l.
    /// </summary>
    public static object Median(List<int> l)
    {
        if (l == null || l.Count == 0)
        {
            return null;
        }

        // Sort the list to find the middle elements
        var sorted = l.OrderBy(x => x).ToList();
        int count = sorted.Count;

        if (count % 2 != 0)
        {
            // For odd number of elements, return the middle one
            return sorted[count / 2];
        }
        else
        {
            // For even number of elements, return the average of the two middle elements
            // Note: Returning as double to handle cases like (6 + 10) / 2.0 = 8.0
            double leftMid = sorted[count / 2 - 1];
            double rightMid = sorted[count / 2];
            return (leftMid + rightMid) / 2.0;
        }
    }
}
}
