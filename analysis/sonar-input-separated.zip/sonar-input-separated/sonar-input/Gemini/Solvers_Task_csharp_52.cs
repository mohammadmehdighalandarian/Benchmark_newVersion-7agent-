namespace Benchmarks.csharp_52.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
public static int MaxFill(List<List<int>> grid, int capacity)
{
if (grid == null || grid.Count == 0 || capacity <= 0)
{
return 0;
}


    int totalBucketsNeeded = 0;

    foreach (var well in grid)
    {
        int waterInWell = 0;
        foreach (int unit in well)
        {
            if (unit == 1)
            {
                waterInWell++;
            }
        }

        if (waterInWell > 0)
        {
            // Calculate how many times the bucket needs to be lowered for this specific well.
            // This is equivalent to Ceiling(waterInWell / capacity).
            int drops = (waterInWell + capacity - 1) / capacity;
            totalBucketsNeeded += drops;
        }
    }

    return totalBucketsNeeded;
}



}
}
