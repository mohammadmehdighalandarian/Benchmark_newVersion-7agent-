namespace Benchmarks.csharp_28.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Returns the greatest integer that is greater than zero, 
    /// and has a frequency greater than or equal to the value of the integer itself.
    /// If no such value exists, returns -1.
    /// </summary>
    public static int Search(List<int> lst)
    {
        var eligible = lst.GroupBy(x => x)
                          .Where(g => g.Count() >= g.Key)
                          .Select(g => g.Key);

        return eligible.Any() ? eligible.Max() : -1;
    }
}
}
