namespace Benchmarks.csharp_68.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Returns the number of elements in the array that are greater than 10 and both 
    /// first and last digits of a number are odd (1, 3, 5, 7, 9).
    /// </summary>
    public static int SpecialFilter(List<int> nums)
    {
        int count = 0;
        foreach (int num in nums)
        {
            // Requirement 1: Number must be greater than 10
            if (num > 10)
            {
                string s = num.ToString();
                
                // Get the first and last characters as integers
                int firstDigit = s[0] - '0';
                int lastDigit = s[s.Length - 1] - '0';

                // Requirement 2: Both first and last digits must be odd
                if (IsOdd(firstDigit) && IsOdd(lastDigit))
                {
                    count++;
                }
            }
        }
        return count;
    }

    private static bool IsOdd(int digit)
    {
        return digit % 2 != 0;
    }
}
}
