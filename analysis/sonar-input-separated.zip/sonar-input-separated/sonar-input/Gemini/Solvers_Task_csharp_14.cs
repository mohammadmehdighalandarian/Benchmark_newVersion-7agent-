namespace Benchmarks.csharp_14.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
/// <summary>
/// Computes the n-th element of the Fib4 number sequence efficiently without recursion.
/// Fib4(0) -> 0, Fib4(1) -> 0, Fib4(2) -> 2, Fib4(3) -> 0
/// Fib4(n) -> Fib4(n-1) + Fib4(n-2) + Fib4(n-3) + Fib4(n-4)
/// </summary>
public static int Fib4(int n)
{
if (n == 0) return 0;
if (n == 1) return 0;
if (n == 2) return 2;
if (n == 3) return 0;


    int a = 0; // Fib4(0)
    int b = 0; // Fib4(1)
    int c = 2; // Fib4(2)
    int d = 0; // Fib4(3)

    int result = 0;
    for (int i = 4; i <= n; i++)
    {
        result = a + b + c + d;
        a = b;
        b = c;
        c = d;
        d = result;
    }

    return d;
}



}
}
