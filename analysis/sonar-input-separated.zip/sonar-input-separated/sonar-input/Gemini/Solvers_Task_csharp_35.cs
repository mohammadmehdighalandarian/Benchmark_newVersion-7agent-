namespace Benchmarks.csharp_35.Gemini
{
using System;

public class Solver
{
    /// <summary> 
    /// Takes a string and returns True if the string length is a prime number or False otherwise.
    /// </summary>
    public static bool PrimeLength(string string0)
    {
        int n = string0.Length;
        if (n < 2) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;

        int boundary = (int)Math.Floor(Math.Sqrt(n));

        for (int i = 3; i <= boundary; i += 2)
        {
            if (n % i == 0) return false;
        }

        return true;
    }
}
}
