namespace Benchmarks.csharp_56.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Determines whether the length of the intersection of two closed intervals is a prime number.
    /// </summary>
    public static string Intersection(List<int> interval1, List<int> interval2)
    {
        int start1 = interval1[0];
        int end1 = interval1[1];
        int start2 = interval2[0];
        int end2 = interval2[1];

        // Find the intersection boundaries
        int intersectionStart = Math.Max(start1, start2);
        int intersectionEnd = Math.Min(end1, end2);

        // Check if an intersection exists
        if (intersectionStart > intersectionEnd)
        {
            return "NO";
        }

        // Calculate the length of the closed interval intersection
        int length = intersectionEnd - intersectionStart;

        // Return YES if length is prime, else NO
        return IsPrime(length) ? "YES" : "NO";
    }

    /// <summary>
    /// Helper method to determine if an integer is a prime number.
    /// </summary>
    private static bool IsPrime(int n)
    {
        if (n < 2) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;

        int boundary = (int)Math.Floor(Math.Sqrt(n));

        for (int i = 3; i <= boundary; i += 2)
        {
            if (n % i == 0) return false;
        }

        return true;
    }
}
}
