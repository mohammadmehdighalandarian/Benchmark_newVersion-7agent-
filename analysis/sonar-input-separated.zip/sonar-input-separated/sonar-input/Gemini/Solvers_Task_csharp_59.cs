namespace Benchmarks.csharp_59.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Determines if there is a valid subsequence of brackets where at least one bracket is nested.
    /// This is equivalent to checking if the string contains "[[]]" as a subsequence.
    /// </summary>
    public static bool IsNested(string string0)
    {
        if (string.IsNullOrEmpty(string0))
        {
            return false;
        }

        // The smallest valid nested bracket sequence is "[[]]".
        // If a valid subsequence has any nesting, it must contain "[[]]" as a subsequence.
        string target = "[[]]";
        int targetIndex = 0;

        foreach (char c in string0)
        {
            if (c == target[targetIndex])
            {
                targetIndex++;
                
                // If we've found all four characters in order, the condition is met.
                if (targetIndex == 4)
                {
                    return true;
                }
            }
        }

        return false;
    }
}
}
