namespace Benchmarks.csharp_60.Gemini
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        /// <summary> 
        /// Returns the sum of squared numbers in the given list, 
        /// rounding each element to the upper integer (Ceiling) first.
        /// </summary>
        public static int SumSquares(List<object> lst)
        {
            return lst.Select(x =>
            {
                double val = Convert.ToDouble(x);
                int ceilingVal = (int)Math.Ceiling(val);
                return ceilingVal * ceilingVal;
            }).Sum();
        }
    }
}
