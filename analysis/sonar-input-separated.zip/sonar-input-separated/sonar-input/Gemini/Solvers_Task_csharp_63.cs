namespace Benchmarks.csharp_63.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Returns a list containing the largest of negative integers and the smallest of positive integers.
    /// If there is no negative or positive integers, returns null for that position.
    /// </summary>
    public static List<object> LargestSmallestIntegers(List<int> lst)
    {
        // Find the largest negative integer (x < 0)
        // Using Cast<int?>() allows Max() to return null instead of throwing an exception on an empty sequence
        int? largestNegative = lst.Where(x => x < 0).Cast<int?>().Max();

        // Find the smallest positive integer (x > 0)
        int? smallestPositive = lst.Where(x => x > 0).Cast<int?>().Min();

        // Return as a list of objects to accommodate both integers and null values
        return new List<object> { largestNegative, smallestPositive };
    }
}
}
