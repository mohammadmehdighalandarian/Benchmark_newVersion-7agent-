namespace Benchmarks.csharp_29.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Given the lengths of the three sides of a triangle. Return the area of
    /// the triangle rounded to 2 decimal points if the three sides form a valid triangle. 
    /// Otherwise return -1
    /// Three sides make a valid triangle when the sum of any two sides is greater 
    /// than the third side.
    /// </summary>
    public static object TriangleArea(int a, int b, int c)
    {
        // Check for valid triangle inequality
        if (a + b <= c || a + c <= b || b + c <= a)
        {
            return -1;
        }

        // Use Heron's formula: Area = sqrt(s(s-a)(s-b)(s-c))
        // where s is the semi-perimeter: (a+b+c)/2
        double s = (a + b + c) / 2.0;
        double area = Math.Sqrt(s * (s - a) * (s - b) * (s - c));

        // Return the area rounded to 2 decimal points
        return Math.Round(area, 2);
    }
}
}
