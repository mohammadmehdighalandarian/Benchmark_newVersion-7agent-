namespace Benchmarks.csharp_36.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Given a positive integer N, return the total sum of its digits in binary.
    /// </summary>
    public static string Solve(int N)
    {
        int sum = 0;
        int temp = Math.Abs(N);

        // Calculate the sum of the digits of N in base 10
        if (temp == 0)
        {
            sum = 0;
        }
        else
        {
            while (temp > 0)
            {
                sum += temp % 10;
                temp /= 10;
            }
        }

        // Convert the resulting sum to a binary string
        return Convert.ToString(sum, 2);
    }
}
}
