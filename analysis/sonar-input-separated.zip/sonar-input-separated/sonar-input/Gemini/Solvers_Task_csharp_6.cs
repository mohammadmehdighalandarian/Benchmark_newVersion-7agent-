namespace Benchmarks.csharp_6.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<double> RescaleToUnit(List<double> numbers)
    {
        double min = numbers.Min();
        double max = numbers.Max();
        double range = max - min;

        return numbers.Select(x => (x - min) / range).ToList();
    }
}
}
