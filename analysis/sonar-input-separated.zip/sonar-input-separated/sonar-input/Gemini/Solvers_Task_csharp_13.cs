namespace Benchmarks.csharp_13.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// PairsSumToZero takes a list of integers as an input.
    /// It returns True if there are two distinct elements in the list that
    /// sum to zero, and False otherwise.
    /// </summary>
    public static bool PairsSumToZero(List<int> l)
    {
        if (l == null || l.Count < 2)
        {
            return false;
        }

        HashSet<int> seen = new HashSet<int>();
        
        foreach (int num in l)
        {
            // If the negation of the current number exists in our seen set,
            // we have found two distinct indices i and j such that l[i] + l[j] == 0.
            if (seen.Contains(-num))
            {
                return true;
            }
            seen.Add(num);
        }

        return false;
    }
}
}
