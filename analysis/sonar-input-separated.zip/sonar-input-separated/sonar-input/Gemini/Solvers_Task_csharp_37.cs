namespace Benchmarks.csharp_37.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// You are given a 2 dimensional data, as a nested lists,
    /// which is similar to matrix, however, unlike matrices,
    /// each row may contain a different number of columns.
    /// Given lst, and integer x, find integers x in the list,
    /// and return list of tuples, [(x1, y1), (x2, y2) ...] such that
    /// each tuple is a coordinate - (row, columns), starting with 0.
    /// Sort coordinates initially by rows in ascending order.
    /// Also, sort coordinates of the row by columns in descending order.
    /// </summary>
    public static List<List<int>> GetRow(List<List<int>> lst, int x)
    {
        List<List<int>> coordinates = new List<List<int>>();

        if (lst == null)
        {
            return coordinates;
        }

        // Iterate through rows in ascending order (0 to N-1)
        for (int r = 0; r < lst.Count; r++)
        {
            List<int> columnIndices = new List<int>();
            
            // Find all columns in current row where value matches x
            for (int c = 0; c < lst[r].Count; c++)
            {
                if (lst[r][c] == x)
                {
                    columnIndices.Add(c);
                }
            }

            if (columnIndices.Count > 0)
            {
                // Sort coordinates of the specific row by columns in descending order
                columnIndices.Sort((a, b) => b.CompareTo(a));

                foreach (int colIndex in columnIndices)
                {
                    coordinates.Add(new List<int> { r, colIndex });
                }
            }
        }

        return coordinates;
    }
}
}
