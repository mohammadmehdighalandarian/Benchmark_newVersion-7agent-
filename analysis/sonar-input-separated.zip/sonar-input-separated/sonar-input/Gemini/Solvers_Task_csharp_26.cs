namespace Benchmarks.csharp_26.Gemini
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        /// <summary>
        /// The FibFib number sequence is a sequence similar to the Fibbonacci sequence that's defined as follows:
        /// Fibfib(0) == 0
        /// Fibfib(1) == 0
        /// Fibfib(2) == 1
        /// Fibfib(n) == Fibfib(n-1) + Fibfib(n-2) + Fibfib(n-3).
        /// </summary>
        public static int Fibfib(int n)
        {
            if (n == 0) return 0;
            if (n == 1) return 0;
            if (n == 2) return 1;


            int a = 0; // Fibfib(n-3)
            int b = 0; // Fibfib(n-2)
            int c = 1; // Fibfib(n-1)
            int result = 0;

            for (int i = 3; i <= n; i++)
            {
                result = a + b + c;
                a = b;
                b = c;
                c = result;
            }

            return c;
        }
    }
}
