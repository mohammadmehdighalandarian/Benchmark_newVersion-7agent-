namespace Benchmarks.csharp_78.Gemini
{
using System;
using System.Security.Cryptography;
using System.Text;

public class Solver
{
/// <summary>
/// Given a string 'text', return its md5 hash equivalent string.
/// If 'text' is an empty string, return null (None).
/// </summary>
public static object StringToMd5(string text)
{
if (string.IsNullOrEmpty(text))
{
return null;
}


    using (MD5 md5 = MD5.Create())
    {
        byte[] inputBytes = Encoding.UTF8.GetBytes(text);
        byte[] hashBytes = md5.ComputeHash(inputBytes);

        StringBuilder sb = new StringBuilder();
        foreach (byte b in hashBytes)
        {
            sb.Append(b.ToString("x2"));
        }
        return sb.ToString();
    }
}



}
}
