namespace Benchmarks.csharp_21.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    /// <summary> 
    /// Return n-th Fibonacci number.
    /// >>> Fib(10)
    /// 55
    /// >>> Fib(1)
    /// 1
    /// >>> Fib(8)
    /// 21
    /// </summary>
    public static int Fib(int n)
    {
        if (n <= 0) return 0;
        if (n == 1) return 1;

        int a = 0;
        int b = 1;

        for (int i = 2; i <= n; i++)
        {
            int next = a + b;
            a = b;
            b = next;
        }

        return b;
    }
}
}
