namespace Benchmarks.csharp_44.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Splits a string of words separated by commas or spaces into a list of words.
    /// </summary>
    public static List<string> WordsString(string s)
    {
        if (string.IsNullOrEmpty(s))
        {
            return new List<string>();
        }

        // Split the string using both comma and space as delimiters.
        // StringSplitOptions.RemoveEmptyEntries handles cases like ", " to avoid empty strings in the result.
        string[] parts = s.Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
        
        return parts.ToList();
    }
}
}
