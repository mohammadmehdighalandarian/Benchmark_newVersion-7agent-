namespace Benchmarks.csharp_7.Gemini
{
using System;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// For a given string, flip lowercase characters to uppercase and uppercase to lowercase.
    /// >>> FlipCase('Hello')
    /// 'hELLO'
    /// </summary>
    public static string FlipCase(string string0)
    {
        if (string0 == null)
        {
            return null;
        }

        return new string(string0.Select(c => 
            char.IsUpper(c) ? char.ToLower(c) : char.ToUpper(c)
        ).ToArray());
    }
}
}
