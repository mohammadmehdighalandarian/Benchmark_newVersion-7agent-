namespace Benchmarks.csharp_76.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Given the lengths of the three sides of a triangle. Return True if the three
    /// sides form a right-angled triangle, False otherwise.
    /// A right-angled triangle is a triangle in which one angle is right angle or 
    /// 90 degree.
    /// </summary>
    public static bool RightAngleTriangle(int a, int b, int c)
    {
        // A triangle must have sides with positive length
        if (a <= 0 || b <= 0 || c <= 0)
        {
            return false;
        }

        // Use long to prevent potential overflow during squaring
        long a2 = (long)a * a;
        long b2 = (long)b * b;
        long c2 = (long)c * c;

        // Check the Pythagorean theorem for all possible hypotenuses
        // a^2 + b^2 = c^2 OR a^2 + c^2 = b^2 OR b^2 + c^2 = a^2
        return (a2 + b2 == c2) || (a2 + c2 == b2) || (b2 + c2 == a2);
    }
}
}
