namespace Benchmarks.csharp_30.Gemini
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        /// <summary> 
        /// Returns True if the object q will fly, and False otherwise.
        /// The object q will fly if it's balanced (it is a palindromic list) 
        /// and the sum of its elements is less than or equal to the maximum possible weight w.
        /// </summary>
        public static bool WillItFly(List<int> q, int w)
        {
            if (q == null) return false;

            // Check if the sum of elements is less than or equal to w
            long sum = 0;
            foreach (int val in q)
            {
                sum += val;
            }

            if (sum > w)
            {
                return false;
            }

            // Check if the list is balanced (palindromic)
            int left = 0;
            int right = q.Count - 1;
            while (left < right)
            {
                if (q[left] != q[right])
                {
                    return false;
                }

                left++;
                right--;
            }

            return true;
        }
    }
}
