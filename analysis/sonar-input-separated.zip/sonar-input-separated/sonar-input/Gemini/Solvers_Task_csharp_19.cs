namespace Benchmarks.csharp_19.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    /// <summary> 
    /// You're an expert C# programmer
    /// Add two numbers x and y
    /// >>> Add(2, 3)
    /// 5
    /// >>> Add(5, 7)
    /// 12
    /// </summary>
    public static int Add(int x, int y)
    {
        return x + y;
    }
}
}
