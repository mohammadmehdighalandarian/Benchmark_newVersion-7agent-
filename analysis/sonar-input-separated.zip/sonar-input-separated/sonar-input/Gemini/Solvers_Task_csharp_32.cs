namespace Benchmarks.csharp_32.Gemini
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static string DecimalToBinary(int @decimal)
        {
            string binary = Convert.ToString(@decimal, 2);
            return $"db{binary}db";
        }
    }
}
