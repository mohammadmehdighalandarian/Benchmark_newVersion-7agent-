namespace Benchmarks.csharp_79.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Given two positive integers a and b, return the even digits between a
    /// and b, in ascending order.
    /// </summary>
    public static List<int> GenerateIntegers(int a, int b)
    {
        int start = Math.Min(a, b);
        int end = Math.Max(a, b);
        List<int> result = new List<int>();

        for (int i = start; i <= end; i++)
        {
            // Only consider single-digit even numbers (0, 2, 4, 6, 8)
            if (i >= 0 && i <= 9 && i % 2 == 0)
            {
                result.Add(i);
            }
        }

        return result;
    }
}
}
