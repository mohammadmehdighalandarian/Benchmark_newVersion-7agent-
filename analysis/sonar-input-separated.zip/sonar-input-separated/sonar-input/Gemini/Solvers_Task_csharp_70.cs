namespace Benchmarks.csharp_70.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Returns a list containing all planets whose orbits are 
    /// located between the orbit of planet1 and the orbit of planet2, sorted by 
    /// the proximity to the sun.
    /// </summary>
    public static List<string> Bf(string planet1, string planet2)
    {
        string[] planets = { "Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune" };

        int index1 = Array.IndexOf(planets, planet1);
        int index2 = Array.IndexOf(planets, planet2);

        // If planet1 or planet2 are not correct planet names, return an empty list
        if (index1 == -1 || index2 == -1)
        {
            return new List<string>();
        }

        int start = Math.Min(index1, index2);
        int end = Math.Max(index1, index2);

        List<string> result = new List<string>();

        // Iterate through planets between the two indices
        for (int i = start + 1; i < end; i++)
        {
            result.Add(planets[i]);
        }

        return result;
    }
}
}
