namespace Benchmarks.csharp_75.Gemini
{
using System;
using System.Text;

public class Solver
{
    /// <summary> 
    /// Given a positive integer, obtain its roman numeral equivalent as a string,
    /// and return it in lowercase.
    /// Restrictions: 1 <= num <= 1000
    /// </summary>
    public static string IntToMiniRoman(int number)
    {
        int[] values = { 1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1 };
        string[] symbols = { "m", "cm", "d", "cd", "c", "xc", "l", "xl", "x", "ix", "v", "iv", "i" };

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < values.Length; i++)
        {
            while (number >= values[i])
            {
                number -= values[i];
                result.Append(symbols[i]);
            }
        }

        return result.ToString();
    }
}
}
