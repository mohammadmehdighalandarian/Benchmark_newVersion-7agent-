namespace Benchmarks.csharp_66.Gemini
{
using System;

public class Solver
{
    /// <summary> 
    /// You're an expert C# programmer
    /// Your task is to implement a function that will Simplify the expression
    /// x * n. The function returns True if x * n evaluates to a whole number and False
    /// otherwise. Both x and n, are string representation of a fraction, and have the following format,
    /// <numerator>/<denominator> where both numerator and denominator are positive whole numbers.
    /// 
    /// You can assume that x, and n are valid fractions, and do not have zero as denominator.
    /// 
    /// Simplify("1/5", "5/1") = True
    /// Simplify("1/6", "2/1") = False
    /// Simplify("7/10", "10/2") = False
    /// 
    /// </summary>
    public static bool Simplify(string x, string n)
    {
        string[] xParts = x.Split('/');
        string[] nParts = n.Split('/');

        long xNum = long.Parse(xParts[0]);
        long xDen = long.Parse(xParts[1]);
        long nNum = long.Parse(nParts[0]);
        long nDen = long.Parse(nParts[1]);

        long numeratorProduct = xNum * nNum;
        long denominatorProduct = xDen * nDen;

        return numeratorProduct % denominatorProduct == 0;
    }
}
}
