namespace Benchmarks.csharp_12.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// TriplesSumToZero takes a list of integers as an input.
    /// It returns True if there are three distinct elements in the list that
    /// sum to zero, and False otherwise.
    /// </summary>
    public static bool TriplesSumToZero(List<int> l)
    {
        if (l == null || l.Count < 3)
        {
            return false;
        }

        // Sorting the list allows us to use the two-pointer approach
        // which reduces the complexity from O(n^3) to O(n^2).
        l.Sort();

        for (int i = 0; i < l.Count - 2; i++)
        {
            int left = i + 1;
            int right = l.Count - 1;

            while (left < right)
            {
                int currentSum = l[i] + l[left] + l[right];

                if (currentSum == 0)
                {
                    return true;
                }
                else if (currentSum < 0)
                {
                    // Sum is too small, move the left pointer forward
                    left++;
                }
                else
                {
                    // Sum is too large, move the right pointer backward
                    right--;
                }
            }
        }

        return false;
    }
}
}
