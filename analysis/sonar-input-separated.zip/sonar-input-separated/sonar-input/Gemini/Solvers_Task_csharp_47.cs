namespace Benchmarks.csharp_47.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> F(int n)
    {
        List<int> result = new List<int>();
        for (int i = 1; i <= n; i++)
        {
            if (i % 2 == 0)
            {
                // Calculate Factorial of i for even i
                int factorial = 1;
                for (int j = 1; j <= i; j++)
                {
                    factorial *= j;
                }
                result.Add(factorial);
            }
            else
            {
                // Calculate Sum from 1 to i for odd i
                // Formula: (n * (n + 1)) / 2
                int sum = (i * (i + 1)) / 2;
                result.Add(sum);
            }
        }
        return result;
    }
}
}
