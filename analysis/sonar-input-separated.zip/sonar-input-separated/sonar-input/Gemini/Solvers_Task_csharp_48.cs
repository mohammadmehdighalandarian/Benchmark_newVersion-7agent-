namespace Benchmarks.csharp_48.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Given a positive integer n, return a list that has the number of even and odd
    /// integer palindromes that fall within the range(1, n), inclusive.
    /// </summary>
    public static List<int> EvenOddPalindrome(int n)
    {
        int evenCount = 0;
        int oddCount = 0;

        for (int i = 1; i <= n; i++)
        {
            if (IsPalindrome(i))
            {
                if (i % 2 == 0)
                {
                    evenCount++;
                }
                else
                {
                    oddCount++;
                }
            }
        }

        return new List<int> { evenCount, oddCount };
    }

    private static bool IsPalindrome(int num)
    {
        string s = num.ToString();
        int left = 0;
        int right = s.Length - 1;
        
        while (left < right)
        {
            if (s[left] != s[right])
            {
                return false;
            }
            left++;
            right--;
        }
        
        return true;
    }
}
}
