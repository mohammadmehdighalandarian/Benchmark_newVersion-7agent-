namespace Benchmarks.csharp_46.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
/// <summary>
/// Computes the average of the integers from n through m (inclusive).
/// Rounds the answer to the nearest integer and converts it to binary.
/// If n > m, returns -1.
/// </summary>
public static object RoundedAvg(int n, int m)
{
// Guard clause: if n is greater than m, return -1.
if (n > m)
{
return -1;
}


    // The average of a sequence of consecutive integers from n to m
    // is the arithmetic mean of the first and last numbers: (n + m) / 2.
    // We use double to handle cases where (n + m) is odd (resulting in .5).
    // Casting m to double handles potential overflow during the addition of two large ints.
    double average = (n + (double)m) / 2.0;

    // Round the average to the nearest integer. 
    // Based on the example RoundedAvg(20, 33) => "0b11010" (which is 26),
    // we use MidpointRounding.ToEven (Banker's Rounding), which is the 
    // default behavior of Math.Round in C#. 26.5 rounds to 26.
    int roundedValue = (int)Math.Round(average, MidpointRounding.ToEven);

    // Convert the rounded integer to its binary string representation.
    string binaryRepresentation = Convert.ToString(roundedValue, 2);

    // Prepend the "0b" prefix and return the result.
    return "0b" + binaryRepresentation;
}



}
}
