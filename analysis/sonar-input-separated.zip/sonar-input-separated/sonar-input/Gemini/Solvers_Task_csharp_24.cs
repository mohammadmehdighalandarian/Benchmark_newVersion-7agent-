namespace Benchmarks.csharp_24.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// SumToN is a function that sums numbers from 1 to n.
    /// </summary>
    public static int SumToN(int n)
    {
        return n * (n + 1) / 2;
    }
}
}
