namespace Benchmarks.csharp_4.Gemini
{
using System;

public class Solver
{
    /// <summary> 
    /// Return a greatest common divisor of two integers a and b
    /// >>> GreatestCommonDivisor(3, 5)
    /// 1
    /// >>> GreatestCommonDivisor(25, 15)
    /// 5
    /// </summary>
    public static int GreatestCommonDivisor(int a, int b)
    {
        while (b != 0)
        {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return Math.Abs(a);
    }
}
}
