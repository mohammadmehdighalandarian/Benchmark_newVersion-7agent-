namespace Benchmarks.csharp_22.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Return sorted unique common elements for two lists.
    /// </summary>
    public static List<int> Common(List<int> l1, List<int> l2)
    {
        if (l1 == null || l2 == null)
        {
            return new List<int>();
        }

        return l1.Intersect(l2).OrderBy(x => x).ToList();
    }
}
}
