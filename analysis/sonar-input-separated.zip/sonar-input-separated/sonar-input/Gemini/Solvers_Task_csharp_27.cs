namespace Benchmarks.csharp_27.Gemini
{
    using System;
    using System.Linq;

    public class Solver
    {
        public static int VowelsCount(string s)
        {
            if (string.IsNullOrEmpty(s)) return 0;

            int count = 0;
            string lowerStr = s.ToLower();

            for (int i = 0; i < lowerStr.Length; i++)
            {
                char c = lowerStr[i];
                if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
                {
                    count++;
                }
                else if (c == 'y' && i == lowerStr.Length - 1)
                {
                    count++;
                }
            }

            return count;
        }
    }
}
