namespace Benchmarks.csharp_53.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Returns a list of all words from string s that contain exactly 
    /// n consonants, in the order they appear.
    /// </summary>
    public static List<string> SelectWords(string s, int n)
    {
        // Return an empty list if the input string is null or empty
        if (string.IsNullOrEmpty(s))
        {
            return new List<string>();
        }

        const string vowels = "aeiouAEIOU";
        // Split the string by spaces to isolate words
        string[] words = s.Split(' ');
        List<string> result = new List<string>();

        foreach (string word in words)
        {
            // Skip empty strings resulting from multiple spaces
            if (string.IsNullOrEmpty(word))
            {
                continue;
            }

            int consonantCount = 0;
            foreach (char c in word)
            {
                // A character is a consonant if it is a letter and not a vowel
                if (char.IsLetter(c) && !vowels.Contains(c))
                {
                    consonantCount++;
                }
            }

            // If the count matches n, add the word to the result list
            if (consonantCount == n)
            {
                result.Add(word);
            }
        }

        return result;
    }
}
}
