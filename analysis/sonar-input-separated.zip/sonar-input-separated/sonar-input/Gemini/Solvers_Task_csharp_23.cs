namespace Benchmarks.csharp_23.Gemini
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static int LargestPrimeFactor(int n)
        {
            int maxPrime = -1;

            // Extract the factor 2
            while (n % 2 == 0)
            {
                maxPrime = 2;
                n /= 2;
            }

            // Extract odd factors starting from 3
            for (int i = 3; (long)i * i <= n; i += 2)
            {
                while (n % i == 0)
                {
                    maxPrime = i;
                    n /= i;
                }
            }

            // If n is still greater than 2, then the remaining n is the largest prime factor
            if (n > 2)
            {
                maxPrime = n;
            }

            return maxPrime;
        }
    }
}
