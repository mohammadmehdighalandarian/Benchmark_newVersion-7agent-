namespace Benchmarks.csharp_39.Gemini
{
using System;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// You're an expert C# programmer
    /// 
    /// You'll be given a string of words, and your task is to count the number
    /// of boredoms. A boredom is a sentence that starts with the word "I".
    /// Sentences are delimited by '.', '?' or '!'.
    /// 
    /// For example:
    /// >>> IsBored("Hello world")
    /// 0
    /// >>> IsBored("The sky is blue. The sun is shining. I love this weather")
    /// 1
    /// 
    /// </summary>
    public static int IsBored(string S)
    {
        if (string.IsNullOrEmpty(S))
        {
            return 0;
        }

        // Define the sentence delimiters
        char[] delimiters = new char[] { '.', '?', '!' };

        // Split the input string into sentences based on delimiters
        string[] sentences = S.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);

        int boredomCount = 0;

        foreach (string sentence in sentences)
        {
            // Trim leading and trailing whitespace from the sentence
            string trimmedSentence = sentence.Trim();

            // A boredom is a sentence that starts with the word "I"
            // We split by space to isolate the first word
            string[] words = trimmedSentence.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            if (words.Length > 0 && words[0] == "I")
            {
                boredomCount++;
            }
        }

        return boredomCount;
    }
}
}
