namespace Benchmarks.csharp_61.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    /// <summary> 
    /// Returns True if the last character of a given string is an alphabetical character 
    /// and is not a part of a word (separated by a space), and False otherwise.
    /// </summary>
    public static bool CheckIfLastCharIsALetter(string txt)
    {
        if (string.IsNullOrEmpty(txt))
        {
            return false;
        }

        int n = txt.Length;
        char lastChar = txt[n - 1];

        // Check if the last character is an alphabetical character
        if (!char.IsLetter(lastChar))
        {
            return false;
        }

        // A character is "not part of a word" if it is standalone.
        // This means either the string length is 1, or the character before it is a space.
        if (n == 1 || txt[n - 2] == ' ')
        {
            return true;
        }

        return false;
    }
}
}
