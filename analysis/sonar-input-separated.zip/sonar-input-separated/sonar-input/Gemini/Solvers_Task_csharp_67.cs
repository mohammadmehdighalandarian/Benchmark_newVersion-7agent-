namespace Benchmarks.csharp_67.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Sorts the given list of integers in ascending order according to the sum of their digits.
    /// If the number is negative, the first digit is treated as negative.
    /// If there are several items with the same sum, their relative order from the original list is preserved.
    /// </summary>
    public static List<int> OrderByPoints(List<int> nums)
    {
        if (nums == null || nums.Count == 0)
        {
            return new List<int>();
        }

        // Enumerable.OrderBy is a stable sort in .NET, satisfying the requirement 
        // to maintain original order for items with similar digit sums.
        return nums.OrderBy(GetWeight).ToList();
    }

    /// <summary>
    /// Calculates the weight (sum of digits) of an integer based on the specific rules:
    /// For positive numbers, sum all digits.
    /// For negative numbers, the first digit is negative and others are positive.
    /// </summary>
    private static int GetWeight(int n)
    {
        string s = n.ToString();
        int sum = 0;

        if (n < 0)
        {
            // For negative numbers, skip the '-' sign at index 0.
            // The first digit (index 1) is subtracted, subsequent digits are added.
            for (int i = 1; i < s.Length; i++)
            {
                int digit = s[i] - '0';
                if (i == 1)
                {
                    sum -= digit;
                }
                else
                {
                    sum += digit;
                }
            }
        }
        else
        {
            // For non-negative numbers, simply sum all digits.
            for (int i = 0; i < s.Length; i++)
            {
                sum += (s[i] - '0');
            }
        }

        return sum;
    }
}
}
