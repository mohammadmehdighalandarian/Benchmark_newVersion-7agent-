namespace Benchmarks.csharp_18.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Return True if all numbers in the list l are below threshold t.
    /// >>> BelowThreshold([1, 2, 4, 10], 100)
    /// True
    /// >>> BelowThreshold([1, 20, 4, 10], 5)
    /// False
    /// </summary>
    public static bool BelowThreshold(List<int> l, int t)
    {
        return l.All(x => x < t);
    }
}
}
