namespace Benchmarks.csharp_62.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Returns the largest index of an element which is not greater than or equal to 
    /// the element immediately preceding it. If no such element exists then return -1.
    /// </summary>
    public static int CanArrange(List<int> arr)
    {
        // Iterate backwards from the end of the list to find the largest index first
        for (int i = arr.Count - 1; i > 0; i--)
        {
            // "Not greater than or equal to" is equivalent to "less than"
            if (arr[i] < arr[i - 1])
            {
                return i;
            }
        }
        return -1;
    }
}
}
