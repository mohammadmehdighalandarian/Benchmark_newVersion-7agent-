namespace Benchmarks.csharp_1.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// For a given list of integers, return a list consisting of a sum and a product of all the integers in a list.
    /// Empty sum should be equal to 0 and empty product should be equal to 1.
    /// </summary>
    public static List<int> SumProduct(List<int> numbers)
    {
        int sum = 0;
        int product = 1;

        foreach (int n in numbers)
        {
            sum += n;
            product *= n;
        }

        return new List<int> { sum, product };
    }
}
}
