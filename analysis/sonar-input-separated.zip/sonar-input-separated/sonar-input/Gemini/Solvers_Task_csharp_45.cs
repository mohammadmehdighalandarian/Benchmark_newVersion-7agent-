namespace Benchmarks.csharp_45.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// This function takes two positive numbers x and y and returns the
    /// biggest even integer number that is in the range [x, y] inclusive. If 
    /// there's no such number, then the function should return -1.
    /// </summary>
    public static int ChooseNum(int x, int y)
    {
        if (x > y)
        {
            return -1;
        }

        if (y % 2 == 0)
        {
            return y;
        }

        if (y - 1 >= x)
        {
            return y - 1;
        }

        return -1;
    }
}
}
