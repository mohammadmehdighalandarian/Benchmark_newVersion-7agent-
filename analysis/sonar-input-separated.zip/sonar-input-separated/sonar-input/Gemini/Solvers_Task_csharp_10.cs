namespace Benchmarks.csharp_10.Gemini
{
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Return sorted Unique elements in a list
    /// >>> Unique([5, 3, 5, 2, 3, 3, 9, 0, 123])
    /// [0, 2, 3, 5, 9, 123]
    /// </summary>
    public static List<int> Unique(List<int> l)
    {
        return l.Distinct().OrderBy(x => x).ToList();
    }
}
}
