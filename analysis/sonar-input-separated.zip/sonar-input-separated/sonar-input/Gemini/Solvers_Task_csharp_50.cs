namespace Benchmarks.csharp_50.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Determines whether it is possible to perform an exchange of elements
    /// between two lists to make lst1 a list of only even numbers.
    /// </summary>
    public static string Exchange(List<int> lst1, List<int> lst2)
    {
        // Count how many odd numbers are currently in lst1 that need to be replaced.
        int oddInLst1 = lst1.Count(x => x % 2 != 0);

        // Count how many even numbers are available in lst2 to use as replacements.
        int evenInLst2 = lst2.Count(x => x % 2 == 0);

        // If we have enough even numbers in lst2 to replace all odd numbers in lst1, return "YES".
        if (evenInLst2 >= oddInLst1)
        {
            return "YES";
        }

        return "NO";
    }
}
}
