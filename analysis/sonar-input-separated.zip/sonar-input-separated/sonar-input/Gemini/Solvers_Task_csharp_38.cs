namespace Benchmarks.csharp_38.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Returns the 2nd smallest element of the list.
    /// Returns null (None) if there is no such element.
    /// </summary>
    public static object NextSmallest(List<int> lst)
    {
        if (lst == null || lst.Count < 2)
        {
            return null;
        }

        // Get unique elements and sort them in ascending order
        var sortedDistinct = lst.Distinct().OrderBy(x => x).Take(2).ToList();

        // If there are fewer than 2 unique elements, the 2nd smallest doesn't exist
        if (sortedDistinct.Count < 2)
        {
            return null;
        }

        // Return the second element in the sorted unique list
        return sortedDistinct[1];
    }
}
}
