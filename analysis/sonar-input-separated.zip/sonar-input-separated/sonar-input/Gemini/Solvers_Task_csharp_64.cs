namespace Benchmarks.csharp_64.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// The Brazilian factorial is defined as:
    /// brazilian_factorial(n) = n! * (n-1)! * (n-2)! * ... * 1!
    /// where n > 0
    /// </summary>
    public static int SpecialFactorial(int n)
    {
        if (n <= 0) return 0;
        
        int result = 1;
        int currentFactorial = 1;
        
        for (int i = 1; i <= n; i++)
        {
            currentFactorial *= i;
            result *= currentFactorial;
        }
        
        return result;
    }
}
}
