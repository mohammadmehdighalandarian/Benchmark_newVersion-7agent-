namespace Benchmarks.csharp_57.Gemini
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static List<object> Tri(int n)
        {
            List<object> result = new List<object>();
            if (n < 0) return result;


            for (int i = 0; i <= n; i++)
            {
                if (i == 0)
                {
                    // tri(n) = 1 + n / 2, if n is even
                    result.Add(1L);
                }
                else if (i == 1)
                {
                    // tri(1) = 3
                    result.Add(3L);
                }
                else if (i % 2 == 0)
                {
                    // tri(n) = 1 + n / 2, if n is even
                    result.Add(1L + (long)i / 2);
                }
                else
                {
                    // tri(n) = tri(n - 1) + tri(n - 2) + tri(n + 1), if n is odd
                    // n is odd, so n-1 is even and n+1 is even
                    // tri(n-1) = 1 + (n-1) / 2
                    // tri(n+1) = 1 + (n+1) / 2
                    // tri(n-2) is already computed in the list
                    long term_prev1 = 1L + (long)(i - 1) / 2;
                    long term_prev2 = Convert.ToInt64(result[i - 2]);
                    long term_next = 1L + (long)(i + 1) / 2;

                    result.Add(term_prev1 + term_prev2 + term_next);
                }
            }

            return result;
        }
    }
}
