namespace Benchmarks.csharp_73.Gemini
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        /// <summary> 
        /// You're an expert C# programmer
        /// You will be given the name of a class (a string) and a list of extensions.
        /// The extensions are to be used to load additional classes to the class. The
        /// strength of the extension is as follows: Let CAP be the number of the uppercase
        /// letters in the extension's name, and let SM be the number of lowercase letters 
        /// in the extension's name, the strength is given by the fraction CAP - SM. 
        /// You should find the strongest extension and return a string in this 
        /// format: ClassName.StrongestExtensionName.
        /// If there are two or more extensions with the same strength, you should
        /// choose the one that comes first in the list.
        /// </summary>
        public static string StrongestExtension(string class_name, List<string> extensions)
        {
            string strongest = extensions[0];
            int maxStrength = int.MinValue;

            foreach (string ext in extensions)
            {
                int cap = 0;
                int sm = 0;

                foreach (char c in ext)
                {
                    if (char.IsUpper(c))
                    {
                        cap++;
                    }
                    else if (char.IsLower(c))
                    {
                        sm++;
                    }
                }

                int currentStrength = cap - sm;

                if (currentStrength > maxStrength)
                {
                    maxStrength = currentStrength;
                    strongest = ext;
                }
            }

            return $"{class_name}.{strongest}";
        }
    }
}
