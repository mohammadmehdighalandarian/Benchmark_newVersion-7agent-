namespace Benchmarks.csharp_31.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Returns true if the given number is the multiplication of 3 prime numbers
    /// and false otherwise.
    /// </summary>
    public static bool IsMultiplyPrime(int a)
    {
        if (a < 8) return false;

        int count = 0;
        int temp = a;

        // Iterate through potential factors starting from the smallest prime (2)
        for (int i = 2; i <= temp; i++)
        {
            // If i is a factor, divide temp by i as many times as possible
            // The first factor found is guaranteed to be prime
            while (temp % i == 0)
            {
                count++;
                temp /= i;
            }
        }

        // Return true if the total count of prime factors is exactly 3
        return count == 3;
    }
}
}
