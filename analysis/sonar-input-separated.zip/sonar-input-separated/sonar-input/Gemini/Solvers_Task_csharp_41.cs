namespace Benchmarks.csharp_41.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
/// <summary>
/// Given a dictionary, return True if all keys are strings in lower
/// case or all keys are strings in upper case, else return False.
/// The function should return False if the given dictionary is empty.
/// </summary>
public static bool CheckDictCase(Dictionary<object, string> dict)
{
if (dict == null || dict.Count == 0)
{
return false;
}


    bool allLower = true;
    bool allUpper = true;

    foreach (var key in dict.Keys)
    {
        if (key is string s)
        {
            if (s != s.ToLower())
            {
                allLower = false;
            }
            if (s != s.ToUpper())
            {
                allUpper = false;
            }
        }
        else
        {
            // Key is not a string
            return false;
        }
    }

    return allLower || allUpper;
}



}
}
