namespace Benchmarks.csharp_42.Gemini
{
using System;
using System.Globalization;

public class Solver
{
    public static int ClosestInteger(string value)
    {
        double parsedValue = double.Parse(value, CultureInfo.InvariantCulture);
        return (int)Math.Round(parsedValue, MidpointRounding.AwayFromZero);
    }
}
}
