namespace Benchmarks.csharp_69.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// You are given a positive integer n. You have to create an integer array a of length n.
    /// For each i (1 ≤ i ≤ n), the value of a[i] = i * i - i + 1.
    /// Return the number of triples (a[i], a[j], a[k]) of a where i < j < k, 
    /// and a[i] + a[j] + a[k] is a multiple of 3.
    /// </summary>
    public static int GetMaxTriples(int n)
    {
        // Instead of building the full array, we only care about the remainders modulo 3.
        // a[i] = i^2 - i + 1
        // We need (a[i] + a[j] + a[k]) % 3 == 0
        
        long count0 = 0;
        long count1 = 0;
        long count2 = 0;

        for (int i = 1; i <= n; i++)
        {
            // Use long to prevent overflow during calculation, though i is small.
            long val = (long)i * i - i + 1;
            long remainder = val % 3;

            if (remainder == 0) count0++;
            else if (remainder == 1) count1++;
            else count2++;
        }

        // To make the sum a multiple of 3, the remainders must be:
        // 1. All three are the same (0+0+0, 1+1+1, 2+2+2)
        // 2. All three are different (0+1+2)

        long triples = 0;

        // Case 1: All same
        triples += (count0 * (count0 - 1) * (count0 - 2)) / 6;
        triples += (count1 * (count1 - 1) * (count1 - 2)) / 6;
        triples += (count2 * (count2 - 1) * (count2 - 2)) / 6;

        // Case 2: All different
        triples += count0 * count1 * count2;

        return (int)triples;
    }
}
}
