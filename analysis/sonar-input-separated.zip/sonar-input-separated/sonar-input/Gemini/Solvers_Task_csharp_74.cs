namespace Benchmarks.csharp_74.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    /// <summary> 
    /// You're an expert C# programmer
    /// You are given 2 words. You need to return True if the second word or any of its rotations is a substring in the first word
    /// CycpatternCheck("abcd","abd") => False
    /// CycpatternCheck("hello","ell") => True
    /// CycpatternCheck("whassup","psus") => False
    /// CycpatternCheck("abab","baa") => True
    /// CycpatternCheck("efef","eeff") => False
    /// CycpatternCheck("himenss","simen") => True
    /// </summary>
    public static bool CycpatternCheck(string a, string b)
    {
        if (string.IsNullOrEmpty(b)) return true;
        if (b.Length > a.Length) return false;

        int n = b.Length;
        for (int i = 0; i < n; i++)
        {
            // Generate rotation starting at index i
            string rotation = b.Substring(i) + b.Substring(0, i);
            if (a.Contains(rotation))
            {
                return true;
            }
        }

        return false;
    }
}
}
