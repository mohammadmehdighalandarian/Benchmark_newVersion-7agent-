namespace Benchmarks.csharp_2.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class Solver
{
    /// <summary> 
    /// Input are two strings a and b consisting only of 1s and 0s.
    /// Perform binary XOR on these inputs and return result also as a string.
    /// >>> StringXor('010', '110')
    /// '100'
    /// </summary>
    public static string StringXor(string a, string b)
    {
        if (a == null || b == null) return null;
        
        char[] result = new char[a.Length];
        for (int i = 0; i < a.Length; i++)
        {
            // XOR logic: result is '0' if characters are the same, '1' if they are different
            result[i] = (a[i] == b[i]) ? '0' : '1';
        }
        
        return new string(result);
    }
}
}
