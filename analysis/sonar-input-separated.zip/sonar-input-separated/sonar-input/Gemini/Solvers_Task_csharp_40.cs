namespace Benchmarks.csharp_40.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Finds the largest prime value in a list of integers and returns the sum of its digits.
    /// </summary>
    public static int Skjkasdkd(List<int> lst)
    {
        if (lst == null || lst.Count == 0)
        {
            return 0;
        }

        int? maxPrime = null;

        foreach (int num in lst)
        {
            if (IsPrime(num))
            {
                if (maxPrime == null || num > maxPrime)
                {
                    maxPrime = num;
                }
            }
        }

        if (maxPrime == null)
        {
            return 0;
        }

        return SumOfDigits(maxPrime.Value);
    }

    private static bool IsPrime(int n)
    {
        if (n < 2) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;

        int boundary = (int)Math.Floor(Math.Sqrt(n));

        for (int i = 3; i <= boundary; i += 2)
        {
            if (n % i == 0) return false;
        }

        return true;
    }

    private static int SumOfDigits(int n)
    {
        int sum = 0;
        int absN = Math.Abs(n);
        while (absN > 0)
        {
            sum += absN % 10;
            absN /= 10;
        }
        return sum;
    }
}
}
