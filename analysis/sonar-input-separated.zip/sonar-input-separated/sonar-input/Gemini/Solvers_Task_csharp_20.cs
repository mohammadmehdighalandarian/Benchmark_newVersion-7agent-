namespace Benchmarks.csharp_20.Gemini
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        /// <summary> 
        /// Check if two words have the same characters.
        /// </summary>
        public static bool SameChars(string s0, string s1)
        {
            if (s0 == null || s1 == null)
            {
                return s0 == s1;
            }

            HashSet<char> set0 = new HashSet<char>(s0);
            HashSet<char> set1 = new HashSet<char>(s1);

            return set0.SetEquals(set1);
        }
    }
}
