namespace Benchmarks.csharp_11.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int PrimeFib(int n)
    {
        int count = 0;
        long a = 0;
        long b = 1;

        while (true)
        {
            long next = a + b;
            a = b;
            b = next;

            if (IsPrime(b))
            {
                count++;
                if (count == n)
                {
                    return (int)b;
                }
            }
        }
    }

    private static bool IsPrime(long number)
    {
        if (number <= 1) return false;
        if (number == 2 || number == 3) return true;
        if (number % 2 == 0 || number % 3 == 0) return false;

        for (long i = 5; i * i <= number; i += 6)
        {
            if (number % i == 0 || number % (i + 2) == 0)
                return false;
        }

        return true;
    }
}
}
