namespace Benchmarks.csharp_72.Gemini
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    /// <summary> 
    /// Given a list of numbers, return the sum of squares of the numbers
    /// in the list that are odd. Ignore numbers that are negative or not integers.
    /// </summary>
    public static int DoubleTheDifference(List<object> lst)
    {
        if (lst == null || lst.Count == 0)
        {
            return 0;
        }

        int sum = 0;

        foreach (var item in lst)
        {
            // Check if the item is a numeric type that can represent an integer
            // and ensure it is actually an integer value (not 1.5, etc.)
            if (IsIntegerType(item))
            {
                int val = Convert.ToInt32(item);

                // Ignore negative numbers
                if (val >= 0)
                {
                    // Check if the number is odd
                    if (val % 2 != 0)
                    {
                        sum += val * val;
                    }
                }
            }
        }

        return sum;
    }

    private static bool IsIntegerType(object value)
    {
        if (value == null) return false;

        // Check if it's a standard integral type
        if (value is int || value is long || value is short || value is sbyte ||
            value is uint || value is ulong || value is ushort || value is byte)
        {
            return true;
        }

        // Check if it's a floating point type but contains an integer value
        if (value is double d)
        {
            return d >= 0 && d == Math.Floor(d) && !double.IsInfinity(d) && !double.IsNaN(d);
        }
        if (value is float f)
        {
            return f >= 0 && f == (float)Math.Floor(f) && !float.IsInfinity(f) && !float.IsNaN(f);
        }
        if (value is decimal dec)
        {
            return dec >= 0 && dec == Math.Floor(dec);
        }

        return false;
    }
}
}
