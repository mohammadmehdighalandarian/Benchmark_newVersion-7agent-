namespace Benchmarks.csharp_25.Gemini
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        /// <summary> 
        /// xs represent coefficients of a polynomial.
        /// xs[0] + xs[1] * x + xs[2] * x^2 + ....
        /// Return Derivative of this polynomial in the same form.
        /// </summary>
        public static List<int> Derivative(List<int> xs)
        {
            List<int> result = new List<int>();

            // The derivative of a constant (xs[0]) is 0.
            // For i > 0, the derivative of xs[i] * x^i is (i * xs[i]) * x^(i-1).
            for (int i = 1; i < xs.Count; i++)
            {
                result.Add(xs[i] * i);
            }

            return result;
        }
    }
}
