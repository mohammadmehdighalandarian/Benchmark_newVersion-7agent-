param(
    [string]$Url = "http://localhost:9000",
    [string]$Projects = "benchmark-deepseek,benchmark-mistral,benchmark-llama",
    [string]$Output = ".\sonar_export"
)

$ErrorActionPreference = "Stop"
$Url = $Url.TrimEnd('/')

if (-not $env:SONAR_TOKEN) {
    $secure = Read-Host "Enter SonarQube token" -AsSecureString
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try {
        $token = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
    }
}
else {
    $token = $env:SONAR_TOKEN
}

if ([string]::IsNullOrWhiteSpace($token)) {
    throw "A SonarQube token is required. Set SONAR_TOKEN or enter a token when prompted."
}

$pair = "{0}:" -f $token
$encoded = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($pair))
$headers = @{ Authorization = "Basic $encoded" }

New-Item -ItemType Directory -Force -Path $Output | Out-Null

function Get-Sonar([string]$Path, [hashtable]$Query = @{}) {
    $parts = @()
    foreach ($key in $Query.Keys) {
        $value = [Uri]::EscapeDataString([string]$Query[$key])
        $parts += "{0}={1}" -f $key, $value
    }

    $uri = "$Url$Path"
    if ($parts.Count -gt 0) {
        $uri += "?" + ($parts -join "&")
    }

    Invoke-RestMethod -Uri $uri -Headers $headers -Method Get -TimeoutSec 120
}

function Save-Json($Object, [string]$File) {
    $Object | ConvertTo-Json -Depth 30 | Set-Content -Path $File -Encoding UTF8
}

function Get-AllPages([string]$Path, [hashtable]$Query, [string]$ArrayProperty) {
    $all = @()
    $page = 1

    do {
        $Query["p"] = $page
        $response = Get-Sonar $Path $Query
        $items = @($response.$ArrayProperty)

        foreach ($item in $items) {
            $all += $item
        }

        $total = 0
        $pageSize = 0
        if ($null -ne $response.paging) {
            $total = [int]$response.paging.total
            $pageSize = [int]$response.paging.pageSize
        }

        if ($total -eq 0) {
            $total = $all.Count
        }

        Write-Host "$Path page $page : $($all.Count)/$total"

        if ($items.Count -eq 0 -or $all.Count -ge $total -or $pageSize -le 0) {
            break
        }

        $page++
    } while ($true)

    return $all
}

# Verify connection and permissions before exporting.
$version = Get-Sonar "/api/server/version"
Write-Host "Connected to SonarQube $version"

$projectKeys = @(
    $Projects -split ',' |
    ForEach-Object { $_.Trim() } |
    Where-Object { $_ }
)

if ($projectKeys.Count -eq 0) {
    throw "No project keys were provided."
}

$manifest = @()

foreach ($project in $projectKeys) {
    Write-Host "`n=== Exporting $project ===" -ForegroundColor Cyan
    $safe = $project -replace '[^A-Za-z0-9_.-]', '_'

    $projectInfo = Get-Sonar "/api/projects/search" @{ projects = $project; ps = 100; p = 1 }
    Save-Json $projectInfo (Join-Path $Output "project__$safe.json")

    $issues = Get-AllPages `
        "/api/issues/search" `
        @{ componentKeys = $project; ps = 500; statuses = "OPEN,CONFIRMED,REOPENED,RESOLVED,CLOSED" } `
        "issues"

    Save-Json `
        @{ project = $project; total = $issues.Count; issues = $issues } `
        (Join-Path $Output "issues__$safe.json")

    # Some SonarQube editions/versions do not expose component_tree to the
    # current token or return 404 for this endpoint. Keep the export running;
    # write an explicit placeholder so the missing data is documented.
    $metricKeys = "bugs,vulnerabilities,code_smells,security_hotspots,violations,complexity,cognitive_complexity,duplicated_lines_density,duplicated_blocks,technical_debt,comment_lines_density,ncloc,lines,functions,classes,files"

    try {
        $measures = Get-AllPages `
            "/api/measures/component_tree" `
            @{ component = $project; metricKeys = $metricKeys; qualifiers = "FIL"; ps = 500 } `
            "components"

        Save-Json `
            @{ project = $project; total = $measures.Count; components = $measures; available = $true } `
            (Join-Path $Output "measures_files__$safe.json")
    }
    catch {
        $message = $_.Exception.Message
        Write-Warning "Could not export file measures for $project. Continuing without this file."
        Write-Warning $message

        Save-Json `
            @{ project = $project; total = 0; components = @(); available = $false; error = $message } `
            (Join-Path $Output "measures_files__$safe.json")
    }

    $profiles = Get-Sonar "/api/qualityprofiles/search" @{ project = $project }
    Save-Json $profiles (Join-Path $Output "qualityprofiles__$safe.json")

    $rules = Get-AllPages `
        "/api/rules/search" `
        @{ languages = "cs"; ps = 500; activation = "true" } `
        "rules"

    Save-Json `
        @{ project = $project; total = $rules.Count; rules = $rules } `
        (Join-Path $Output "rules__$safe.json")

    $projectName = $project
    if ($null -ne $projectInfo.components -and @($projectInfo.components).Count -gt 0) {
        $projectName = @($projectInfo.components)[0].name
    }

    $manifest += [PSCustomObject]@{
        project_key = $project
        project_name = $projectName
        source_file_pattern = "Solvers_Task_csharp_*.cs"
        expected_source_files = 80
    }
}

Save-Json `
    @{ exported_at = (Get-Date).ToUniversalTime().ToString("o"); sonar_url = $Url; projects = $manifest } `
    (Join-Path $Output "manifest.json")

Write-Host "`nExport complete: $Output" -ForegroundColor Green
Get-ChildItem $Output -File |
    Select-Object Name, Length |
    Format-Table -AutoSize
