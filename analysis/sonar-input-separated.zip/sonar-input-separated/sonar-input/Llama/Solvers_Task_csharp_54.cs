namespace Benchmarks.csharp_54.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static List<int> Maximum(List<int> arr, int k) 
    {
        return arr.OrderByDescending(x => x).Take(k).OrderBy(x => x).ToList();
    }
}
}
