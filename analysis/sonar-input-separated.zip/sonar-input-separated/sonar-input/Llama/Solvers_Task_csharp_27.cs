namespace Benchmarks.csharp_27.Llama
{
    using System;
    using System.Linq;

    public class Solver
    {
        public static int VowelsCount(string s)
        {
            int count = 0;
            string lowerS = s.ToLower();
            char[] vowels = { 'a', 'e', 'i', 'o', 'u' };

            for (int i = 0; i < lowerS.Length; i++)
            {
                char c = lowerS[i];
                if (vowels.Contains(c))
                {
                    count++;
                }
                else if (c == 'y' && i == lowerS.Length - 1)
                {
                    count++;
                }
            }

            return count;
        }
    }
}
