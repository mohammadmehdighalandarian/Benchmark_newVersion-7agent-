namespace Benchmarks.csharp_66.Llama
{
using System;

public class Solver 
{
    public static bool Simplify(string x, string n) 
    {
        var partsX = x.Split('/');
        var partsN = n.Split('/');

        long numeratorX = long.Parse(partsX[0]);
        long denominatorX = long.Parse(partsX[1]);

        long numeratorN = long.Parse(partsN[0]);
        long denominatorN = long.Parse(partsN[1]);

        long productNumerator = numeratorX * numeratorN;
        long productDenominator = denominatorX * denominatorN;

        return productNumerator % productDenominator == 0;
    }
}
}
