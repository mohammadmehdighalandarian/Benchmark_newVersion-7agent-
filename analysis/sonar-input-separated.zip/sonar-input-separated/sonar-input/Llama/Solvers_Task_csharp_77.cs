namespace Benchmarks.csharp_77.Llama
{
using System;
using System.Linq;
using System.Text;

public class Solver
{
    public static string Solve(string s)
    {
        if (s == null)
        {
            return null;
        }

        bool containsLetters = s.Any(Char.IsLetter);

        if (!containsLetters)
        {
            char[] charArray = s.ToCharArray();
            Array.Reverse(charArray);
            return new string(charArray);
        }
        else
        {
            StringBuilder result = new StringBuilder();
            foreach (char c in s)
            {
                if (Char.IsLetter(c))
                {
                    if (Char.IsLower(c))
                    {
                        result.Append(Char.ToUpper(c));
                    }
                    else
                    {
                        result.Append(Char.ToLower(c));
                    }
                }
                else
                {
                    result.Append(c);
                }
            }
            return result.ToString();
        }
    }
}
}
