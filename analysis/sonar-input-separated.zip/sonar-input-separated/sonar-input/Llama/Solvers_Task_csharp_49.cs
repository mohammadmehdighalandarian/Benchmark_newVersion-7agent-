namespace Benchmarks.csharp_49.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool MoveOneBall(List<int> arr)
    {
        if (arr.Count == 0) return true;
        var sortedArr = arr.OrderBy(x => x).ToList();
        for (int i = 0; i < arr.Count; i++)
        {
            if (arr.SequenceEqual(sortedArr)) return true;
            arr.Insert(0, arr[arr.Count - 1]);
            arr.RemoveAt(arr.Count - 1);
        }
        return false;
    }
}
}
