namespace Benchmarks.csharp_76.Llama
{
using System;
using System.Linq;

public class Solver
{
    public static bool RightAngleTriangle(int a, int b, int c)
    {
        var sides = new[] { a, b, c }.OrderBy(x => x).ToArray();
        return sides[0] > 0 && Math.Pow(sides[0], 2) + Math.Pow(sides[1], 2) == Math.Pow(sides[2], 2);
    }
}
}
