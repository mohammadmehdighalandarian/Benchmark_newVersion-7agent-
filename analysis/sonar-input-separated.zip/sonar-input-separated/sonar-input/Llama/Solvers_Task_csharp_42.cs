namespace Benchmarks.csharp_42.Llama
{
using System;

public class Solver 
{
    public static int ClosestInteger(string value) 
    {
        double number = double.Parse(value);
        double floor = Math.Floor(number);
        double ceil = Math.Ceiling(number);
        double diffFloor = Math.Abs(number - floor);
        double diffCeil = Math.Abs(ceil - number);
        if (diffFloor < diffCeil) 
        {
            return (int)floor;
        } 
        else if (diffFloor > diffCeil) 
        {
            return (int)ceil;
        } 
        else 
        {
            return number < 0 ? (int)floor : (int)ceil;
        }
    }
}
}
