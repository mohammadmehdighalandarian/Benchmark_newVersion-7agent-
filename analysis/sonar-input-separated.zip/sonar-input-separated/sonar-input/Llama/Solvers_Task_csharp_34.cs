namespace Benchmarks.csharp_34.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<string> NumericalLetterGrade(List<object> grades)
    {
        return grades.Select(gpa => Convert.ToDouble(gpa)).Select(MapGpaToGrade).ToList();
    }

    private static string MapGpaToGrade(double gpa)
    {
        if (gpa == 4.0) return "A+";
        if (gpa > 3.7) return "A";
        if (gpa > 3.3) return "A-";
        if (gpa > 3.0) return "B+";
        if (gpa > 2.7) return "B";
        if (gpa > 2.3) return "B-";
        if (gpa > 2.0) return "C+";
        if (gpa > 1.7) return "C";
        if (gpa > 1.3) return "C-";
        if (gpa > 1.0) return "D+";
        if (gpa > 0.7) return "D";
        if (gpa > 0.0) return "D-";
        return "E";
    }
}
}
