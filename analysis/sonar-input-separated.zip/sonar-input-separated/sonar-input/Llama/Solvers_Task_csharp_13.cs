namespace Benchmarks.csharp_13.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static bool PairsSumToZero(List<int> l) 
    {
        var numSet = new HashSet<int>();
        foreach (var num in l) 
        {
            if (numSet.Contains(-num)) 
            {
                return true;
            }
            numSet.Add(num);
        }
        return false;
    }
}
}
