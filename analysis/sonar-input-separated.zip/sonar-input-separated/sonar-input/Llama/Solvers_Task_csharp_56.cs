namespace Benchmarks.csharp_56.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static string Intersection(List<int> interval1, List<int> interval2) 
    {
        int start1 = interval1[0];
        int end1 = interval1[1];
        int start2 = interval2[0];
        int end2 = interval2[1];

        int intersectionStart = Math.Max(start1, start2);
        int intersectionEnd = Math.Min(end1, end2);

        if (intersectionStart > intersectionEnd) 
        {
            return "NO";
        }

        int intersectionLength = intersectionEnd - intersectionStart + 1;

        if (IsPrime(intersectionLength)) 
        {
            return "YES";
        } 
        else 
        {
            return "NO";
        }
    }

    private static bool IsPrime(int number) 
    {
        if (number <= 1) return false;
        if (number == 2) return true;
        if (number % 2 == 0) return false;

        var boundary = (int)Math.Floor(Math.Sqrt(number));

        for (int i = 3; i <= boundary; i += 2) 
        {
            if (number % i == 0) return false;
        }

        return true;
    }
}
}
