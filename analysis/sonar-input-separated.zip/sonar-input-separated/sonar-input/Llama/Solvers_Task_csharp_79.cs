namespace Benchmarks.csharp_79.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static List<int> GenerateIntegers(int a, int b) 
    {
        int start = Math.Min(a, b);
        int end = Math.Max(a, b);
        return Enumerable.Range(start, end - start + 1).Where(x => x % 2 == 0).ToList();
    }
}
}
