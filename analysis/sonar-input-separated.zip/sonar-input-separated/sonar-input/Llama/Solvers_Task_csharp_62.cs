namespace Benchmarks.csharp_62.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int CanArrange(List<int> arr)
    {
        int result = -1;
        for (int i = 1; i < arr.Count; i++)
        {
            if (arr[i] < arr[i - 1])
            {
                result = i;
            }
        }
        return result;
    }
}
}
