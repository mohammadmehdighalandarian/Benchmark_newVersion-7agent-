namespace Benchmarks.csharp_11.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static int PrimeFib(int n) 
    {
        int count = 0;
        int a = 0;
        int b = 1;
        while (true) 
        {
            int fib = a + b;
            a = b;
            b = fib;
            if (IsPrime(fib)) 
            {
                count++;
                if (count == n) 
                {
                    return fib;
                }
            }
        }
    }

    public static bool IsPrime(int number) 
    {
        if (number <= 1) return false;
        if (number == 2) return true;
        if (number % 2 == 0) return false;

        var boundary = (int)Math.Floor(Math.Sqrt(number));

        for (int i = 3; i <= boundary; i += 2)
        {
            if (number % i == 0) return false;
        }

        return true;
    }
}
}
