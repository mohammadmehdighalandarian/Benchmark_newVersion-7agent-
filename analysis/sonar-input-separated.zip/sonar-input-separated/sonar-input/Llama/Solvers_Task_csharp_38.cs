namespace Benchmarks.csharp_38.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static object NextSmallest(List<int> lst)
    {
        var distinctElements = lst.Distinct().OrderBy(x => x).ToList();
        return distinctElements.Count >= 2 ? (object)distinctElements[1] : null;
    }
}
}
