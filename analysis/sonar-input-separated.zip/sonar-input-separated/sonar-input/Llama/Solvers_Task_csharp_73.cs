namespace Benchmarks.csharp_73.Llama
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static string StrongestExtension(string class_name, List<string> extensions)
        {
            int maxStrength = int.MinValue;
            string strongestExtension = null;

            foreach (var extension in extensions)
            {
                int cap = extension.Count(char.IsUpper);
                int sm = extension.Count(char.IsLower);
                int strength = cap - sm;

                if (strength > maxStrength)
                {
                    maxStrength = strength;
                    strongestExtension = extension;
                }
            }

            return $"{class_name}.{strongestExtension}";
        }
    }
}
