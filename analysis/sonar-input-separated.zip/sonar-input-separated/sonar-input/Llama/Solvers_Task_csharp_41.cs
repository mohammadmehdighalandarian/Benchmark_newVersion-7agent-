namespace Benchmarks.csharp_41.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static bool CheckDictCase(Dictionary<object, string> dict) 
    {
        if (dict.Count == 0) return false;

        bool allLower = true;
        bool allUpper = true;

        foreach (var key in dict.Keys) 
        {
            if (!(key is string)) return false;
            string strKey = (string)key;
            if (!strKey.All(char.IsLower)) allLower = false;
            if (!strKey.All(char.IsUpper)) allUpper = false;
        }

        return allLower || allUpper;
    }
}
}
