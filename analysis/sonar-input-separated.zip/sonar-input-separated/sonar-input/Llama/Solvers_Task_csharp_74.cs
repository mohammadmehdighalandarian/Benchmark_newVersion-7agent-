namespace Benchmarks.csharp_74.Llama
{
using System;
using System.Linq;

public class Solver 
{
    public static bool CycpatternCheck(string a, string b) 
    {
        if (a.Length < b.Length) return false;
        string rotatedB = b + b;
        return rotatedB.Contains(a.Substring(0, b.Length)) && a.Contains(b);
    }
}
}
