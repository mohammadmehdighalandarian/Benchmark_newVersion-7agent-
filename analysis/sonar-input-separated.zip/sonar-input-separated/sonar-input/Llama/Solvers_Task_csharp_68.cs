namespace Benchmarks.csharp_68.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static int SpecialFilter(List<int> nums) 
    {
        return nums.Count(num => num > 10 && IsFirstAndLastDigitOdd(num));
    }

    private static bool IsFirstAndLastDigitOdd(int num) 
    {
        var numStr = Math.Abs(num).ToString();
        return int.Parse(numStr[0].ToString()) % 2 != 0 && int.Parse(numStr[numStr.Length - 1].ToString()) % 2 != 0;
    }
}
}
