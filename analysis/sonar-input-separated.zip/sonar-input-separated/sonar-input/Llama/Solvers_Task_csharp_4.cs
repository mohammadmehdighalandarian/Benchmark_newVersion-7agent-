namespace Benchmarks.csharp_4.Llama
{
using System;

public class Solver 
{
    public static int GreatestCommonDivisor(int a, int b) 
    {
        while (b != 0) 
        {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return Math.Abs(a);
    }
}
}
