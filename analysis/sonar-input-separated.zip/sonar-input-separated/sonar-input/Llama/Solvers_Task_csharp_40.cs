namespace Benchmarks.csharp_40.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static int Skjkasdkd(List<int> lst) 
    {
        int maxPrime = lst.Where(IsPrime).DefaultIfEmpty(0).Max();
        return SumOfDigits(maxPrime);
    }

    private static bool IsPrime(int n) 
    {
        if (n <= 1) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;

        var boundary = (int)Math.Floor(Math.Sqrt(n));

        for (int i = 3; i <= boundary; i += 2)
        {
            if (n % i == 0) return false;
        }

        return true;
    }

    private static int SumOfDigits(int n) 
    {
        return Math.Abs(n).ToString().Select(c => int.Parse(c.ToString())).Sum();
    }
}
}
