﻿namespace Benchmarks.csharp_57.Llama
{
    using System;
    using System.Collections.Generic;

    public class Solver
    {
        public static List<object> Tri(int n)
        {
            throw new InvalidOperationException();
        }
    }
}

