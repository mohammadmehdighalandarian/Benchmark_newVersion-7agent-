namespace Benchmarks.csharp_45.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static int ChooseNum(int x, int y) 
    {
        if (x > y) return -1;
        int max = Math.Max(x, y);
        int min = Math.Min(x, y);
        int biggestEven = max - (max % 2);
        return biggestEven >= min ? biggestEven : -1;
    }
}
}
