﻿namespace Benchmarks.csharp_19.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
public class Solver
{
    public static int Add(int x, int y)
    {
        return x + y;
    }
}
}

