namespace Benchmarks.csharp_6.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<double> RescaleToUnit(List<double> numbers)
    {
        double min = numbers.Min();
        double max = numbers.Max();
        return numbers.Select(n => (n - min) / (max - min)).ToList();
    }
}
}
