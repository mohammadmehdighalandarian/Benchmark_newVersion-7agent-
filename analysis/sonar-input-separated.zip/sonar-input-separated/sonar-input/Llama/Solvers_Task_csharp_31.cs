namespace Benchmarks.csharp_31.Llama
{
using System;
using System.Linq;

public class Solver
{
    public static bool IsMultiplyPrime(int a)
    {
        // Precompute prime numbers less than 100
        bool[] primes = new bool[100];
        for (int i = 0; i < 100; i++)
            primes[i] = true;
        primes[0] = primes[1] = false;
        for (int i = 2; i * i < 100; i++)
        {
            if (primes[i])
            {
                for (int j = i * i; j < 100; j += i)
                    primes[j] = false;
            }
        }

        // Check all combinations of three prime numbers
        for (int i = 2; i < 100; i++)
        {
            if (primes[i] && a % i == 0)
            {
                int quotient = a / i;
                for (int j = i; j < 100; j++)
                {
                    if (primes[j] && quotient % j == 0)
                    {
                        int last = quotient / j;
                        if (primes[last])
                            return true;
                    }
                }
            }
        }
        return false;
    }
}
}
