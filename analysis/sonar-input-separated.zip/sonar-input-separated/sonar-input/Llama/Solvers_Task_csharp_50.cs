namespace Benchmarks.csharp_50.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static string Exchange(List<int> lst1, List<int> lst2) 
    {
        int countOddLst1 = lst1.Count(x => x % 2 != 0);
        int countEvenLst2 = lst2.Count(x => x % 2 == 0);
        return countOddLst1 <= countEvenLst2 ? "YES" : "NO";
    }
}
}
