namespace Benchmarks.csharp_51.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static List<object> ReverseDelete(string s, string c) 
    {
        var resultString = new string(s.Where(ch => !c.Contains(ch)).ToArray());
        var isPalindrome = resultString.SequenceEqual(resultString.Reverse());
        return new List<object> { resultString, isPalindrome };
    }
}
}
