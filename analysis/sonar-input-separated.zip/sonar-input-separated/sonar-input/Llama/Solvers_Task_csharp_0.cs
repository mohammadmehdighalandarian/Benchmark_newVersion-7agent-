namespace Benchmarks.csharp_0.Llama
{
using System;
using System.Collections.Generic;

public class Solver 
{
    public static bool BelowZero(List<int> operations) 
    {
        int balance = 0;
        foreach (var operation in operations) 
        {
            balance += operation;
            if (balance < 0) 
            {
                return true;
            }
        }
        return false;
    }
}
}
