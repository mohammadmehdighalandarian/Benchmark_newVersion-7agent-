namespace Benchmarks.csharp_25.Llama
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static List<int> Derivative(List<int> xs)
        {
            return xs.Select((x, i) => new { Coefficient = x, Power = i })
                .Where(x => x.Power > 0)
                .Select(x => x.Coefficient * x.Power)
                .ToList();
        }
    }
}
