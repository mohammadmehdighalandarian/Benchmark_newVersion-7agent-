namespace Benchmarks.csharp_30.Llama
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static bool WillItFly(List<int> q, int w)
        {
            // Check if the list is balanced (palindromic)
            bool isPalindromic = true;
            for (int i = 0; i < q.Count / 2; i++)
            {
                if (q[i] != q[q.Count - 1 - i])
                {
                    isPalindromic = false;
                    break;
                }
            }

            // Calculate the sum of elements
            long sum = 0;
            foreach (int item in q)
            {
                sum += item;
            }

            // Check if the sum is less than or equal to the maximum possible weight
            bool withinWeightLimit = sum <= w;

            return isPalindromic && withinWeightLimit;
        }
    }
}
