namespace Benchmarks.csharp_71.Llama
{
using System;

public class Solver 
{
    public static int XOrY(int n, int x, int y) 
    {
        if (n <= 1) return y;
        for (int i = 2; i * i <= n; i++) 
        {
            if (n % i == 0) return y;
        }
        return x;
    }
}
}
