namespace Benchmarks.csharp_20.Llama
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static bool SameChars(string s0, string s1)
        {
            var dict0 = s0.GroupBy(c => c).ToDictionary(g => g.Key, g => g.Count());
            var dict1 = s1.GroupBy(c => c).ToDictionary(g => g.Key, g => g.Count());

            return dict0.Keys.All(k => dict1.ContainsKey(k) && dict1[k] >= dict0[k])
                   && dict1.Keys.All(k => dict0.ContainsKey(k) && dict0[k] <= dict1[k]);
        }
    }
}
