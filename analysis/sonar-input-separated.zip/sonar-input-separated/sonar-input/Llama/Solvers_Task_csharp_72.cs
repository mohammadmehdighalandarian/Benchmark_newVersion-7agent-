namespace Benchmarks.csharp_72.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static int DoubleTheDifference(List<object> lst) 
    {
        return lst.Where(x => x is int && (int)x >= 0 && (int)x % 2 != 0).Select(x => (int)x * (int)x).Sum();
    }
}
}
