namespace Benchmarks.csharp_69.Llama
{
using System;

public class Solver 
{
    public static int GetMaxTriples(int n) 
    {
        int count1 = 0, count2 = 0, count0 = 0;
        for (int i = 1; i <= n; i++) 
        {
            int remainder = (i * i - i + 1) % 3;
            if (remainder == 1) count1++;
            else if (remainder == 2) count2++;
            else count0++;
        }
        return count1 * count2 * count0 + (count0 * (count0 - 1) * (count0 - 2)) / 6 + (count1 * (count1 - 1) * (count1 - 2)) / 6 + (count2 * (count2 - 1) * (count2 - 2)) / 6;
    }
}
}
