namespace Benchmarks.csharp_64.Llama
{
using System;

public class Solver 
{
    public static int SpecialFactorial(int n) 
    {
        long result = 1;
        for (int i = 1; i <= n; i++) 
        {
            long factorial = 1;
            for (int j = 1; j <= i; j++) 
            {
                factorial *= j;
            }
            result *= factorial;
            if (result > int.MaxValue) 
            {
                throw new OverflowException();
            }
        }
        return (int)result;
    }
}
}
