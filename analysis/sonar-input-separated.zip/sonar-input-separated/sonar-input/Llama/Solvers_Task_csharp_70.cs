namespace Benchmarks.csharp_70.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<string> Bf(string planet1, string planet2)
    {
        string[] planets = { "Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune" };
        if (!planets.Contains(planet1) || !planets.Contains(planet2))
            return new List<string>();

        int index1 = Array.IndexOf(planets, planet1);
        int index2 = Array.IndexOf(planets, planet2);

        int start = Math.Min(index1, index2);
        int end = Math.Max(index1, index2);

        return planets.Skip(start + 1).Take(end - start - 1).ToList();
    }
}
}
