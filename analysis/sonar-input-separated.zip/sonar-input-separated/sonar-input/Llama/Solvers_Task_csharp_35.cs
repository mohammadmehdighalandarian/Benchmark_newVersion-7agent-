namespace Benchmarks.csharp_35.Llama
{
using System;

public class Solver 
{
    public static bool PrimeLength(string string0) 
    {
        int length = string0.Length;
        if (length <= 1) return false;
        for (int i = 2; i * i <= length; i++) 
        {
            if (length % i == 0) return false;
        }
        return true;
    }
}
}
