namespace Benchmarks.csharp_17.Llama
{
using System;
using System.Linq;

public class Solver 
{
    public static string RemoveVowels(string text) 
    {
        return new string(text.Where(c => !"aeiouAEIOU".Contains(c)).ToArray());
    }
}
}
