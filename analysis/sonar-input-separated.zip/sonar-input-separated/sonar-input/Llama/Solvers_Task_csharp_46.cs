namespace Benchmarks.csharp_46.Llama
{
using System;
using System.Linq;

public class Solver 
{
    public static object RoundedAvg(int n, int m) 
    {
        if (n > m) return -1;
        var count = m - n + 1;
        var sum = (long)n * count + (long)count * (count - 1) / 2;
        var average = (int)Math.Round((double)sum / count);
        return $"0b{Convert.ToString(average, 2)}";
    }
}
}
