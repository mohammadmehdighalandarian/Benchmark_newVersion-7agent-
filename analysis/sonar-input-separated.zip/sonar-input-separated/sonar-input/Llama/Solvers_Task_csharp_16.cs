namespace Benchmarks.csharp_16.Llama
{
using System;
using System.Linq;

public class Solver
{
    public static bool IsPalindrome(string text)
    {
        var cleanedText = text.ToLower();
        var left = 0;
        var right = cleanedText.Length - 1;
        while (left < right)
        {
            if (cleanedText[left] != cleanedText[right])
                return false;
            left++;
            right--;
        }
        return true;
    }
}
}
