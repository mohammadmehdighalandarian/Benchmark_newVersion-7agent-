namespace Benchmarks.csharp_59.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static bool IsNested(string string0) 
    {
        int count = 0;
        foreach (char c in string0) 
        {
            if (c == '[') 
            {
                count++;
            } 
            else if (c == ']') 
            {
                count--;
                if (count < 0) return false;
                if (count > 0) return true;
            }
        }
        return false;
    }
}
}
