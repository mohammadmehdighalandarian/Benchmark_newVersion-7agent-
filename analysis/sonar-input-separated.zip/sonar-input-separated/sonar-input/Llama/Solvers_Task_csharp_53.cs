namespace Benchmarks.csharp_53.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<string> SelectWords(string s, int n)
    {
        return s.Split(' ')
               .Where(word => CountConsonants(word) == n)
               .ToList();
    }

    private static int CountConsonants(string word)
    {
        return word.ToLower()
                   .Count(c => char.IsLetter(c) && !"aeiou".Contains(c));
    }
}
}
