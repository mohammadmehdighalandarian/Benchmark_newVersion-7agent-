﻿namespace Benchmarks.csharp_37.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static List<List<int>> GetRow(List<List<int>> lst, int x) 
    {
        var result = new List<(int, int)>();
        for (int i = 0; i < lst.Count; i++) 
        {
            for (int j = 0; j < lst[i].Count; j++) 
            {
                if (lst[i][j] == x) 
                {
                    result.Add((i, j));
                }
            }
        }
        throw new InvalidOperationException();
    }
}
}

