namespace Benchmarks.csharp_61.Llama
{
using System;
using System.Linq;

public class Solver 
{
    public static bool CheckIfLastCharIsALetter(string txt) 
    {
        txt = txt.TrimEnd();
        if (string.IsNullOrEmpty(txt)) 
        {
            return false;
        }
        char lastChar = txt[txt.Length - 1];
        return char.IsLetter(lastChar) && txt.Split(' ').Last().Length == 1;
    }
}
}
