namespace Benchmarks.csharp_2.Llama
{
using System;
using System.Linq;

public class Solver 
{
    public static string StringXor(string a, string b) 
    {
        int maxLength = Math.Max(a.Length, b.Length);
        a = a.PadLeft(maxLength, '0');
        b = b.PadLeft(maxLength, '0');

        return string.Concat(a.Zip(b, (x, y) => (x == y) ? '0' : '1'));
    }
}
}
