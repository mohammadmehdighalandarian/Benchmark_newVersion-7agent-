namespace Benchmarks.csharp_39.Llama
{
using System;
using System.Linq;

public class Solver
{
    public static int IsBored(string S)
    {
        int boredCount = 0;
        char[] delimiters = { '.', '?', '!' };
        string[] sentences = S.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);

        foreach (string sentence in sentences)
        {
            string trimmedSentence = sentence.Trim();
            if (trimmedSentence.StartsWith("I ", StringComparison.OrdinalIgnoreCase) || trimmedSentence.Equals("I", StringComparison.OrdinalIgnoreCase))
            {
                boredCount++;
            }
        }

        return boredCount;
    }
}
}
