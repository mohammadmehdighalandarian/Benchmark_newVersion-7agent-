namespace Benchmarks.csharp_43.Llama
{
    using System;
    using System.Collections.Generic;

    public class Solver
    {
        public static List<int> MakeAPile(int n)
        {
            List<int> result = new List<int>();
            result.Add(n);
            for (int i = 1; i < n; i++)
            {
                if (n % 2 == 0)
                {
                    n += 2;
                }
                else
                {
                    n += 2;
                }

                result.Add(n);
            }

            return result;
        }
    }
}
