namespace Benchmarks.csharp_44.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static List<string> WordsString(string s) 
    {
        return s.Replace(",", " ").Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries).ToList();
    }
}
}
