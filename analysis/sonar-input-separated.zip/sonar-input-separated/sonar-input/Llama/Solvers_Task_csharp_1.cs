namespace Benchmarks.csharp_1.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static List<int> SumProduct(List<int> numbers) 
    {
        long sum = 0;
        long product = 1;
        foreach (var number in numbers) 
        {
            sum += number;
            product *= number;
        }
        return new List<int> { (int)sum, (int)product };
    }
}
}
