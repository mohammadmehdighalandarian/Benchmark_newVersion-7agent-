namespace Benchmarks.csharp_12.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static bool TriplesSumToZero(List<int> l) 
    {
        if (l.Count < 3) return false;
        l.Sort();
        for (int i = 0; i < l.Count - 2; i++) 
        {
            if (i > 0 && l[i] == l[i - 1]) continue;
            int left = i + 1, right = l.Count - 1;
            while (left < right) 
            {
                int sum = l[i] + l[left] + l[right];
                if (sum < 0) left++;
                else if (sum > 0) right--;
                else return true;
            }
        }
        return false;
    }
}
}
