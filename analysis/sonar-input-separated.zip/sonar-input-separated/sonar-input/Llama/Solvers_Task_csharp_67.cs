namespace Benchmarks.csharp_67.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static List<int> OrderByPoints(List<int> nums) 
    {
        return nums.Select((num, index) => new { num, index })
                   .OrderBy(x => x.num.ToString().Select(c => Math.Abs(c - '0')).Sum())
                   .ThenBy(x => x.index)
                   .Select(x => x.num)
                   .ToList();
    }
}
}
