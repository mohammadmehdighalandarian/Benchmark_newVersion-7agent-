namespace Benchmarks.csharp_60.Llama
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static int SumSquares(List<object> lst)
        {
            return lst.Select(x => (int)Math.Ceiling(Convert.ToDouble(x))).Select(y => y * y).Sum();
        }
    }
}
