namespace Benchmarks.csharp_18.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static bool BelowThreshold(List<int> l, int t) 
    {
        return l.All(x => x < t);
    }
}
}
