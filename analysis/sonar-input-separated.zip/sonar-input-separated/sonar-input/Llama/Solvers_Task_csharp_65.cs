namespace Benchmarks.csharp_65.Llama
{
using System;
using System.Linq;

public class Solver 
{
    public static string WordsInSentence(string sentence) 
    {
        return string.Join(" ", sentence.Split(' ').Where(word => IsPrime(word.Length)));
    }

    private static bool IsPrime(int number) 
    {
        if (number <= 1) return false;
        if (number == 2) return true;
        if (number % 2 == 0) return false;

        var boundary = (int)Math.Floor(Math.Sqrt(number));

        for (int i = 3; i <= boundary; i += 2)
        {
            if (number % i == 0) return false;
        }

        return true;
    }
}
}
