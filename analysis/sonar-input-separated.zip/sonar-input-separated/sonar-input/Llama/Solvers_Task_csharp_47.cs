namespace Benchmarks.csharp_47.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static List<int> F(int n) 
    {
        List<int> result = new List<int>();
        for (int i = 1; i <= n; i++) 
        {
            if (i % 2 == 0) 
            {
                long factorial = 1;
                for (int j = 1; j <= i; j++) 
                {
                    factorial *= j;
                }
                result.Add((int)Math.Min(factorial, int.MaxValue));
            } 
            else 
            {
                result.Add(i * (i + 1) / 2);
            }
        }
        return result;
    }
}
}
