namespace Benchmarks.csharp_5.Llama
{
using System;
using System.Linq;

public class Solver 
{
    public static string SortNumbers(string numbers) 
    {
        var numberWords = new[] { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
        var sorted = numbers.Split(' ').OrderBy(n => Array.IndexOf(numberWords, n));
        return string.Join(" ", sorted);
    }
}
}
