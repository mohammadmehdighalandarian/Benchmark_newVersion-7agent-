namespace Benchmarks.csharp_7.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static string FlipCase(string string0)
    {
        char[] arr = string0.ToCharArray();
        for (int i = 0; i < arr.Length; i++)
        {
            if (char.IsLower(arr[i]))
                arr[i] = char.ToUpper(arr[i]);
            else if (char.IsUpper(arr[i]))
                arr[i] = char.ToLower(arr[i]);
        }
        return new string(arr);
    }
}
}
