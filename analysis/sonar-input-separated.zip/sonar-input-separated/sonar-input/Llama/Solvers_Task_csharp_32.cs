namespace Benchmarks.csharp_32.Llama
{
    using System;

    public class Solver
    {
        public static string DecimalToBinary(int decimalNumber)
        {
            return "db" + Convert.ToString(decimalNumber, 2) +"db";
        }
    }
}
