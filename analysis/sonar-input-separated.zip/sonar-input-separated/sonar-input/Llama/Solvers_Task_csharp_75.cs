namespace Benchmarks.csharp_75.Llama
{
using System;

public class Solver 
{
    public static string IntToMiniRoman(int number) 
    {
        int[] values = { 1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1 };
        string[] romanNumerals = { "m", "cm", "d", "cd", "c", "xc", "l", "xl", "x", "ix", "v", "iv", "i" };

        string result = "";
        for (int i = 0; i < values.Length; i++) 
        {
            while (number >= values[i]) 
            {
                number -= values[i];
                result += romanNumerals[i];
            }
        }
        return result;
    }
}
}
