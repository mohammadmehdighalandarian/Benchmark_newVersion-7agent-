namespace Benchmarks.csharp_78.Llama
{
using System;
using System.Security.Cryptography;
using System.Text;

public class Solver
{
    public static object StringToMd5(string text)
    {
        if (string.IsNullOrEmpty(text))
            return null;

        using var md5 = MD5.Create();
        var bytes = md5.ComputeHash(Encoding.UTF8.GetBytes(text));
        var sb = new StringBuilder();
        foreach (var b in bytes)
            sb.Append(b.ToString("x2"));
        return sb.ToString();
    }
}
}
