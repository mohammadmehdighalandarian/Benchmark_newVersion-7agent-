namespace Benchmarks.csharp_23.Llama
{
    using System;

    public class Solver
    {
        public static int LargestPrimeFactor(int n)
        {
            int largestFactor = 1;
            for (int i = 2; i * i <= n; i++)
            {
                while (n % i == 0)
                {
                    largestFactor = i;
                    n /= i;
                }
            }

            if (n > 1)
            {
                largestFactor = n;
            }

            return largestFactor;
        }
    }
}
