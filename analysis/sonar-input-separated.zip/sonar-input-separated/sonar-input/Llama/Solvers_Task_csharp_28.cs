namespace Benchmarks.csharp_28.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static int Search(List<int> lst) 
    {
        var freq = lst.GroupBy(x => x).ToDictionary(g => g.Key, g => g.Count());
        int max = -1;
        foreach (var pair in freq)
        {
            if (pair.Key <= pair.Value && pair.Key > max)
                max = pair.Key;
        }
        return max;
    }
}
}
