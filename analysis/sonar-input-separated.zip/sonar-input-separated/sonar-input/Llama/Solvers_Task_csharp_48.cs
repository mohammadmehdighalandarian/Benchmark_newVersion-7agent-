namespace Benchmarks.csharp_48.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static List<int> EvenOddPalindrome(int n) 
    {
        int evenCount = 0;
        int oddCount = 0;
        for (int i = 1; i <= n; i++) 
        {
            string numStr = i.ToString();
            if (numStr.SequenceEqual(numStr.Reverse())) 
            {
                if (i % 2 == 0) 
                {
                    evenCount++;
                } 
                else 
                {
                    oddCount++;
                }
            }
        }
        return new List<int> { evenCount, oddCount };
    }
}
}
