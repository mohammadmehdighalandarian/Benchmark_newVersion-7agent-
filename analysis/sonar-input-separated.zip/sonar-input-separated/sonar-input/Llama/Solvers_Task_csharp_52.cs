namespace Benchmarks.csharp_52.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static int MaxFill(List<List<int>> grid, int capacity) 
    {
        int count = 0;
        foreach (var well in grid) 
        {
            int waterUnits = well.Sum();
            count += (int)Math.Ceiling((double)waterUnits / capacity);
        }
        return count;
    }
}
}
