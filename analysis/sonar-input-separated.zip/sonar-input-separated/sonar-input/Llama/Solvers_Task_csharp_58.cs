namespace Benchmarks.csharp_58.Llama
{
using System;
using System.Linq;

public class Solver 
{
    public static int Digits(int n) 
    {
        int product = 1;
        bool hasOdd = false;
        foreach (char digit in n.ToString()) 
        {
            int d = int.Parse(digit.ToString());
            if (d % 2 != 0) 
            {
                hasOdd = true;
                product *= d;
            }
        }
        return hasOdd ? product : 0;
    }
}
}
