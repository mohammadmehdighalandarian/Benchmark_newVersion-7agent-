namespace Benchmarks.csharp_15.Llama
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver 
{
    public static object Median(List<int> l) 
    {
        var sortedList = l.OrderBy(x => x).ToList();
        int count = sortedList.Count;
        if (count % 2 == 0) 
        {
            return (sortedList[count / 2 - 1] + sortedList[count / 2]) / 2.0;
        } 
        else 
        {
            return sortedList[count / 2];
        }
    }
}
}
