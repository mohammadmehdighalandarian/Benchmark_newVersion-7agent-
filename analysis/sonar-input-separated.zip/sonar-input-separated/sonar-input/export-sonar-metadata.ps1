param(
    [string]$Url = "http://localhost:9000",
    [string]$Projects = "benchmark-gpt,benchmark-gemini,benchmark-claude,benchmark-grok,benchmark-mistral,benchmark-deepseek,benchmark-llama",
    [string]$Output = ".\sonar_export\metadata"
)

$ErrorActionPreference = "Stop"
$Url = $Url.TrimEnd('/')

if (-not $env:SONAR_TOKEN) {
    $secure = Read-Host "Enter SonarQube token" -AsSecureString
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { $token = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) }
    finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
} else {
    $token = $env:SONAR_TOKEN
}

$pair = "{0}:" -f $token
$encoded = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($pair))
$headers = @{ Authorization = "Basic $encoded" }
New-Item -ItemType Directory -Force -Path $Output | Out-Null

function Get-Sonar([string]$Path, [hashtable]$Query = @{}) {
    $parts = @()
    foreach ($key in $Query.Keys) {
        $parts += "{0}={1}" -f $key, [Uri]::EscapeDataString([string]$Query[$key])
    }
    $uri = "$Url$Path"
    if ($parts.Count -gt 0) { $uri += "?" + ($parts -join "&") }
    Invoke-RestMethod -Uri $uri -Headers $headers -Method Get -TimeoutSec 120
}

function Save-Json($Object, [string]$File) {
    $Object | ConvertTo-Json -Depth 30 | Set-Content -Path $File -Encoding UTF8
}

$projectKeys = @($Projects -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ })
$allRuleRows = @()
$analysisRows = @()

foreach ($project in $projectKeys) {
    Write-Host "Processing $project ..." -ForegroundColor Cyan
    $safe = $project -replace '[^A-Za-z0-9_.-]', '_'

    # Get all issues, including resolved/closed, so historical issue counts are represented.
    $issuesResponse = Get-Sonar "/api/issues/search" @{
        componentKeys = $project
        ps = 500
        statuses = "OPEN,CONFIRMED,REOPENED,RESOLVED,CLOSED"
    }
    $issues = @($issuesResponse.issues)
    $issueFile = Join-Path (Split-Path $Output -Parent) "issues__$safe.json"
    if (Test-Path $issueFile) {
        try { $issues = @((Get-Content $issueFile -Raw | ConvertFrom-Json).issues) } catch { }
    }

    $counts = @($issues | Where-Object { $_.rule } | Group-Object rule | Sort-Object Count -Descending | Select-Object -First 5)
    $topRules = @()
    foreach ($group in $counts) {
        $ruleKey = [string]$group.Name
        try {
            $ruleInfo = Get-Sonar "/api/rules/show" @{ key = $ruleKey }
            $topRules += [PSCustomObject]@{
                project = $project
                rule_key = $ruleKey
                title = [string]$ruleInfo.rule.name
                issue_count = [int]$group.Count
                severity = [string]$ruleInfo.rule.severity
                type = [string]$ruleInfo.rule.type
            }
        }
        catch {
            $topRules += [PSCustomObject]@{
                project = $project
                rule_key = $ruleKey
                title = "(Rule title unavailable)"
                issue_count = [int]$group.Count
                severity = ""
                type = ""
            }
        }
    }
    Save-Json @{ project = $project; top_5_rules = $topRules } (Join-Path $Output "top5_rules__$safe.json")
    $allRuleRows += $topRules

    # Analysis history supplies the exact server-side analysis timestamps.
    $analysis = Get-Sonar "/api/project_analyses/search" @{ project = $project; ps = 100; p = 1 }
    $analysisRows += @($analysis.analyses | ForEach-Object {
        [PSCustomObject]@{
            project = $project
            analysis_key = $_.key
            date = $_.date
            date_string = $_.date
            revision = $_.revision
            events = (@($_.events | ForEach-Object { $_.name }) -join "; ")
        }
    })
}

$globalTop = @($allRuleRows | Group-Object rule_key | Sort-Object Count -Descending | Select-Object -First 5 | ForEach-Object {
    $rows = @($_.Group)
    [PSCustomObject]@{
        rule_key = $_.Name
        title = $rows[0].title
        projects = (($rows | Select-Object -ExpandProperty project -Unique) -join ", ")
        summed_top5_project_counts = (($rows | Measure-Object issue_count -Sum).Sum)
    }
})

Save-Json @{ generated_at_utc = (Get-Date).ToUniversalTime().ToString("o"); top_5_rules_global = $globalTop } (Join-Path $Output "top5_rules_global.json")
Save-Json @{ generated_at_utc = (Get-Date).ToUniversalTime().ToString("o"); analyses = $analysisRows } (Join-Path $Output "analysis_dates.json")

Write-Host "`nTop five rules across the supplied projects:" -ForegroundColor Green
$globalTop | Format-Table -AutoSize
Write-Host "`nExact analysis dates:" -ForegroundColor Green
$analysisRows | Sort-Object project, date | Format-Table -AutoSize
Write-Host "`nFiles written to: $Output" -ForegroundColor Green
