namespace Benchmarks.csharp_41.GPT
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static bool CheckDictCase(Dictionary<object, string> dict)
    {
        if (dict == null || dict.Count == 0)
            return false;

        bool allLower = true;
        bool allUpper = true;

        foreach (var key in dict.Keys)
        {
            if (key == null || key.GetType() != typeof(string))
                return false;

            string s = (string)key;

            if (s != s.ToLower())
                allLower = false;

            if (s != s.ToUpper())
                allUpper = false;
        }

        return allLower || allUpper;
    }
}
}
