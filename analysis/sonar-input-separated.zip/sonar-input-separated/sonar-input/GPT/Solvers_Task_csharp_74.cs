namespace Benchmarks.csharp_74.GPT
{
using System;
using System.Linq;

public class Solver
{
    public static bool CycpatternCheck(string a, string b)
    {
        int n = b.Length;
        if (n == 0 || n > a.Length) return false;

        for (int i = 0; i <= a.Length - n; i++)
        {
            string sub = a.Substring(i, n);
            if ((sub + sub).Contains(b))
                return true;
        }

        return false;
    }
}
}
