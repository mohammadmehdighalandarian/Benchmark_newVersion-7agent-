namespace Benchmarks.csharp_25.GPT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static List<int> Derivative(List<int> xs)
        {
            if (xs == null || xs.Count <= 1)
                return new List<int>();

            List<int> result = new List<int>(xs.Count - 1);

            for (int i = 1; i < xs.Count; i++)
            {
                result.Add(xs[i] * i);
            }

            return result;
        }
    }
}
