namespace Benchmarks.csharp_44.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<string> WordsString(string s)
    {
        if (string.IsNullOrEmpty(s))
            return new List<string>();

        string cleaned = s.Replace(",", " ");
        string[] parts = cleaned.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

        return parts.ToList();
    }
}
}
