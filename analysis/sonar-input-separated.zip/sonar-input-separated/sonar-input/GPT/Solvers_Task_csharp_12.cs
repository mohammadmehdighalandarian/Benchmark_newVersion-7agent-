namespace Benchmarks.csharp_12.GPT
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static bool TriplesSumToZero(List<int> l)
    {
        int n = l.Count;
        if (n < 3) return false;

        l.Sort();

        for (int i = 0; i < n - 2; i++)
        {
            int left = i + 1;
            int right = n - 1;

            while (left < right)
            {
                int sum = l[i] + l[left] + l[right];

                if (sum == 0)
                    return true;
                if (sum < 0)
                    left++;
                else
                    right--;
            }
        }

        return false;
    }
}
}
