namespace Benchmarks.csharp_73.GPT
{
    using System;

    public class Solver
    {
        public static string StrongestExtension(string class_name, List<string> extensions)
        {
            string strongest = extensions[0];
            int bestStrength = Strength(strongest);

            for (int i = 1; i < extensions.Count; i++)
            {
                int currentStrength = Strength(extensions[i]);
                if (currentStrength > bestStrength)
                {
                    bestStrength = currentStrength;
                    strongest = extensions[i];
                }
            }

            return class_name + "." + strongest;
        }

        private static int Strength(string extension)
        {
            int upper = 0;
            int lower = 0;

            foreach (char c in extension)
            {
                if (char.IsUpper(c)) upper++;
                else if (char.IsLower(c)) lower++;
            }

            return upper - lower;
        }
    }
}
