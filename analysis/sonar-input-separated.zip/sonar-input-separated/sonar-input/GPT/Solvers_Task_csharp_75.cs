namespace Benchmarks.csharp_75.GPT
{
using System;

public class Solver
{
    public static string IntToMiniRoman(int number)
    {
        (int value, string symbol)[] map = new (int, string)[]
        {
            (1000, "M"),
            (900, "CM"),
            (500, "D"),
            (400, "CD"),
            (100, "C"),
            (90, "XC"),
            (50, "L"),
            (40, "XL"),
            (10, "X"),
            (9, "IX"),
            (5, "V"),
            (4, "IV"),
            (1, "I")
        };

        var result = "";

        foreach (var (value, symbol) in map)
        {
            while (number >= value)
            {
                result += symbol;
                number -= value;
            }
        }

        return result.ToLower();
    }
}
}
