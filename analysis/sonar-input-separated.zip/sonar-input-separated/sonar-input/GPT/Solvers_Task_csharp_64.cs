namespace Benchmarks.csharp_64.GPT
{
using System;

public class Solver
{
    public static int SpecialFactorial(int n)
    {
        int fact = 1;
        int result = 1;

        for (int i = 1; i <= n; i++)
        {
            fact *= i;
            result *= fact;
        }

        return result;
    }
}
}
