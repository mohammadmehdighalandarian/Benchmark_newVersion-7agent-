namespace Benchmarks.csharp_77.GPT
{
using System;
using System.Linq;

public class Solver
{
    public static string Solve(string s)
    {
        bool hasLetter = s.Any(char.IsLetter);

        if (!hasLetter)
        {
            char[] rev = s.ToCharArray();
            Array.Reverse(rev);
            return new string(rev);
        }

        char[] result = new char[s.Length];

        for (int i = 0; i < s.Length; i++)
        {
            char c = s[i];

            if (char.IsLetter(c))
            {
                result[i] = char.IsLower(c) ? char.ToUpper(c) : char.ToLower(c);
            }
            else
            {
                result[i] = c;
            }
        }

        return new string(result);
    }
}
}
