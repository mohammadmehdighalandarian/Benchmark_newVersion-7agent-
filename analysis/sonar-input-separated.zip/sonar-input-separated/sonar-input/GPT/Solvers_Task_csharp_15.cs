namespace Benchmarks.csharp_15.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static object Median(List<int> l)
    {
        var sorted = l.OrderBy(x => x).ToList();
        int n = sorted.Count;

        if (n % 2 == 1)
            return sorted[n / 2];

        return (sorted[n / 2 - 1] + sorted[n / 2]) / 2.0;
    }
}
}
