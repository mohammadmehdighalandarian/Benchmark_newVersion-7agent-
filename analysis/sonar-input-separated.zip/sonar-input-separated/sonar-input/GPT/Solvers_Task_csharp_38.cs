namespace Benchmarks.csharp_38.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static object NextSmallest(List<int> lst)
    {
        if (lst == null || lst.Count == 0)
            return "None";

        var distinct = lst.Distinct().OrderBy(x => x).ToList();

        if (distinct.Count < 2)
            return "None";

        return distinct[1];
    }
}
}
