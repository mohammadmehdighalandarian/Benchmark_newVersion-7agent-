namespace Benchmarks.csharp_51.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<object> ReverseDelete(string s, string c)
    {
        var set = new HashSet<char>(c);
        
        var filtered = new string(s.Where(ch => !set.Contains(ch)).ToArray());
        
        bool isPalindrome = true;
        int i = 0, j = filtered.Length - 1;
        
        while (i < j)
        {
            if (filtered[i] != filtered[j])
            {
                isPalindrome = false;
                break;
            }
            i++;
            j--;
        }
        
        return new List<object> { filtered, isPalindrome };
    }
}
}
