namespace Benchmarks.csharp_76.GPT
{
using System;
using System.Linq;

public class Solver
{
    public static bool RightAngleTriangle(int a, int b, int c)
    {
        int[] s = new int[] { a, b, c };
        Array.Sort(s);

        long x = s[0];
        long y = s[1];
        long z = s[2];

        return x > 0 && y > 0 && z > 0 && (x * x + y * y == z * z);
    }
}
}
