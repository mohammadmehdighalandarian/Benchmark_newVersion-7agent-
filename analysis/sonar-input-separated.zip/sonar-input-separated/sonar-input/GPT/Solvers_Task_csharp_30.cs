namespace Benchmarks.csharp_30.GPT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static bool WillItFly(List<int> q, int w)
        {
            bool isBalanced = q.SequenceEqual(q.AsEnumerable().Reverse());
            int sum = q.Sum();
            return isBalanced && sum <= w;
        }
    }
}
