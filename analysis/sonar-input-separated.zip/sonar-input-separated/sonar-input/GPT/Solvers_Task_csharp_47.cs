namespace Benchmarks.csharp_47.GPT
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static List<int> F(int n)
    {
        List<int> result = new List<int>(n);
        long fact = 1;

        for (int i = 1; i <= n; i++)
        {
            fact *= i;

            if (i % 2 == 0)
            {
                result.Add((int)fact);
            }
            else
            {
                result.Add(i * (i + 1) / 2);
            }
        }

        return result;
    }
}
}
