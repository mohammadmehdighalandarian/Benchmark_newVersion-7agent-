namespace Benchmarks.csharp_37.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<List<int>> GetRow(List<List<int>> lst, int x)
    {
        var result = new List<List<int>>();

        for (int i = 0; i < lst.Count; i++)
        {
            for (int j = 0; j < lst[i].Count; j++)
            {
                if (lst[i][j] == x)
                {
                    result.Add(new List<int> { i, j });
                }
            }
        }

        return result
            .OrderBy(p => p[0])
            .ThenByDescending(p => p[1])
            .ToList();
    }
}
}
