namespace Benchmarks.csharp_48.GPT
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static List<int> EvenOddPalindrome(int n)
    {
        int evenCount = 0;
        int oddCount = 0;

        for (int i = 1; i <= n; i++)
        {
            if (IsPalindrome(i))
            {
                if (i % 2 == 0) evenCount++;
                else oddCount++;
            }
        }

        return new List<int> { evenCount, oddCount };
    }

    private static bool IsPalindrome(int x)
    {
        string s = x.ToString();
        int l = 0, r = s.Length - 1;

        while (l < r)
        {
            if (s[l] != s[r]) return false;
            l++;
            r--;
        }

        return true;
    }
}
}
