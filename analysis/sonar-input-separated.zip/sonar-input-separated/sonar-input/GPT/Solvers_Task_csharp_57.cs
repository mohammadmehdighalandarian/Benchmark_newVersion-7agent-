namespace Benchmarks.csharp_57.GPT
{
    using System;
    using System.Collections.Generic;

    public class Solver
    {
        public static List<object> Tri(int n)
        {
            int N = n + 1;
            long[] tri = new long[N + 2];

            if (N >= 1) tri[1] = 3;

            for (int i = 2; i <= N; i++)
            {
                if (i % 2 == 0)
                    tri[i] = 1 + i / 2;
            }

            for (int i = 3; i <= N; i += 2)
            {
                tri[i] = tri[i - 1] + tri[i - 2] + tri[i + 1];
            }

            var res = new List<object>();
            for (int i = 1; i <= N; i++)
                res.Add(tri[i]);

            return res;
        }
    }
}
