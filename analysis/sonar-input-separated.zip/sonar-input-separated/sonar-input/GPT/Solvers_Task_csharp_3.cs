namespace Benchmarks.csharp_3.GPT
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static object Longest(List<string> strings)
    {
        if (strings == null || strings.Count == 0)
            return null;

        string longest = strings[0];

        foreach (string s in strings)
        {
            if (s.Length > longest.Length)
                longest = s;
        }

        return longest;
    }
}
}
