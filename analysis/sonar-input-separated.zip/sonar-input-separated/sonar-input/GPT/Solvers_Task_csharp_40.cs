namespace Benchmarks.csharp_40.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int Skjkasdkd(List<int> lst)
    {
        int maxPrime = int.MinValue;
        bool found = false;

        foreach (int num in lst)
        {
            if (IsPrime(num))
            {
                if (!found || num > maxPrime)
                {
                    maxPrime = num;
                    found = true;
                }
            }
        }

        if (!found) return 0;

        int sum = 0;
        int n = maxPrime;

        while (n > 0)
        {
            sum += n % 10;
            n /= 10;
        }

        return sum;
    }

    private static bool IsPrime(int n)
    {
        if (n <= 1) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;

        for (int i = 3; i * i <= n; i += 2)
        {
            if (n % i == 0) return false;
        }

        return true;
    }
}
}
