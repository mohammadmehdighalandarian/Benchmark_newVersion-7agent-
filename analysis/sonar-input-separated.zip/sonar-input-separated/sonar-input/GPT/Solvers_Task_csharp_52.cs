namespace Benchmarks.csharp_52.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int MaxFill(List<List<int>> grid, int capacity)
    {
        int result = 0;

        foreach (var row in grid)
        {
            int ones = 0;
            for (int i = 0; i < row.Count; i++)
                ones += row[i];

            result += (ones + capacity - 1) / capacity;
        }

        return result;
    }
}
}
