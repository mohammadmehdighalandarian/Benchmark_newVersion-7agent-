namespace Benchmarks.csharp_49.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool MoveOneBall(List<int> arr)
    {
        int n = arr.Count;
        if (n == 0) return true;

        int breaks = 0;

        for (int i = 0; i < n; i++)
        {
            if (arr[i] > arr[(i + 1) % n])
                breaks++;
        }

        return breaks <= 1;
    }
}
}
