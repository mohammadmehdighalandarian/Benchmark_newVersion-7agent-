namespace Benchmarks.csharp_29.GPT
{
using System;

public class Solver
{
    public static object TriangleArea(int a, int b, int c)
    {
        if (a + b <= c || a + c <= b || b + c <= a)
            return -1;

        double s = (a + b + c) / 2.0;
        double area = Math.Sqrt(s * (s - a) * (s - b) * (s - c));

        return Math.Round(area, 2);
    }
}
}
