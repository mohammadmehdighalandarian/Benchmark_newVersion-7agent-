namespace Benchmarks.csharp_5.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static string SortNumbers(string numbers)
    {
        var order = new Dictionary<string, int>
        {
            ["zero"] = 0,
            ["one"] = 1,
            ["two"] = 2,
            ["three"] = 3,
            ["four"] = 4,
            ["five"] = 5,
            ["six"] = 6,
            ["seven"] = 7,
            ["eight"] = 8,
            ["nine"] = 9
        };

        return string.Join(" ",
            numbers.Split(' ')
                   .OrderBy(n => order[n]));
    }
}
}
