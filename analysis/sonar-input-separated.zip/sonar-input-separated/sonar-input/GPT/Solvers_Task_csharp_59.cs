namespace Benchmarks.csharp_59.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool IsNested(string string0)
    {
        int n = string0.Length;
        int[] suffixClose = new int[n + 1];

        for (int i = n - 1; i >= 0; i--)
        {
            suffixClose[i] = suffixClose[i + 1] + (string0[i] == ']' ? 1 : 0);
        }

        int prefixOpen = 0;

        for (int i = 0; i < n; i++)
        {
            if (string0[i] == '[')
            {
                if (prefixOpen >= 1 && suffixClose[i + 1] >= 2)
                    return true;

                prefixOpen++;
            }
        }

        return false;
    }
}
}
