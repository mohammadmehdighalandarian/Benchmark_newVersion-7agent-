namespace Benchmarks.csharp_66.GPT
{
using System;

public class Solver
{
    public static bool Simplify(string x, string n)
    {
        var partsX = x.Split('/');
        var partsN = n.Split('/');

        long a = long.Parse(partsX[0]);
        long b = long.Parse(partsX[1]);
        long c = long.Parse(partsN[0]);
        long d = long.Parse(partsN[1]);

        long numerator = a * c;
        long denominator = b * d;

        return numerator % denominator == 0;
    }
}
}
