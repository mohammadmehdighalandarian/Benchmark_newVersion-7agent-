namespace Benchmarks.csharp_32.GPT
{
    using System;

    public class Solver
    {
        public static string DecimalToBinary(int @decimal)
        {
            string binary = Convert.ToString(@decimal, 2);
            return "db" + binary + "db";
        }
    }
}
