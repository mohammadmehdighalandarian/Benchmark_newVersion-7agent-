namespace Benchmarks.csharp_36.GPT
{
using System;

public class Solver
{
    public static string Solve(int N)
    {
        int sum = 0;

        while (N > 0)
        {
            sum += N % 10;
            N /= 10;
        }

        return Convert.ToString(sum, 2);
    }
}
}
