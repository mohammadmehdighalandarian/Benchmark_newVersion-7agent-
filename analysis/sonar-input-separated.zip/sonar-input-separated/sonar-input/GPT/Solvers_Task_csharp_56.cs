namespace Benchmarks.csharp_56.GPT
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static string Intersection(List<int> interval1, List<int> interval2)
    {
        int start1 = interval1[0], end1 = interval1[1];
        int start2 = interval2[0], end2 = interval2[1];

        int left = Math.Max(start1, start2);
        int right = Math.Min(end1, end2);

        if (left > right)
            return "NO";

        int len = right - left + 1;

        if (IsPrime(len))
            return "YES";

        return "NO";
    }

    private static bool IsPrime(int n)
    {
        if (n < 2) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;

        for (int i = 3; i * i <= n; i += 2)
        {
            if (n % i == 0)
                return false;
        }

        return true;
    }
}
}
