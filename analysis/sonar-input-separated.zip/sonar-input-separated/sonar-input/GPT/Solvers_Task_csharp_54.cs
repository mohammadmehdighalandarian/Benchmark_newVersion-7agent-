namespace Benchmarks.csharp_54.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> Maximum(List<int> arr, int k)
    {
        if (k == 0) return new List<int>();

        return arr
            .OrderByDescending(x => x)
            .Take(k)
            .OrderBy(x => x)
            .ToList();
    }
}
}
