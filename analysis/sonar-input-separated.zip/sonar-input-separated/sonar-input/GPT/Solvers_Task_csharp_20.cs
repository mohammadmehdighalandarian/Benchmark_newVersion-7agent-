namespace Benchmarks.csharp_20.GPT
{
    using System;
    using System.Linq;
    using System.Collections.Generic;

    public class Solver
    {
        public static bool SameChars(string s0, string s1)
        {
            return new HashSet<char>(s0).SetEquals(new HashSet<char>(s1));
        }
    }
}
