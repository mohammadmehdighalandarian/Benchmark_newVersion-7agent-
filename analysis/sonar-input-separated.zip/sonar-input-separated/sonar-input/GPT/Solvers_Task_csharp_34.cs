namespace Benchmarks.csharp_34.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<string> NumericalLetterGrade(List<object> grades)
    {
        var result = new List<string>();

        foreach (var g in grades)
        {
            double grade = Convert.ToDouble(g);

            if (grade == 4.0)
                result.Add("A+");
            else if (grade > 3.7)
                result.Add("A");
            else if (grade > 3.3)
                result.Add("A-");
            else if (grade > 3.0)
                result.Add("B+");
            else if (grade > 2.7)
                result.Add("B");
            else if (grade > 2.3)
                result.Add("B-");
            else if (grade > 2.0)
                result.Add("C+");
            else if (grade > 1.7)
                result.Add("C");
            else if (grade > 1.3)
                result.Add("C-");
            else if (grade > 1.0)
                result.Add("D+");
            else if (grade > 0.7)
                result.Add("D");
            else if (grade > 0.0)
                result.Add("D-");
            else
                result.Add("E");
        }

        return result;
    }
}
}
