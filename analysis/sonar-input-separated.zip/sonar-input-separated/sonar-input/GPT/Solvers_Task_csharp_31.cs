namespace Benchmarks.csharp_31.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool IsMultiplyPrime(int a)
    {
        if (a <= 1) return false;

        List<int> factors = new List<int>();

        for (int i = 2; i * i <= a; i++)
        {
            while (a % i == 0)
            {
                factors.Add(i);
                a /= i;
            }
        }

        if (a > 1)
            factors.Add(a);

        if (factors.Count != 3)
            return false;

        foreach (var f in factors)
        {
            if (!IsPrime(f))
                return false;
        }

        return true;
    }

    private static bool IsPrime(int n)
    {
        if (n < 2) return false;
        for (int i = 2; i * i <= n; i++)
        {
            if (n % i == 0) return false;
        }
        return true;
    }
}
}
