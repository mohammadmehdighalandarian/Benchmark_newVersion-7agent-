namespace Benchmarks.csharp_13.GPT
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static bool PairsSumToZero(List<int> l)
    {
        HashSet<int> seen = new HashSet<int>();

        foreach (int x in l)
        {
            if (seen.Contains(-x))
                return true;

            seen.Add(x);
        }

        return false;
    }
}
}
