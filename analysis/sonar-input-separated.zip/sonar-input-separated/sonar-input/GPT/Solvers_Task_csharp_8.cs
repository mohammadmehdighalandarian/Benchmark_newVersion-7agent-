namespace Benchmarks.csharp_8.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> GetPositive(List<int> l)
    {
        return l.Where(x => x > 0).ToList();
    }
}
}
