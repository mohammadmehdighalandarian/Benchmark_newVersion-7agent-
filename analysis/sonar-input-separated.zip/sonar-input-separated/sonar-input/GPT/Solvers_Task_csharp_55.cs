namespace Benchmarks.csharp_55.GPT
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static int AddElements(List<int> arr, int k)
    {
        int sum = 0;

        for (int i = 0; i < k; i++)
        {
            int val = arr[i];
            if (Math.Abs(val) <= 99)
                sum += val;
        }

        return sum;
    }
}
}
