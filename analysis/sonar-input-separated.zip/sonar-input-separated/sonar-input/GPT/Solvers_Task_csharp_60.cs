namespace Benchmarks.csharp_60.GPT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static int SumSquares(List<object> lst)
        {
            int sum = 0;

            foreach (var item in lst)
            {
                double val = Convert.ToDouble(item);
                int ceiled = (int)Math.Ceiling(val);
                sum += ceiled * ceiled;
            }

            return sum;
        }
    }
}
