namespace Benchmarks.csharp_28.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int Search(List<int> lst)
    {
        Dictionary<int, int> freq = new Dictionary<int, int>();

        foreach (int num in lst)
        {
            if (freq.ContainsKey(num))
                freq[num]++;
            else
                freq[num] = 1;
        }

        int result = -1;

        foreach (var kv in freq)
        {
            int value = kv.Key;
            int count = kv.Value;

            if (value > 0 && count >= value)
            {
                result = Math.Max(result, value);
            }
        }

        return result;
    }
}
}
