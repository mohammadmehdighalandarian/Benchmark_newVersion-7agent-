namespace Benchmarks.csharp_1.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> SumProduct(List<int> numbers)
    {
        int sum = 0;
        int product = 1;

        foreach (int n in numbers)
        {
            sum += n;
            product *= n;
        }

        return new List<int> { sum, product };
    }
}
}
