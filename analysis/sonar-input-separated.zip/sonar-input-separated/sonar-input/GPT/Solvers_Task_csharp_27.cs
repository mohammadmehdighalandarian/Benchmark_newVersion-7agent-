namespace Benchmarks.csharp_27.GPT
{
    using System;

    public class Solver
    {
        public static int VowelsCount(string s)
        {
            if (string.IsNullOrEmpty(s)) return 0;

            int count = 0;
            string vowels = "aeiou";

            for (int i = 0; i < s.Length; i++)
            {
                char c = char.ToLower(s[i]);

                if (vowels.Contains(c))
                {
                    count++;
                }
                else if (c == 'y' && i == s.Length - 1)
                {
                    count++;
                }
            }

            return count;
        }
    }
}
