namespace Benchmarks.csharp_43.GPT
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text.RegularExpressions;

    public class Solver
    {
        public static List<int> MakeAPile(int n)
        {
            var res = new List<int>(n);
            for (int i = 0; i < n; i++)
            {
                res.Add(n + 2 * i);
            }

            return res;
        }
    }
}
