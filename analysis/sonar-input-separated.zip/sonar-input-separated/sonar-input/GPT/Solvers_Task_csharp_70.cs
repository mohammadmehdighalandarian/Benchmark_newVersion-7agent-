namespace Benchmarks.csharp_70.GPT
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static List<string> Bf(string planet1, string planet2)
    {
        string[] planets = new string[]
        {
            "Mercury", "Venus", "Earth", "Mars",
            "Jupiter", "Saturn", "Uranus", "Neptune"
        };

        int i1 = Array.IndexOf(planets, planet1);
        int i2 = Array.IndexOf(planets, planet2);

        if (i1 == -1 || i2 == -1)
            return new List<string>();

        int start = Math.Min(i1, i2);
        int end = Math.Max(i1, i2);

        List<string> result = new List<string>();

        for (int i = start + 1; i < end; i++)
        {
            result.Add(planets[i]);
        }

        return result;
    }
}
}
