namespace Benchmarks.csharp_21.GPT
{
using System;

public class Solver
{
    public static int Fib(int n)
    {
        if (n <= 1) return n;

        int a = 1, b = 1;

        for (int i = 3; i <= n; i++)
        {
            int c = a + b;
            a = b;
            b = c;
        }

        return b;
    }
}
}
