namespace Benchmarks.csharp_72.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int DoubleTheDifference(List<object> lst)
    {
        if (lst == null || lst.Count == 0)
            return 0;

        int sum = 0;

        foreach (var item in lst)
        {
            if (item is int x)
            {
                if (x > 0 && x % 2 != 0)
                {
                    sum += x * x;
                }
            }
        }

        return sum;
    }
}
}
