namespace Benchmarks.csharp_45.GPT
{
using System;

public class Solver
{
    public static int ChooseNum(int x, int y)
    {
        int l = Math.Min(x, y);
        int r = Math.Max(x, y);

        int candidate = (r % 2 == 0) ? r : r - 1;

        if (candidate >= l)
            return candidate;

        return -1;
    }
}
}
