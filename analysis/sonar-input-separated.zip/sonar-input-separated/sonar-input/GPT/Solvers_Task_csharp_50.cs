namespace Benchmarks.csharp_50.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static string Exchange(List<int> lst1, List<int> lst2)
    {
        int evenCount = lst1.Concat(lst2).Count(x => x % 2 == 0);
        return evenCount >= lst1.Count ? "YES" : "NO";
    }
}
}
