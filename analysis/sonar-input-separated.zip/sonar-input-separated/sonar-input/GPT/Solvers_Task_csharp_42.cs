namespace Benchmarks.csharp_42.GPT
{
using System;
using System.Globalization;

public class Solver
{
    public static int ClosestInteger(string value)
    {
        double x = double.Parse(value, CultureInfo.InvariantCulture);
        return (int)Math.Round(x, MidpointRounding.AwayFromZero);
    }
}
}
