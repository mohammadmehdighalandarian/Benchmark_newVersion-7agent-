namespace Benchmarks.csharp_16.GPT
{
using System;

public class Solver
{
    public static bool IsPalindrome(string text)
    {
        if (text == null)
            return false;

        int left = 0;
        int right = text.Length - 1;

        while (left < right)
        {
            if (text[left] != text[right])
                return false;

            left++;
            right--;
        }

        return true;
    }
}
}
