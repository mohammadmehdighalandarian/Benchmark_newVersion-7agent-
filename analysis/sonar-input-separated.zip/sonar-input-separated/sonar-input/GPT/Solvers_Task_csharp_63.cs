namespace Benchmarks.csharp_63.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<object> LargestSmallestIntegers(List<int> lst)
    {
        int? largestNegative = null;
        int? smallestPositive = null;

        foreach (var x in lst)
        {
            if (x < 0)
            {
                if (largestNegative == null || x > largestNegative)
                    largestNegative = x;
            }
            else if (x > 0)
            {
                if (smallestPositive == null || x < smallestPositive)
                    smallestPositive = x;
            }
        }

        return new List<object>
        {
            largestNegative.HasValue ? (object)largestNegative.Value : null,
            smallestPositive.HasValue ? (object)smallestPositive.Value : null
        };
    }
}
}
