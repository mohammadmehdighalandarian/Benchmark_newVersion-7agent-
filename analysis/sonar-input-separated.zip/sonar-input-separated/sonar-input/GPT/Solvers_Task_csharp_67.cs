namespace Benchmarks.csharp_67.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> OrderByPoints(List<int> nums)
    {
        if (nums == null || nums.Count == 0)
            return new List<int>();

        int DigitSum(int x)
        {
            x = Math.Abs(x);
            int sum = 0;
            while (x > 0)
            {
                sum += x % 10;
                x /= 10;
            }
            return sum;
        }

        return nums
            .Select((value, index) => new { value, index, sum = DigitSum(value) })
            .OrderBy(x => x.sum)
            .ThenBy(x => x.index)
            .Select(x => x.value)
            .ToList();
    }
}
}
