namespace Benchmarks.csharp_46.GPT
{
using System;
using System.Linq;

public class Solver
{
    public static object RoundedAvg(int n, int m)
    {
        if (n > m) return -1;

        double avg = (n + m) / 2.0;
        int rounded = (int)Math.Floor(avg);

        string binary = Convert.ToString(rounded, 2);
        return "0b" + binary;
    }
}
}
