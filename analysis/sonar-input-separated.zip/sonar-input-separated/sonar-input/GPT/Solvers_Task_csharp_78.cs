namespace Benchmarks.csharp_78.GPT
{
using System;
using System.Text;
using System.Security.Cryptography;

public class Solver
{
    public static object StringToMd5(string text)
    {
        if (string.IsNullOrEmpty(text))
            return "None";

        using (MD5 md5 = MD5.Create())
        {
            byte[] inputBytes = Encoding.UTF8.GetBytes(text);
            byte[] hashBytes = md5.ComputeHash(inputBytes);

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < hashBytes.Length; i++)
                sb.Append(hashBytes[i].ToString("x2"));

            return sb.ToString();
        }
    }
}
}
