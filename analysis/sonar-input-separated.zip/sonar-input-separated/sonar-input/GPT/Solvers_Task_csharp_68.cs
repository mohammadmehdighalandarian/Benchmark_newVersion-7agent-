namespace Benchmarks.csharp_68.GPT
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static int SpecialFilter(List<int> nums)
    {
        int count = 0;

        foreach (int n in nums)
        {
            if (n <= 10) continue;

            int x = Math.Abs(n);

            int last = x % 10;

            int first = x;
            while (first >= 10)
                first /= 10;

            if (IsOddDigit(first) && IsOddDigit(last))
                count++;
        }

        return count;
    }

    private static bool IsOddDigit(int d)
    {
        return d == 1 || d == 3 || d == 5 || d == 7 || d == 9;
    }
}
}
