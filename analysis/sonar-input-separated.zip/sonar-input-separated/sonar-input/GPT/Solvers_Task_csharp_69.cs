namespace Benchmarks.csharp_69.GPT
{
using System;

public class Solver
{
    public static int GetMaxTriples(int n)
    {
        int q = n / 3;
        int r = n % 3;

        long cnt0 = q + (r == 2 ? 1 : 0);
        long cnt1 = n - cnt0;

        long c0 = (cnt0 >= 3) ? cnt0 * (cnt0 - 1) * (cnt0 - 2) / 6 : 0;
        long c1 = (cnt1 >= 3) ? cnt1 * (cnt1 - 1) * (cnt1 - 2) / 6 : 0;

        return (int)(c0 + c1);
    }
}
}
