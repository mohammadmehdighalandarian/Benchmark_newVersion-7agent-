namespace Benchmarks.csharp_53.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<string> SelectWords(string s, int n)
    {
        var result = new List<string>();
        if (string.IsNullOrWhiteSpace(s)) return result;

        var vowels = new HashSet<char> { 'a', 'e', 'i', 'o', 'u' };

        var words = s.Split(' ', StringSplitOptions.RemoveEmptyEntries);

        foreach (var word in words)
        {
            int consonants = 0;

            foreach (char c in word)
            {
                char ch = char.ToLower(c);
                if (!vowels.Contains(ch))
                    consonants++;
            }

            if (consonants == n)
                result.Add(word);
        }

        return result;
    }
}
}
