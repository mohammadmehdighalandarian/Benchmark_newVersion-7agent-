namespace Benchmarks.csharp_71.GPT
{
using System;

public class Solver
{
    public static int XOrY(int n, int x, int y)
    {
        if (n <= 1) return y;
        if (n == 2) return x;
        if (n % 2 == 0) return y;

        for (int i = 3; i * i <= n; i += 2)
        {
            if (n % i == 0)
                return y;
        }

        return x;
    }
}
}
