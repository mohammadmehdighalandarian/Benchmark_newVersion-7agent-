namespace Benchmarks.csharp_7.GPT
{
using System;
using System.Linq;

public class Solver
{
    public static string FlipCase(string string0)
    {
        return new string(string0.Select(c =>
            char.IsLower(c) ? char.ToUpper(c) :
            char.IsUpper(c) ? char.ToLower(c) :
            c).ToArray());
    }
}
}
