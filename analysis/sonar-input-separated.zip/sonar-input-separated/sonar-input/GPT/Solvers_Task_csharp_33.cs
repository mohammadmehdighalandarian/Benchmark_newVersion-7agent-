namespace Benchmarks.csharp_33.GPT
{
using System;

public class Solver
{
    public static bool IsHappy(string s)
    {
        if (s == null || s.Length < 3)
            return false;

        for (int i = 0; i < s.Length - 2; i++)
        {
            char a = s[i];
            char b = s[i + 1];
            char c = s[i + 2];

            if (a == b || a == c || b == c)
                return false;
        }

        return true;
    }
}
}
