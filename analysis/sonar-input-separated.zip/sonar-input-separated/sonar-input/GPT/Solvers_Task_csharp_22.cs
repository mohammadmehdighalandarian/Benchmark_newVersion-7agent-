namespace Benchmarks.csharp_22.GPT
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static List<int> Common(List<int> l1, List<int> l2)
    {
        return l1.Intersect(l2).Distinct().OrderBy(x => x).ToList();
    }
}
}
