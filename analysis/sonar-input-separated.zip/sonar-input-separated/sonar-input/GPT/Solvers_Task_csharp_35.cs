namespace Benchmarks.csharp_35.GPT
{
using System;

public class Solver
{
    public static bool PrimeLength(string string0)
    {
        int n = string0.Length;

        if (n <= 1) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;

        for (int i = 3; i * i <= n; i += 2)
        {
            if (n % i == 0)
                return false;
        }

        return true;
    }
}
}
