namespace Benchmarks.csharp_39.GPT
{
using System;
using System.Text.RegularExpressions;

public class Solver
{
    public static int IsBored(string S)
    {
        if (string.IsNullOrEmpty(S)) return 0;

        var sentences = Regex.Split(S, "[.!?]");
        int count = 0;

        foreach (var sentence in sentences)
        {
            var trimmed = sentence.Trim();
            if (trimmed.Length == 0) continue;

            var words = trimmed.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (words.Length > 0 && words[0] == "I")
            {
                count++;
            }
        }

        return count;
    }
}
}
