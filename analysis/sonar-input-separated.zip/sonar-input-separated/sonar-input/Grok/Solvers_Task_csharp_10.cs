namespace Benchmarks.csharp_10.Grok
{
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> Unique(List<int> l)
    {
        return l.Distinct().OrderBy(x => x).ToList();
    }
}
}
