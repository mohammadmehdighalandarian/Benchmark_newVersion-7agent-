namespace Benchmarks.csharp_62.Grok
{
using System.Collections.Generic;

public class Solver
{
    public static int CanArrange(List<int> arr)
    {
        for (int i = arr.Count - 1; i >= 1; i--)
        {
            if (arr[i] < arr[i - 1]) return i;
        }
        return -1;
    }
}
}
