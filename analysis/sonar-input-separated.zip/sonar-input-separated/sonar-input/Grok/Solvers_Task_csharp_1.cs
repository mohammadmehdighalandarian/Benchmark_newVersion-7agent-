namespace Benchmarks.csharp_1.Grok
{
using System.Collections.Generic;

public class Solver
{
    public static List<int> SumProduct (List<int> numbers) 
    {
        int sum = 0;
        int product = 1;
        foreach (int num in numbers)
        {
            sum += num;
            product *= num;
        }
        return new List<int> { sum, product };
    }
}
}
