namespace Benchmarks.csharp_34.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static List<string> NumericalLetterGrade(List<object> grades)
    {
        List<string> result = new List<string>();
        foreach (object o in grades)
        {
            double gpa = Convert.ToDouble(o);
            string grade;
            if (gpa == 4.0)
            {
                grade = "A+";
            }
            else if (gpa > 3.7)
            {
                grade = "A";
            }
            else if (gpa > 3.3)
            {
                grade = "A-";
            }
            else if (gpa > 3.0)
            {
                grade = "B+";
            }
            else if (gpa > 2.7)
            {
                grade = "B";
            }
            else if (gpa > 2.3)
            {
                grade = "B-";
            }
            else if (gpa > 2.0)
            {
                grade = "C+";
            }
            else if (gpa > 1.7)
            {
                grade = "C";
            }
            else if (gpa > 1.3)
            {
                grade = "C-";
            }
            else if (gpa > 1.0)
            {
                grade = "D+";
            }
            else if (gpa > 0.7)
            {
                grade = "D";
            }
            else if (gpa > 0.0)
            {
                grade = "D-";
            }
            else
            {
                grade = "E";
            }
            result.Add(grade);
        }
        return result;
    }
}
}
