namespace Benchmarks.csharp_45.Grok
{
public class Solver
{
    public static int ChooseNum(int x, int y)
    {
        if (x > y) return -1;
        int maxEven = y - (y % 2);
        if (maxEven >= x) return maxEven;
        return -1;
    }
}
}
