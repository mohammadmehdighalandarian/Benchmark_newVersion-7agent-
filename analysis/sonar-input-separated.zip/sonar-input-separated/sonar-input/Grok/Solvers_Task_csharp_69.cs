namespace Benchmarks.csharp_69.Grok
{
public class Solver
{
    public static int GetMaxTriples(int n)
    {
        int q = n / 3;
        int r = n % 3;
        int count0 = q + (r == 2 ? 1 : 0);
        int count1 = n - count0;
        long res = 0;
        if (count0 >= 3)
        {
            res += (long)count0 * (count0 - 1) * (count0 - 2) / 6;
        }
        if (count1 >= 3)
        {
            res += (long)count1 * (count1 - 1) * (count1 - 2) / 6;
        }
        return (int)res;
    }
}
}
