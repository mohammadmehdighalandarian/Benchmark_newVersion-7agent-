namespace Benchmarks.csharp_67.Grok
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> OrderByPoints(List<int> nums)
    {
        if (nums == null || nums.Count == 0) return new List<int>();

        var indexed = nums.Select((num, index) => new { Num = num, Index = index, Sum = GetDigitSum(num) });
        var sorted = indexed.OrderBy(x => x.Sum).ThenBy(x => x.Index).Select(x => x.Num).ToList();
        return sorted;
    }

    private static int GetDigitSum(int n)
    {
        if (n == 0) return 0;
        int sign = Math.Sign(n);
        int sum = 0;
        n = Math.Abs(n);
        while (n > 0)
        {
            sum += n % 10;
            n /= 10;
        }
        return sign * sum;
    }
}
}
