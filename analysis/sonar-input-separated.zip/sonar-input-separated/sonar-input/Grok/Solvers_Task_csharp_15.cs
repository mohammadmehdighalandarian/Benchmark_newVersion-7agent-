namespace Benchmarks.csharp_15.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static object Median(List<int> l)
    {
        l.Sort();
        int n = l.Count;
        if (n % 2 == 1)
        {
            return l[n / 2];
        }
        else
        {
            int a = l[n / 2];
            int b = l[n / 2 + 1];
            return a / 2.0 + b / 2.0;
        }
    }
}
}
