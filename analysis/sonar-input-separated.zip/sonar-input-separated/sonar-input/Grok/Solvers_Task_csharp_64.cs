namespace Benchmarks.csharp_64.Grok
{
public class Solver
{
    public static int SpecialFactorial(int n)
    {
        int product = 1;
        for (int m = 1; m <= n; m++)
        {
            int exp = n - m + 1;
            for (int i = 0; i < exp; i++)
            {
                product *= m;
            }
        }
        return product;
    }
}
}
