namespace Benchmarks.csharp_57.Grok
{
    using System;
    using System.Collections.Generic;

    public class Solver
    {
        public static List<object> Tri(int n)
        {
            List<object> res = new List<object>();
            for (int i = 0; i <= n; i++)
            {
                if (i % 2 == 0)
                {
                    res.Add(1 + i / 2);
                }
                else if (i == 1)
                {
                    res.Add(3);
                }
                else
                {
                    int prevOdd = (int)res[i - 2];
                    int prevEven = 1 + (i - 1) / 2;
                    int nextEven = 1 + (i + 1) / 2;
                    res.Add(prevOdd + prevEven + nextEven);
                }
            }

            return res;
        }
    }
}
