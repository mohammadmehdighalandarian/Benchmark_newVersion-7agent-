namespace Benchmarks.csharp_52.Grok
{
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int MaxFill(List<List<int>> grid, int capacity)
    {
        int totalLowerings = 0;
        foreach (var well in grid)
        {
            int water = well.Sum();
            if (water > 0)
            {
                totalLowerings += (water + capacity - 1) / capacity;
            }
        }
        return totalLowerings;
    }
}
}
