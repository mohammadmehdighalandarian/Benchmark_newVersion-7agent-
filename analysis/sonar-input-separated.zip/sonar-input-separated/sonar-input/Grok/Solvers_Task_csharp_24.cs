namespace Benchmarks.csharp_24.Grok
{
public class Solver
{
    public static int SumToN (int n)
    {
        return n * (n + 1) / 2;
    }
}
}
