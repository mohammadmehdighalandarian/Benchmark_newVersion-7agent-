namespace Benchmarks.csharp_13.Grok
{
using System.Collections.Generic;

public class Solver
{
    public static bool PairsSumToZero(List<int> l)
    {
        HashSet<int> seen = new HashSet<int>();
        foreach (int num in l)
        {
            long complement = -(long)num;
            if (complement >= int.MinValue && complement <= int.MaxValue && seen.Contains((int)complement))
            {
                return true;
            }
            seen.Add(num);
        }
        return false;
    }
}
}
