namespace Benchmarks.csharp_55.Grok
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int AddElements(List<int> arr, int k)
    {
        return arr.Take(k).Where(x => Math.Abs(x) <= 99).Sum();
    }
}
}
