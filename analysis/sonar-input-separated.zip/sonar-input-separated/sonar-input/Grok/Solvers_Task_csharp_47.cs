namespace Benchmarks.csharp_47.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static List<int> F (int n) 
    {
        List<int> res = new List<int>(n);
        long sum = 0;
        long fact = 1;
        for (int i = 1; i <= n; i++)
        {
            sum += i;
            fact *= i;
            if (i % 2 == 0)
            {
                res.Add((int)fact);
            }
            else
            {
                res.Add((int)sum);
            }
        }
        return res;
    }
}
}
