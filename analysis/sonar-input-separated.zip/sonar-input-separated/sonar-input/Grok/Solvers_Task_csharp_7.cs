namespace Benchmarks.csharp_7.Grok
{
using System;

public class Solver
{
    public static string FlipCase (string string0) 
    {
        char[] charArray = string0.ToCharArray();
        for (int i = 0; i < charArray.Length; i++)
        {
            if (char.IsUpper(charArray[i]))
            {
                charArray[i] = char.ToLower(charArray[i]);
            }
            else if (char.IsLower(charArray[i]))
            {
                charArray[i] = char.ToUpper(charArray[i]);
            }
        }
        return new string(charArray);
    }
}
}
