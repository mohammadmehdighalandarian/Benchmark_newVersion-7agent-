namespace Benchmarks.csharp_28.Grok
{
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int Search(List<int> lst)
    {
        var freq = lst.GroupBy(x => x).ToDictionary(g => g.Key, g => g.Count());
        var qualifying = freq.Where(p => p.Value >= p.Key).Select(p => p.Key);
        return qualifying.Any() ? qualifying.Max() : -1;
    }
}
}
