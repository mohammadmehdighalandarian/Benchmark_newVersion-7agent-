namespace Benchmarks.csharp_14.Grok
{
public class Solver
{
    public static int Fib4 (int n)
    {
        if (n == 0 || n == 1 || n == 3) return 0;
        if (n == 2) return 2;
        int a = 0;
        int b = 0;
        int c = 2;
        int d = 0;
        for (int i = 4; i <= n; i++)
        {
            int next = a + b + c + d;
            a = b;
            b = c;
            c = d;
            d = next;
        }
        return d;
    }
}
}
