namespace Benchmarks.csharp_76.Grok
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool RightAngleTriangle(int a, int b, int c)
    {
        int x = a * a;
        int y = b * b;
        int z = c * c;

        return (x + y == z) || (x + z == y) || (y + z == x);
    }
}
}
