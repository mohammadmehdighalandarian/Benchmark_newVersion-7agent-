namespace Benchmarks.csharp_37.Grok
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<List<int>> GetRow(List<List<int>> lst, int x)
    {
        List<List<int>> coords = new List<List<int>>();
        for (int i = 0; i < lst.Count; i++)
        {
            for (int j = 0; j < lst[i].Count; j++)
            {
                if (lst[i][j] == x)
                {
                    coords.Add(new List<int> { i, j });
                }
            }
        }
        coords = coords.OrderBy(c => c[0]).ThenByDescending(c => c[1]).ToList();
        return coords;
    }
}
}
