namespace Benchmarks.csharp_51.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static List<object> ReverseDelete (string s, string c) 
    {
        var toRemove = new HashSet<char>(c);
        string result = "";
        foreach (char ch in s)
        {
            if (!toRemove.Contains(ch))
            {
                result += ch;
            }
        }
        
        bool isPalindrome = true;
        int len = result.Length;
        for (int i = 0; i < len / 2; i++)
        {
            if (result[i] != result[len - 1 - i])
            {
                isPalindrome = false;
                break;
            }
        }
        
        return new List<object> { result, isPalindrome };
    }
}
}
