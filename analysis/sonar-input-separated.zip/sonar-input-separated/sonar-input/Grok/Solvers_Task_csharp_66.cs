namespace Benchmarks.csharp_66.Grok
{
using System;
using System.Numerics;

public class Solver
{
    public static bool Simplify(string x, string n)
    {
        string[] x_parts = x.Split('/');
        BigInteger x_num = BigInteger.Parse(x_parts[0]);
        BigInteger x_den = BigInteger.Parse(x_parts[1]);

        string[] n_parts = n.Split('/');
        BigInteger n_num = BigInteger.Parse(n_parts[0]);
        BigInteger n_den = BigInteger.Parse(n_parts[1]);

        BigInteger num = x_num * n_num;
        BigInteger den = x_den * n_den;

        return num % den == 0;
    }
}
}
