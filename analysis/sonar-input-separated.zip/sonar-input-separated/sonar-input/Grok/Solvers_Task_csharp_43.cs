namespace Benchmarks.csharp_43.Grok
{
    using System.Collections.Generic;

    public class Solver
    {
        public static List<int> MakeAPile(int n)
        {
            List<int> pile = new List<int>();
            int current = n;
            for (int i = 0; i < n; i++)
            {
                pile.Add(current);
                current += 2;
            }

            return pile;
        }
    }
}
