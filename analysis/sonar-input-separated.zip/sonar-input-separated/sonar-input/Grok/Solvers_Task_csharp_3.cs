namespace Benchmarks.csharp_3.Grok
{
using System.Collections.Generic;

public class Solver
{
    public static object Longest(List<string> strings)
    {
        if (strings == null || strings.Count == 0)
        {
            return null;
        }

        string longest = strings[0];
        int maxLen = longest.Length;

        for (int i = 1; i < strings.Count; i++)
        {
            if (strings[i].Length > maxLen)
            {
                longest = strings[i];
                maxLen = strings[i].Length;
            }
        }

        return longest;
    }
}
}
