namespace Benchmarks.csharp_32.Grok
{
    using System;

    public class Solver
    {
        public static string DecimalToBinary(int @decimal)
        {
            return "db" + Convert.ToString(@decimal, 2) + "db";
        }
    }
}
