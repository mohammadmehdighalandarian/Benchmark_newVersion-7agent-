namespace Benchmarks.csharp_19.Grok
{
public class Solver
{
    public static int Add (int x, int y) 
    {
        return x + y;
    }
}
}
