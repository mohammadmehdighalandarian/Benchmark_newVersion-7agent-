namespace Benchmarks.csharp_49.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static bool MoveOneBall(List<int> arr)
    {
        List<int> sorted = new List<int>(arr);
        sorted.Sort();
        string original = string.Join(",", arr);
        string target = string.Join(",", sorted);
        return (original + "," + original).Contains(target);
    }
}
}
