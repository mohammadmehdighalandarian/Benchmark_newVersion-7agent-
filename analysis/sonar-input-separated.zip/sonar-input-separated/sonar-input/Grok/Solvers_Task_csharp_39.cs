namespace Benchmarks.csharp_39.Grok
{
using System;

public class Solver
{
    public static int IsBored (string S) 
    {
        if (string.IsNullOrWhiteSpace(S)) return 0;
        string[] parts = S.Split(new char[] { '.', '?', '!' }, StringSplitOptions.RemoveEmptyEntries);
        int count = 0;
        foreach (string part in parts)
        {
            string sentence = part.Trim();
            if (sentence == "I" || sentence.StartsWith("I "))
            {
                count++;
            }
        }
        return count;
    }
}
}
