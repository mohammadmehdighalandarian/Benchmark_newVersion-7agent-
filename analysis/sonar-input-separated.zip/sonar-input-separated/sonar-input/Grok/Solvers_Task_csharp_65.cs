namespace Benchmarks.csharp_65.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static string WordsInSentence(string sentence)
    {
        string[] words = sentence.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        List<string> result = new List<string>();
        foreach (string word in words)
        {
            int len = word.Length;
            if (IsPrime(len))
            {
                result.Add(word);
            }
        }
        return string.Join(" ", result);
    }

    private static bool IsPrime(int n)
    {
        if (n <= 1) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;
        for (int i = 3; i * i <= n; i += 2)
        {
            if (n % i == 0) return false;
        }
        return true;
    }
}
}
