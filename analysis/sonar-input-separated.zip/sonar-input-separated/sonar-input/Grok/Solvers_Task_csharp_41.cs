namespace Benchmarks.csharp_41.Grok
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool CheckDictCase(Dictionary<object, string> dict)
    {
        if (dict == null || dict.Count == 0) return false;

        if (!dict.Keys.All(k => k is string)) return false;

        var stringKeys = dict.Keys.Cast<string>();

        bool allLower = stringKeys.All(k => k == k.ToLower());
        bool allUpper = stringKeys.All(k => k == k.ToUpper());

        return allLower || allUpper;
    }
}
}
