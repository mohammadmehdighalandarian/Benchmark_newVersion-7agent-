namespace Benchmarks.csharp_31.Grok
{
using System;

public class Solver
{
    public static bool IsMultiplyPrime(int a)
    {
        if (a <= 1) return false;
        int count = 0;
        while (a % 2 == 0)
        {
            count++;
            a /= 2;
        }
        for (int i = 3; i * i <= a; i += 2)
        {
            while (a % i == 0)
            {
                count++;
                a /= i;
            }
        }
        if (a > 1) count++;
        return count == 3;
    }
}
}
