namespace Benchmarks.csharp_68.Grok
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int SpecialFilter(List<int> nums)
    {
        return nums.Count(n =>
        {
            if (n <= 10) return false;
            int last = n % 10;
            if (last % 2 == 0) return false;
            int first = n;
            while (first >= 10) first /= 10;
            return first % 2 == 1;
        });
    }
}
}
