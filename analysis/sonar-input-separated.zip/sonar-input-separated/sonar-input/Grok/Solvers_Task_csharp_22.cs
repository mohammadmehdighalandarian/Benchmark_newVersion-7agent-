namespace Benchmarks.csharp_22.Grok
{
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> Common(List<int> l1, List<int> l2)
    {
        return l1.Intersect(l2).OrderBy(x => x).ToList();
    }
}
}
