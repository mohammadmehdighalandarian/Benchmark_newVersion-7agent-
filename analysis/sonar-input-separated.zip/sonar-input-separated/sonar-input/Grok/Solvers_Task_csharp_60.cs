namespace Benchmarks.csharp_60.Grok
{
    using System;
    using System.Collections.Generic;

    public class Solver
    {
        public static int SumSquares(List<object> lst)
        {
            int sum = 0;
            foreach (object obj in lst)
            {
                double num = Convert.ToDouble(obj);
                double ceiled = Math.Ceiling(num);
                int ceiledInt = (int)ceiled;
                sum += ceiledInt * ceiledInt;
            }

            return sum;
        }
    }
}
