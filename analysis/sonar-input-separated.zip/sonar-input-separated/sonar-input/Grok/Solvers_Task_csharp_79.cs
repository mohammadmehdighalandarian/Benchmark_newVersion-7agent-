namespace Benchmarks.csharp_79.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static List<int> GenerateIntegers(int a, int b)
    {
        int min = Math.Min(a, b);
        int max = Math.Max(a, b);
        List<int> result = new List<int>();
        for (int i = 0; i < 10; i += 2)
        {
            if (i >= min && i <= max)
            {
                result.Add(i);
            }
        }
        return result;
    }
}
}
