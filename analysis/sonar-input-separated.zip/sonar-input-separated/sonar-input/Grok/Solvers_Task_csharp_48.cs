namespace Benchmarks.csharp_48.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static List<int> EvenOddPalindrome(int n)
    {
        int evenCount = 0;
        int oddCount = 0;
        for (int i = 1; i <= n; i++)
        {
            if (IsPalindrome(i))
            {
                if (i % 2 == 0)
                {
                    evenCount++;
                }
                else
                {
                    oddCount++;
                }
            }
        }
        return new List<int> { evenCount, oddCount };
    }

    private static bool IsPalindrome(int num)
    {
        string s = num.ToString();
        int len = s.Length;
        for (int i = 0; i < len / 2; i++)
        {
            if (s[i] != s[len - 1 - i])
            {
                return false;
            }
        }
        return true;
    }
}
}
