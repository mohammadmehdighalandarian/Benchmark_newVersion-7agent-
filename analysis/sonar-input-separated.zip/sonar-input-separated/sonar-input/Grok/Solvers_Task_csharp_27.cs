namespace Benchmarks.csharp_27.Grok
{
    using System;

    public class Solver
    {
        public static int VowelsCount(string s)
        {
            if (string.IsNullOrEmpty(s)) return 0;
            string lower = s.ToLower();
            int count = 0;
            for (int i = 0; i < lower.Length; i++)
            {
                char c = lower[i];
                if ("aeiou".Contains(c) || (c == 'y' && i == lower.Length - 1))
                {
                    count++;
                }
            }

            return count;
        }
    }
}
