namespace Benchmarks.csharp_38.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static object NextSmallest(List<int> lst)
    {
        if (lst == null || lst.Count == 0)
            return null;

        int minVal = lst[0];
        for (int i = 1; i < lst.Count; i++)
        {
            if (lst[i] < minVal)
                minVal = lst[i];
        }

        int? second = null;
        for (int i = 0; i < lst.Count; i++)
        {
            if (lst[i] > minVal && (second == null || lst[i] < second))
                second = lst[i];
        }

        return second;
    }
}
}
