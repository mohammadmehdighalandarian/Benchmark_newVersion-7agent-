namespace Benchmarks.csharp_73.Grok
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static string StrongestExtension(string class_name, List<string> extensions)
        {
            string bestExt = extensions[0];
            int maxStr = extensions[0].Count(char.IsUpper) - extensions[0].Count(char.IsLower);
            for (int i = 1; i < extensions.Count; i++)
            {
                string ext = extensions[i];
                int strength = ext.Count(char.IsUpper) - ext.Count(char.IsLower);
                if (strength > maxStr)
                {
                    maxStr = strength;
                    bestExt = ext;
                }
            }

            return class_name + "." + bestExt;
        }
    }
}
