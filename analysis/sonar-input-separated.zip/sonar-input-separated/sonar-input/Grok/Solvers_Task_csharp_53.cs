namespace Benchmarks.csharp_53.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static List<string> SelectWords(string s, int n)
    {
        var words = s.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        var result = new List<string>();
        foreach (var word in words)
        {
            int consonantCount = 0;
            foreach (char c in word)
            {
                if (char.IsLetter(c) && !"aeiouAEIOU".Contains(c))
                {
                    consonantCount++;
                }
            }
            if (consonantCount == n)
            {
                result.Add(word);
            }
        }
        return result;
    }
}
}
