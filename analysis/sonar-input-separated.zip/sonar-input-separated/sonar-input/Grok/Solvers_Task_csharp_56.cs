namespace Benchmarks.csharp_56.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static string Intersection(List<int> interval1, List<int> interval2)
    {
        int start1 = interval1[0];
        int end1 = interval1[1];
        int start2 = interval2[0];
        int end2 = interval2[1];

        int intersectStart = Math.Max(start1, start2);
        int intersectEnd = Math.Min(end1, end2);

        if (intersectStart > intersectEnd)
        {
            return "NO";
        }

        int length = intersectEnd - intersectStart;

        return IsPrime(length) ? "YES" : "NO";
    }

    private static bool IsPrime(int n)
    {
        if (n <= 1) return false;
        if (n == 2 || n == 3) return true;
        if (n % 2 == 0 || n % 3 == 0) return false;

        for (int i = 5; (long)i * i <= n; i += 6)
        {
            if (n % i == 0 || n % (i + 2) == 0) return false;
        }
        return true;
    }
}
}
