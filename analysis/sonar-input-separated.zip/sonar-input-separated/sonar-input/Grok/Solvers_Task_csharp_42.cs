namespace Benchmarks.csharp_42.Grok
{
using System;

public class Solver
{
    public static int ClosestInteger(string value)
    {
        double num = double.Parse(value);
        return (int)Math.Round(num, MidpointRounding.AwayFromZero);
    }
}
}
