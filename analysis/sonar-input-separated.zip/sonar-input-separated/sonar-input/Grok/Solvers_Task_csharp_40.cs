namespace Benchmarks.csharp_40.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static int Skjkasdkd (List<int> lst)
    {
        int maxPrime = -1;
        foreach (int num in lst)
        {
            if (num > 1 && IsPrime(num) && (maxPrime == -1 || num > maxPrime))
            {
                maxPrime = num;
            }
        }
        int sum = 0;
        int temp = maxPrime;
        while (temp > 0)
        {
            sum += temp % 10;
            temp /= 10;
        }
        return sum;
    }

    private static bool IsPrime(int n)
    {
        if (n <= 1) return false;
        if (n <= 3) return true;
        if (n % 2 == 0 || n % 3 == 0) return false;
        for (int i = 5; i * i <= n; i += 6)
        {
            if (n % i == 0 || n % (i + 2) == 0) return false;
        }
        return true;
    }
}
}
