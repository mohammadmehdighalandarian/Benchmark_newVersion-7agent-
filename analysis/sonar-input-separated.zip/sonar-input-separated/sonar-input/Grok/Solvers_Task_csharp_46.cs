namespace Benchmarks.csharp_46.Grok
{
using System;

public class Solver
{
    public static object RoundedAvg(int n, int m)
    {
        if (n > m)
        {
            return -1;
        }

        long first = n;
        long last = m;
        long count = last - first + 1;
        long sum = (first + last) * count / 2;
        double avg = (double)sum / count;
        long rounded = (long)Math.Round(avg);
        string binary = Convert.ToString(rounded, 2);
        return "0b" + binary;
    }
}
}
