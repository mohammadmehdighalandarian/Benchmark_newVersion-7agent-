namespace Benchmarks.csharp_54.Grok
{
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> Maximum(List<int> arr, int k)
    {
        return arr.OrderBy(x => x).Skip(arr.Count - k).ToList();
    }
}
}
