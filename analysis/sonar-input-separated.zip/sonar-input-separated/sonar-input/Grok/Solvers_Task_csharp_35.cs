namespace Benchmarks.csharp_35.Grok
{
using System;

public class Solver
{
    public static bool PrimeLength(string string0)
    {
        int len = string0.Length;
        if (len <= 1) return false;
        if (len == 2) return true;
        if (len % 2 == 0) return false;
        for (int i = 3; i * i <= len; i += 2)
        {
            if (len % i == 0) return false;
        }
        return true;
    }
}
}
