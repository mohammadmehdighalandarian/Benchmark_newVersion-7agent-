namespace Benchmarks.csharp_59.Grok
{
public class Solver
{
    public static bool IsNested(string string0)
    {
        int countOpen = 0;
        int posSecond = -1;
        for (int i = 0; i < string0.Length; i++)
        {
            if (string0[i] == '[')
            {
                countOpen++;
                if (countOpen == 2)
                {
                    posSecond = i;
                    break;
                }
            }
        }
        if (posSecond == -1)
        {
            return false;
        }
        int countCloseAfter = 0;
        for (int i = posSecond + 1; i < string0.Length; i++)
        {
            if (string0[i] == ']')
            {
                countCloseAfter++;
            }
        }
        return countCloseAfter >= 2;
    }
}
}
