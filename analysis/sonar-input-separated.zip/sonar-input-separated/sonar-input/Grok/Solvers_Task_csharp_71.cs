namespace Benchmarks.csharp_71.Grok
{
using System;

public class Solver
{
    public static int XOrY (int n, int x, int y)
    {
        if (n <= 1)
        {
            return y;
        }
        if (n == 2 || n == 3)
        {
            return x;
        }
        if (n % 2 == 0 || n % 3 == 0)
        {
            return y;
        }
        for (int i = 5; (long)i * i <= n; i += 6)
        {
            if (n % i == 0 || n % (i + 2) == 0)
            {
                return y;
            }
        }
        return x;
    }
}
}
