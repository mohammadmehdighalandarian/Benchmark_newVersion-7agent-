namespace Benchmarks.csharp_5.Grok
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static string SortNumbers(string numbers)
    {
        if (string.IsNullOrWhiteSpace(numbers))
            return "";

        var wordToNum = new Dictionary<string, int>
        {
            { "zero", 0 },
            { "one", 1 },
            { "two", 2 },
            { "three", 3 },
            { "four", 4 },
            { "five", 5 },
            { "six", 6 },
            { "seven", 7 },
            { "eight", 8 },
            { "nine", 9 }
        };

        var parts = numbers.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        var sortedParts = parts.OrderBy(p => wordToNum[p]);
        return string.Join(" ", sortedParts);
    }
}
}
