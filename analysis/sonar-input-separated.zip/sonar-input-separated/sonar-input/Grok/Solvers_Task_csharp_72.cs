namespace Benchmarks.csharp_72.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static int DoubleTheDifference(List<object> lst)
    {
        if (lst == null || lst.Count == 0)
            return 0;

        int sum = 0;
        foreach (var x in lst)
        {
            if (x is int i && i >= 0 && i % 2 != 0)
            {
                sum += i * i;
            }
        }
        return sum;
    }
}
}
