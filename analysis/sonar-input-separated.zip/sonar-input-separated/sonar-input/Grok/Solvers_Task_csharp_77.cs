namespace Benchmarks.csharp_77.Grok
{
using System;

public class Solver
{
    public static string Solve(string s)
    {
        bool hasLetter = false;
        for (int i = 0; i < s.Length; i++)
        {
            if (char.IsLetter(s[i]))
            {
                hasLetter = true;
                break;
            }
        }

        if (!hasLetter)
        {
            char[] arr = s.ToCharArray();
            Array.Reverse(arr);
            return new string(arr);
        }

        char[] result = s.ToCharArray();
        for (int i = 0; i < result.Length; i++)
        {
            char c = result[i];
            if (char.IsLetter(c))
            {
                if (char.IsUpper(c))
                {
                    result[i] = char.ToLower(c);
                }
                else
                {
                    result[i] = char.ToUpper(c);
                }
            }
        }
        return new string(result);
    }
}
}
