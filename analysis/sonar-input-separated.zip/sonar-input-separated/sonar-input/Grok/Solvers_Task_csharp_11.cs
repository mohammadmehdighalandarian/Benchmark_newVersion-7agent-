namespace Benchmarks.csharp_11.Grok
{
using System;

public class Solver
{
    private static bool IsPrime(long num)
    {
        if (num <= 1) return false;
        if (num == 2) return true;
        if (num % 2 == 0) return false;
        for (long i = 3; i * i <= num; i += 2)
        {
            if (num % i == 0) return false;
        }
        return true;
    }

    public static int PrimeFib(int n)
    {
        int count = 0;
        long a = 0;
        long b = 1;
        while (true)
        {
            long fib = a + b;
            a = b;
            b = fib;
            if (IsPrime(fib))
            {
                count++;
                if (count == n) return (int)fib;
            }
        }
    }
}
}
