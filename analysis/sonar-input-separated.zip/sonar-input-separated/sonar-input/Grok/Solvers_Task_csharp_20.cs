namespace Benchmarks.csharp_20.Grok
{
    using System.Collections.Generic;

    public class Solver
    {
        public static bool SameChars(string s0, string s1)
        {
            var set0 = new HashSet<char>(s0);
            var set1 = new HashSet<char>(s1);
            return set0.SetEquals(set1);
        }
    }
}
