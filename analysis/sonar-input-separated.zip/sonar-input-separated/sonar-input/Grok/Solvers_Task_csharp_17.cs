namespace Benchmarks.csharp_17.Grok
{
using System.Text;

public class Solver
{
    public static string RemoveVowels(string text)
    {
        string vowels = "aeiouAEIOU";
        StringBuilder sb = new StringBuilder();
        foreach (char c in text)
        {
            if (!vowels.Contains(c))
            {
                sb.Append(c);
            }
        }
        return sb.ToString();
    }
}
}
