namespace Benchmarks.csharp_30.Grok
{
    using System.Collections.Generic;

    public class Solver
    {
        public static bool WillItFly(List<int> q, int w)
        {
            int sum = 0;
            for (int i = 0; i < q.Count; i++)
            {
                sum += q[i];
            }

            bool isBalanced = true;
            for (int i = 0; i < q.Count / 2; i++)
            {
                if (q[i] != q[q.Count - 1 - i])
                {
                    isBalanced = false;
                    break;
                }
            }

            return isBalanced && sum <= w;
        }
    }
}
