namespace Benchmarks.csharp_16.Grok
{
public class Solver
{
    public static bool IsPalindrome(string text)
    {
        int left = 0;
        int right = text.Length - 1;
        while (left < right)
        {
            if (text[left] != text[right])
            {
                return false;
            }
            left++;
            right--;
        }
        return true;
    }
}
}
