namespace Benchmarks.csharp_74.Grok
{
using System;

public class Solver
{
    public static bool CycpatternCheck(string a, string b)
    {
        if (b.Length == 0) return true;
        for (int i = 0; i < b.Length; i++)
        {
            string rot = b.Substring(i) + b.Substring(0, i);
            if (a.Contains(rot)) return true;
        }
        return false;
    }
}
}
