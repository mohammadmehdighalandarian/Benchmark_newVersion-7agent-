namespace Benchmarks.csharp_6.Grok
{
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<double> RescaleToUnit (List<double> numbers) 
    {
        double min = numbers.Min();
        double max = numbers.Max();
        return numbers.Select(x => (x - min) / (max - min)).ToList();
    }
}
}
