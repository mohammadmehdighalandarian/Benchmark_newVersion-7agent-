namespace Benchmarks.csharp_70.Grok
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<string> Bf(string planet1, string planet2)
    {
        string[] planets = { "Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune" };
        int idx1 = Array.IndexOf(planets, planet1);
        int idx2 = Array.IndexOf(planets, planet2);
        if (idx1 == -1 || idx2 == -1) return new List<string>();
        int start = Math.Min(idx1, idx2) + 1;
        int end = Math.Max(idx1, idx2);
        return planets.Skip(start).Take(end - start).ToList();
    }
}
}
