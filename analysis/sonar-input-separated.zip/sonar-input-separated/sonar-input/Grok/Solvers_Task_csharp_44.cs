namespace Benchmarks.csharp_44.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static List<string> WordsString(string s)
    {
        char[] delimiters = { ' ', ',' };
        string[] words = s.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
        return new List<string>(words);
    }
}
}
