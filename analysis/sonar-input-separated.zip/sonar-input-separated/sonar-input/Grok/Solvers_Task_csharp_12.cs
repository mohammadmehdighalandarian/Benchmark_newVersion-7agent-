namespace Benchmarks.csharp_12.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static bool TriplesSumToZero(List<int> l)
    {
        if (l.Count < 3) return false;
        
        int[] arr = l.ToArray();
        Array.Sort(arr);
        
        for (int i = 0; i < arr.Length - 2; i++)
        {
            int left = i + 1;
            int right = arr.Length - 1;
            
            while (left < right)
            {
                int sum = arr[i] + arr[left] + arr[right];
                
                if (sum == 0) return true;
                else if (sum < 0) left++;
                else right--;
            }
        }
        
        return false;
    }
}
}
