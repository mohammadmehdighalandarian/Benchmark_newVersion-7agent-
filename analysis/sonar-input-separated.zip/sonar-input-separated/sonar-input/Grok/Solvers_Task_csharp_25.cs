namespace Benchmarks.csharp_25.Grok
{
    using System;
    using System.Collections.Generic;

    public class Solver
    {
        public static List<int> Derivative(List<int> xs)
        {
            List<int> result = new List<int>();
            for (int i = 1; i < xs.Count; i++)
            {
                result.Add(i * xs[i]);
            }

            return result;
        }
    }
}
