namespace Benchmarks.csharp_50.Grok
{
using System;
using System.Collections.Generic;

public class Solver
{
    public static string Exchange(List<int> lst1, List<int> lst2)
    {
        int totalEvens = 0;
        foreach (int num in lst1)
        {
            if (num % 2 == 0) totalEvens++;
        }
        foreach (int num in lst2)
        {
            if (num % 2 == 0) totalEvens++;
        }
        return totalEvens >= lst1.Count ? "YES" : "NO";
    }
}
}
