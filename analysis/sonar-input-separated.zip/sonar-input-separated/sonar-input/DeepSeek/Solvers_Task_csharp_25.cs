namespace Benchmarks.csharp_25.DeepSeek
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static List<int> Derivative(List<int> xs)
        {
            if (xs == null || xs.Count <= 1)
                return new List<int>();

            List<int> derivative = new List<int>();

            for (int i = 1; i < xs.Count; i++)
            {
                derivative.Add(xs[i] * i);
            }

            return derivative;
        }
    }
}
