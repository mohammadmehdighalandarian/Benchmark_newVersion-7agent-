namespace Benchmarks.csharp_76.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool RightAngleTriangle(int a, int b, int c)
    {
        int[] sides = { a, b, c };
        Array.Sort(sides);
        return Math.Pow(sides[0], 2) + Math.Pow(sides[1], 2) == Math.Pow(sides[2], 2);
    }
}
}
