namespace Benchmarks.csharp_39.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static int IsBored(string S)
    {
        if (string.IsNullOrWhiteSpace(S))
            return 0;
            
        string[] sentences = Regex.Split(S, @"(?<=[.!?])\s+");
        int count = 0;
        
        foreach (string sentence in sentences)
        {
            string trimmed = sentence.TrimStart();
            if (trimmed.StartsWith("I ", StringComparison.OrdinalIgnoreCase) ||
                trimmed.Equals("I", StringComparison.OrdinalIgnoreCase) ||
                (trimmed.Length >= 2 && trimmed[0] == 'I' && (trimmed[1] == ' ' || trimmed[1] == '\'')))
            {
                count++;
            }
        }
        
        return count;
    }
}
}
