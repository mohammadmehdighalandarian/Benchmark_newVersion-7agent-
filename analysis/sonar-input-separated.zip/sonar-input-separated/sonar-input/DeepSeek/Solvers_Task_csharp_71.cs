namespace Benchmarks.csharp_71.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static int XOrY(int n, int x, int y)
    {
        if (IsPrime(n))
        {
            return x;
        }
        else
        {
            return y;
        }
    }
    
    private static bool IsPrime(int n)
    {
        if (n <= 1) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;
        
        int boundary = (int)Math.Sqrt(n);
        for (int i = 3; i <= boundary; i += 2)
        {
            if (n % i == 0) return false;
        }
        return true;
    }
}
}
