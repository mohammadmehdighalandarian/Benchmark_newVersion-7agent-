namespace Benchmarks.csharp_70.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<string> Bf(string planet1, string planet2)
    {
        string[] planets = { "Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune" };
        
        int index1 = Array.IndexOf(planets, planet1);
        int index2 = Array.IndexOf(planets, planet2);
        
        if (index1 == -1 || index2 == -1)
        {
            return new List<string>();
        }
        
        int start = Math.Min(index1, index2);
        int end = Math.Max(index1, index2);
        
        List<string> result = new List<string>();
        for (int i = start + 1; i < end; i++)
        {
            result.Add(planets[i]);
        }
        
        return result;
    }
}
}
