﻿namespace Benchmarks.csharp_46.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
public class Solver
{
    public static object RoundedAvg(int n, int m)
    {
        if (n > m)
        {
            return -1;
        }
        
        long sum = 0;
        for (int i = n; i <= m; i++)
        {
            sum += i;
        }
        
        double average = (double)sum / (m - n + 1);
        int rounded = (int)Math.Round(average, MidpointRounding.AwayFromZero);
        
        return "0b" + Convert.ToString(rounded, 2);
    }
}
}

