namespace Benchmarks.csharp_41.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool CheckDictCase(Dictionary<object, string> dict)
    {
        if (dict == null || dict.Count == 0)
            return false;
        
        bool allLower = true;
        bool allUpper = true;
        
        foreach (var key in dict.Keys)
        {
            if (!(key is string))
                return false;
            
            string keyStr = (string)key;
            
            if (keyStr.Any(c => char.IsLetter(c) && !char.IsLower(c)))
                allLower = false;
            
            if (keyStr.Any(c => char.IsLetter(c) && !char.IsUpper(c)))
                allUpper = false;
            
            if (!allLower && !allUpper)
                return false;
        }
        
        return allLower || allUpper;
    }
}
}
