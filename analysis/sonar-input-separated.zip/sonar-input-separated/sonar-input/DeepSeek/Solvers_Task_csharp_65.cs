namespace Benchmarks.csharp_65.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static string WordsInSentence(string sentence)
    {
        if (string.IsNullOrWhiteSpace(sentence))
            return string.Empty;
        
        string[] words = sentence.Split(' ');
        List<string> resultWords = new List<string>();
        
        foreach (string word in words)
        {
            int length = word.Length;
            if (IsPrime(length))
            {
                resultWords.Add(word);
            }
        }
        
        return string.Join(" ", resultWords);
    }
    
    private static bool IsPrime(int number)
    {
        if (number <= 1)
            return false;
        if (number == 2)
            return true;
        if (number % 2 == 0)
            return false;
        
        int boundary = (int)Math.Sqrt(number);
        for (int i = 3; i <= boundary; i += 2)
        {
            if (number % i == 0)
                return false;
        }
        return true;
    }
}
}
