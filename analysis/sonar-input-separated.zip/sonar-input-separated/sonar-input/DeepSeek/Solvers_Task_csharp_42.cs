namespace Benchmarks.csharp_42.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static int ClosestInteger(string value)
    {
        double number = double.Parse(value);
        
        if (Math.Abs(number - Math.Floor(number) - 0.5) < 1e-10 ||
            Math.Abs(number - Math.Ceiling(number) + 0.5) < 1e-10)
        {
            return (int)(number > 0 ? Math.Ceiling(number) : Math.Floor(number));
        }
        
        return (int)Math.Round(number, MidpointRounding.AwayFromZero);
    }
}
}
