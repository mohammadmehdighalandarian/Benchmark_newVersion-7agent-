namespace Benchmarks.csharp_0.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool BelowZero(List<int> operations)
    {
        int balance = 0;
        
        foreach (int operation in operations)
        {
            balance += operation;
            
            if (balance < 0)
            {
                return true;
            }
        }
        
        return false;
    }
}
}
