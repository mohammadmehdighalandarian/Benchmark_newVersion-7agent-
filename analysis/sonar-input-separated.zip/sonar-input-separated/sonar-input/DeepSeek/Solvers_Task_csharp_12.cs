namespace Benchmarks.csharp_12.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool TriplesSumToZero(List<int> l)
    {
        if (l == null || l.Count < 3)
            return false;
        
        l.Sort();
        int n = l.Count;
        
        for (int i = 0; i < n - 2; i++)
        {
            if (i > 0 && l[i] == l[i - 1])
                continue;
                
            int left = i + 1;
            int right = n - 1;
            
            while (left < right)
            {
                int sum = l[i] + l[left] + l[right];
                
                if (sum == 0)
                    return true;
                else if (sum < 0)
                    left++;
                else
                    right--;
            }
        }
        
        return false;
    }
}
}
