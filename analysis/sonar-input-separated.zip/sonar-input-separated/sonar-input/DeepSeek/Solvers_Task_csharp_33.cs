namespace Benchmarks.csharp_33.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static bool IsHappy(string s)
    {
        if (s.Length < 3)
        {
            return false;
        }
        
        for (int i = 0; i <= s.Length - 3; i++)
        {
            if (s[i] == s[i + 1] || s[i] == s[i + 2] || s[i + 1] == s[i + 2])
            {
                return false;
            }
        }
        
        return true;
    }
}
}
