namespace Benchmarks.csharp_37.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<List<int>> GetRow(List<List<int>> lst, int x)
    {
        var result = new List<List<int>>();
        
        for (int row = 0; row < lst.Count; row++)
        {
            var columns = new List<int>();
            for (int col = 0; col < lst[row].Count; col++)
            {
                if (lst[row][col] == x)
                {
                    columns.Add(col);
                }
            }
            
            // Sort columns in descending order
            columns.Sort((a, b) => b.CompareTo(a));
            
            foreach (var col in columns)
            {
                result.Add(new List<int> { row, col });
            }
        }
        
        return result;
    }
}
}
