namespace Benchmarks.csharp_73.DeepSeek
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static string StrongestExtension(string class_name, List<string> extensions)
        {
            string strongestExtension = null;
            int maxStrength = int.MinValue;

            foreach (string extension in extensions)
            {
                int cap = extension.Count(c => char.IsUpper(c));
                int sm = extension.Count(c => char.IsLower(c));
                int strength = cap - sm;

                if (strength > maxStrength)
                {
                    maxStrength = strength;
                    strongestExtension = extension;
                }
            }

            return $"{class_name}.{strongestExtension}";
        }
    }
}
