namespace Benchmarks.csharp_69.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int GetMaxTriples(int n)
    {
        if (n < 3) return 0;
        
        // Count numbers with remainder 0, 1, 2 when divided by 3
        int[] remainderCount = new int[3];
        
        for (int i = 1; i <= n; i++)
        {
            long value = (long)i * i - i + 1;
            int remainder = (int)(value % 3);
            remainderCount[remainder]++;
        }
        
        int result = 0;
        
        // All three numbers have remainder 0
        if (remainderCount[0] >= 3)
        {
            result += remainderCount[0] * (remainderCount[0] - 1) * (remainderCount[0] - 2) / 6;
        }
        
        // All three numbers have remainder 1
        if (remainderCount[1] >= 3)
        {
            result += remainderCount[1] * (remainderCount[1] - 1) * (remainderCount[1] - 2) / 6;
        }
        
        // All three numbers have remainder 2
        if (remainderCount[2] >= 3)
        {
            result += remainderCount[2] * (remainderCount[2] - 1) * (remainderCount[2] - 2) / 6;
        }
        
        // One from each remainder (0, 1, 2)
        result += remainderCount[0] * remainderCount[1] * remainderCount[2];
        
        return result;
    }
}
}
