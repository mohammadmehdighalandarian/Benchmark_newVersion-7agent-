namespace Benchmarks.csharp_60.DeepSeek
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static int SumSquares(List<object> lst)
        {
            int sum = 0;
            foreach (object item in lst)
            {
                double number = Convert.ToDouble(item);
                int ceiling = (int)Math.Ceiling(number);
                sum += ceiling * ceiling;
            }

            return sum;
        }
    }
}
