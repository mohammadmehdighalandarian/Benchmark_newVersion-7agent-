namespace Benchmarks.csharp_57.DeepSeek
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static List<object> Tri(int n)
        {
            List<object> result = new List<object>();

            if (n < 0) return result;

            // We need to compute values up to n
            // Since the recurrence for odd n uses n+1, we may need up to n+1
            Dictionary<int, long> memo = new Dictionary<int, long>();

            for (int i = 0; i <= n; i++)
            {
                result.Add(ComputeTri(i, memo));
            }

            return result;
        }

        private static long ComputeTri(int n, Dictionary<int, long> memo)
        {
            if (memo.ContainsKey(n))
                return memo[n];

            long result;

            if (n == 0)
            {
                result = 1;
            }
            else if (n == 1)
            {
                result = 3;
            }
            else if (n % 2 == 0)
            {
                result = 1 + n / 2;
            }
            else // n is odd and n > 1
            {
                // For odd n, we need Tri(n-1), Tri(n-2), and Tri(n+1)
                // This creates a dependency on higher values, so we compute recursively
                long tn1 = ComputeTri(n - 1, memo);
                long tn2 = ComputeTri(n - 2, memo);
                long tnp1 = ComputeTri(n + 1, memo);
                result = tn1 + tn2 + tnp1;
            }

            memo[n] = result;
            return result;
        }
    }
}
