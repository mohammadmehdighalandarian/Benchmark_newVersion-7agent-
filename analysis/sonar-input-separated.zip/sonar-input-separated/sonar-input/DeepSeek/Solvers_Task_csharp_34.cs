namespace Benchmarks.csharp_34.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<string> NumericalLetterGrade(List<object> grades)
    {
        List<string> result = new List<string>();
        
        foreach (object gradeObj in grades)
        {
            double gpa = Convert.ToDouble(gradeObj);
            string letterGrade = "";
            
            if (gpa == 4.0)
                letterGrade = "A+";
            else if (gpa > 3.7)
                letterGrade = "A";
            else if (gpa > 3.3)
                letterGrade = "A-";
            else if (gpa > 3.0)
                letterGrade = "B+";
            else if (gpa > 2.7)
                letterGrade = "B";
            else if (gpa > 2.3)
                letterGrade = "B-";
            else if (gpa > 2.0)
                letterGrade = "C+";
            else if (gpa > 1.7)
                letterGrade = "C";
            else if (gpa > 1.3)
                letterGrade = "C-";
            else if (gpa > 1.0)
                letterGrade = "D+";
            else if (gpa > 0.7)
                letterGrade = "D";
            else if (gpa > 0.0)
                letterGrade = "D-";
            else if (gpa == 0.0)
                letterGrade = "E";
            
            result.Add(letterGrade);
        }
        
        return result;
    }
}
}
