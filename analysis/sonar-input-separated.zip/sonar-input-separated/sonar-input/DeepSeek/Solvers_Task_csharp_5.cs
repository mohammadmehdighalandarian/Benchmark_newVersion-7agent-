namespace Benchmarks.csharp_5.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static string SortNumbers(string numbers)
    {
        if (string.IsNullOrWhiteSpace(numbers))
            return string.Empty;
        
        var numberWords = new List<string> { "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
        
        var inputNumbers = numbers.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
        
        var sortedNumbers = inputNumbers
            .OrderBy(w => numberWords.IndexOf(w))
            .ToArray();
        
        return string.Join(" ", sortedNumbers);
    }
}
}
