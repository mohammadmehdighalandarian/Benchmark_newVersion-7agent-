namespace Benchmarks.csharp_8.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> GetPositive(List<int> l)
    {
        return l.Where(x => x > 0).ToList();
    }
}
}
