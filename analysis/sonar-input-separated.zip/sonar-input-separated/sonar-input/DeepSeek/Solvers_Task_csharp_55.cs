namespace Benchmarks.csharp_55.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int AddElements(List<int> arr, int k)
    {
        int sum = 0;
        for (int i = 0; i < k; i++)
        {
            int num = arr[i];
            if (Math.Abs(num) < 100 && Math.Abs(num) > -100)
            {
                sum += num;
            }
        }
        return sum;
    }
}
}
