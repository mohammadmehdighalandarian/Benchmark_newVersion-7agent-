namespace Benchmarks.csharp_61.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static bool CheckIfLastCharIsALetter(string txt)
    {
        if (string.IsNullOrEmpty(txt))
            return false;
        
        char lastChar = txt[txt.Length - 1];
        
        if (!char.IsLetter(lastChar))
            return false;
        
        string[] words = txt.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        
        if (words.Length == 0)
            return false;
        
        string lastWord = words[words.Length - 1];
        
        return lastWord.Length == 1 && char.IsLetter(lastWord[0]);
    }
}
}
