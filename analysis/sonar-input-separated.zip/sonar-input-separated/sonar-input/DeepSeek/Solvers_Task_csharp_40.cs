namespace Benchmarks.csharp_40.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int Skjkasdkd(List<int> lst)
    {
        int largestPrime = 0;
        
        foreach (int num in lst)
        {
            if (IsPrime(num) && num > largestPrime)
            {
                largestPrime = num;
            }
        }
        
        return SumOfDigits(largestPrime);
    }
    
    private static bool IsPrime(int n)
    {
        if (n <= 1) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;
        
        for (int i = 3; i <= Math.Sqrt(n); i += 2)
        {
            if (n % i == 0) return false;
        }
        
        return true;
    }
    
    private static int SumOfDigits(int n)
    {
        int sum = 0;
        n = Math.Abs(n);
        
        while (n > 0)
        {
            sum += n % 10;
            n /= 10;
        }
        
        return sum;
    }
}
}
