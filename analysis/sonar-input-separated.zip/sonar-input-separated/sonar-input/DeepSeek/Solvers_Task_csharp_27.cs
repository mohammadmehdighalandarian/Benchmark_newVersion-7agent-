namespace Benchmarks.csharp_27.DeepSeek
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text.RegularExpressions;

    public class Solver
    {
        public static int VowelsCount(string s)
        {
            if (string.IsNullOrEmpty(s))
                return 0;

            int count = 0;
            string vowels = "aeiouAEIOU";

            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (vowels.Contains(c))
                {
                    count++;
                }
                else if (i == s.Length - 1 && (c == 'y' || c == 'Y'))
                {
                    count++;
                }
            }

            return count;
        }
    }
}
