namespace Benchmarks.csharp_23.DeepSeek
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text.RegularExpressions;

    public class Solver
    {
        public static int LargestPrimeFactor(int n)
        {
            int largest = 1;

            // Handle factor 2
            while (n % 2 == 0)
            {
                largest = 2;
                n /= 2;
            }

            // Handle odd factors
            for (int i = 3; i <= Math.Sqrt(n); i += 2)
            {
                while (n % i == 0)
                {
                    largest = i;
                    n /= i;
                }
            }

            // If remaining n is greater than 1, it's a prime factor
            if (n > 1)
            {
                largest = n;
            }

            return largest;
        }
    }
}
