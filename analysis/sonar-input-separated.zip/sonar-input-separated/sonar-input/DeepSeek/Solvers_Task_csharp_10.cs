namespace Benchmarks.csharp_10.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> Unique(List<int> l)
    {
        if (l == null)
            return new List<int>();
        
        return l.Distinct().OrderBy(x => x).ToList();
    }
}
}
