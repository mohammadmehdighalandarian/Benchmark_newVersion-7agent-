namespace Benchmarks.csharp_72.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int DoubleTheDifference(List<object> lst)
    {
        if (lst == null || lst.Count == 0)
            return 0;
        
        int sum = 0;
        
        foreach (object item in lst)
        {
            if (item is int num && num > 0 && num % 2 != 0)
            {
                sum += num * num;
            }
        }
        
        return sum;
    }
}
}
