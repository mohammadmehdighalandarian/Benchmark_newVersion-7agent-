namespace Benchmarks.csharp_45.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static int ChooseNum(int x, int y)
    {
        if (x > y)
        {
            return -1;
        }
        
        int biggestEven = y % 2 == 0 ? y : y - 1;
        
        if (biggestEven >= x)
        {
            return biggestEven;
        }
        
        return -1;
    }
}
}
