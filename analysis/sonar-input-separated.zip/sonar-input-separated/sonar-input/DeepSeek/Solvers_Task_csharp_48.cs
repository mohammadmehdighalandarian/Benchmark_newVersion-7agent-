namespace Benchmarks.csharp_48.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> EvenOddPalindrome(int n)
    {
        int evenCount = 0;
        int oddCount = 0;
        
        for (int i = 1; i <= n; i++)
        {
            if (IsPalindrome(i))
            {
                if (i % 2 == 0)
                    evenCount++;
                else
                    oddCount++;
            }
        }
        
        return new List<int> { evenCount, oddCount };
    }
    
    private static bool IsPalindrome(int num)
    {
        string str = num.ToString();
        int left = 0;
        int right = str.Length - 1;
        
        while (left < right)
        {
            if (str[left] != str[right])
                return false;
            left++;
            right--;
        }
        
        return true;
    }
}
}
