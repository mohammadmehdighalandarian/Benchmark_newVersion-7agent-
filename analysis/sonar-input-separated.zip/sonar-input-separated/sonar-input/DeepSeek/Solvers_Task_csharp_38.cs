namespace Benchmarks.csharp_38.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static object NextSmallest(List<int> lst)
    {
        if (lst == null || lst.Count < 2)
        {
            return null;
        }
        
        var distinctSorted = lst.Distinct().OrderBy(x => x).ToList();
        
        if (distinctSorted.Count < 2)
        {
            return null;
        }
        
        return distinctSorted[1];
    }
}
}
