namespace Benchmarks.csharp_24.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static int SumToN(int n)
    {
        return n * (n + 1) / 2;
    }
}
}
