namespace Benchmarks.csharp_17.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static string RemoveVowels(string text)
    {
        if (string.IsNullOrEmpty(text))
            return text;
        
        var vowels = new HashSet<char>(new[] { 'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U' });
        return new string(text.Where(c => !vowels.Contains(c)).ToArray());
    }
}
}
