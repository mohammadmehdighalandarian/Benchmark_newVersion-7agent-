namespace Benchmarks.csharp_36.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static string Solve(int N)
    {
        int sumOfDigits = 0;
        int temp = N;
        
        while (temp > 0)
        {
            sumOfDigits += temp % 10;
            temp /= 10;
        }
        
        return Convert.ToString(sumOfDigits, 2);
    }
}
}
