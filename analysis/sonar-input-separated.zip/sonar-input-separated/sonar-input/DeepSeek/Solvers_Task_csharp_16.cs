namespace Benchmarks.csharp_16.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static bool IsPalindrome(string text)
    {
        if (string.IsNullOrEmpty(text))
            return true;
        
        int left = 0;
        int right = text.Length - 1;
        
        while (left < right)
        {
            if (text[left] != text[right])
                return false;
            left++;
            right--;
        }
        
        return true;
    }
}
}
