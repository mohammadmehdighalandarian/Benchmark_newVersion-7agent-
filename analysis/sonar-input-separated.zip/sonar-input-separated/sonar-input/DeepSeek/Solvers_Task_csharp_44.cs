namespace Benchmarks.csharp_44.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<string> WordsString(string s)
    {
        if (string.IsNullOrWhiteSpace(s))
            return new List<string>();
        
        // Split by commas or spaces, ignoring empty entries
        string[] separators = { ",", " " };
        return s.Split(separators, StringSplitOptions.RemoveEmptyEntries)
                .Select(word => word.Trim())
                .Where(word => !string.IsNullOrEmpty(word))
                .ToList();
    }
}
}
