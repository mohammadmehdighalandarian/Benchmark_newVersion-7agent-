namespace Benchmarks.csharp_32.DeepSeek
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text.RegularExpressions;

    public class Solver
    {
        public static string DecimalToBinary(int decimalNumber)
        {
            if (decimalNumber == 0)
            {
                return "db0db";
            }

            string binary = Convert.ToString(decimalNumber, 2);
            return "db" + binary + "db";
        }
    }
}
