namespace Benchmarks.csharp_28.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int Search(List<int> lst)
    {
        var frequency = new Dictionary<int, int>();
        
        foreach (int num in lst)
        {
            if (frequency.ContainsKey(num))
                frequency[num]++;
            else
                frequency[num] = 1;
        }
        
        int result = -1;
        
        foreach (var kvp in frequency)
        {
            if (kvp.Key > 0 && kvp.Value >= kvp.Key)
            {
                if (kvp.Key > result)
                    result = kvp.Key;
            }
        }
        
        return result;
    }
}
}
