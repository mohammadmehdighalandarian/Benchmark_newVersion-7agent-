namespace Benchmarks.csharp_1.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> SumProduct(List<int> numbers)
    {
        int sum = 0;
        int product = 1;
        
        if (numbers == null || numbers.Count == 0)
        {
            return new List<int> { sum, product };
        }
        
        sum = numbers.Sum();
        product = numbers.Aggregate(1, (acc, val) => acc * val);
        
        return new List<int> { sum, product };
    }
}
}
