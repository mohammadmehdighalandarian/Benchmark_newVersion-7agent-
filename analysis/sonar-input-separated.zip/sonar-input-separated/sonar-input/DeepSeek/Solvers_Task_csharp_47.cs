namespace Benchmarks.csharp_47.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> F(int n)
    {
        List<int> result = new List<int>();
        
        for (int i = 1; i <= n; i++)
        {
            if (i % 2 == 0)
            {
                // Even index: factorial of i
                int factorial = 1;
                for (int j = 1; j <= i; j++)
                {
                    factorial *= j;
                }
                result.Add(factorial);
            }
            else
            {
                // Odd index: sum from 1 to i
                int sum = i * (i + 1) / 2;
                result.Add(sum);
            }
        }
        
        return result;
    }
}
}
