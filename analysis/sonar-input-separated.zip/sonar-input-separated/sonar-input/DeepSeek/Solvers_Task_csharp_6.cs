namespace Benchmarks.csharp_6.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<double> RescaleToUnit(List<double> numbers)
    {
        if (numbers == null || numbers.Count < 2)
            throw new ArgumentException("List must contain at least two elements");
        
        double min = numbers.Min();
        double max = numbers.Max();
        double range = max - min;
        
        if (range == 0)
            return numbers.Select(x => 0.5).ToList();
        
        return numbers.Select(x => (x - min) / range).ToList();
    }
}
}
