namespace Benchmarks.csharp_18.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool BelowThreshold(List<int> l, int t)
    {
        return l.All(x => x < t);
    }
}
}
