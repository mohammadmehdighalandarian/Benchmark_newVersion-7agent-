namespace Benchmarks.csharp_63.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<object> LargestSmallestIntegers(List<int> lst)
    {
        object a = null;
        object b = null;
        
        var negatives = lst.Where(x => x < 0).ToList();
        var positives = lst.Where(x => x > 0).ToList();
        
        if (negatives.Any())
        {
            a = negatives.Max();
        }
        
        if (positives.Any())
        {
            b = positives.Min();
        }
        
        return new List<object> { a, b };
    }
}
}
