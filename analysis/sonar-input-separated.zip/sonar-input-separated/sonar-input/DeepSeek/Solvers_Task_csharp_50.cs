namespace Benchmarks.csharp_50.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static string Exchange(List<int> lst1, List<int> lst2)
    {
        int oddCountInLst1 = lst1.Count(x => x % 2 != 0);
        int evenCountInLst2 = lst2.Count(x => x % 2 == 0);
        
        if (oddCountInLst1 <= evenCountInLst2)
        {
            return "YES";
        }
        else
        {
            return "NO";
        }
    }
}
}
