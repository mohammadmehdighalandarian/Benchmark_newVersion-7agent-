namespace Benchmarks.csharp_79.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> GenerateIntegers(int a, int b)
    {
        int start = Math.Min(a, b);
        int end = Math.Max(a, b);
        
        List<int> result = new List<int>();
        
        for (int i = start; i <= end; i++)
        {
            if (i % 2 == 0)
            {
                result.Add(i);
            }
        }
        
        return result;
    }
}
}
