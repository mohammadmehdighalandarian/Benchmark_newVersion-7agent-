namespace Benchmarks.csharp_68.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static int SpecialFilter(List<int> nums)
    {
        int count = 0;
        
        foreach (int num in nums)
        {
            if (num > 10)
            {
                int absNum = Math.Abs(num);
                string numStr = absNum.ToString();
                
                char firstDigit = numStr[0];
                char lastDigit = numStr[numStr.Length - 1];
                
                bool firstOdd = (firstDigit - '0') % 2 == 1;
                bool lastOdd = (lastDigit - '0') % 2 == 1;
                
                if (firstOdd && lastOdd)
                {
                    count++;
                }
            }
        }
        
        return count;
    }
}
}
