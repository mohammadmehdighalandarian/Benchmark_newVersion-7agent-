namespace Benchmarks.csharp_59.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool IsNested(string string0)
    {
        int depth = 0;
        bool hasNested = false;
        
        foreach (char c in string0)
        {
            if (c == '[')
            {
                depth++;
            }
            else if (c == ']')
            {
                if (depth > 0)
                {
                    depth--;
                    if (depth > 0)
                    {
                        hasNested = true;
                    }
                }
            }
        }
        
        return hasNested;
    }
}
}
