namespace Benchmarks.csharp_26.DeepSeek
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text.RegularExpressions;

    public class Solver
    {
        public static int Fibfib(int n)
        {
            if (n == 0 || n == 1)
                return 0;
            if (n == 2)
                return 1;

            int a = 0, b = 0, c = 1;
            int result = 0;

            for (int i = 3; i <= n; i++)
            {
                result = a + b + c;
                a = b;
                b = c;
                c = result;
            }

            return result;
        }
    }
}
