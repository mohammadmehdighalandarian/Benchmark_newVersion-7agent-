namespace Benchmarks.csharp_35.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static bool PrimeLength(string string0)
    {
        int length = string0.Length;
        
        if (length <= 1)
            return false;
        
        for (int i = 2; i <= Math.Sqrt(length); i++)
        {
            if (length % i == 0)
                return false;
        }
        
        return true;
    }
}
}
