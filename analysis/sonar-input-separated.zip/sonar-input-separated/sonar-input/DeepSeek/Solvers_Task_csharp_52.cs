namespace Benchmarks.csharp_52.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int MaxFill(List<List<int>> grid, int capacity)
    {
        int totalWater = 0;
        
        foreach (var row in grid)
        {
            totalWater += row.Sum();
        }
        
        if (totalWater == 0)
        {
            return 0;
        }
        
        return (int)Math.Ceiling((double)totalWater / capacity);
    }
}
}
