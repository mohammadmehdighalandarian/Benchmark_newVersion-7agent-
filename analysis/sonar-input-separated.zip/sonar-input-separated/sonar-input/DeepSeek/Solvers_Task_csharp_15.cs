namespace Benchmarks.csharp_15.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static object Median(List<int> l)
    {
        if (l == null || l.Count == 0)
            throw new ArgumentException("List cannot be null or empty");
        
        var sorted = l.OrderBy(x => x).ToList();
        int count = sorted.Count;
        
        if (count % 2 == 1)
        {
            return sorted[count / 2];
        }
        else
        {
            return (sorted[count / 2 - 1] + sorted[count / 2]) / 2.0;
        }
    }
}
}
