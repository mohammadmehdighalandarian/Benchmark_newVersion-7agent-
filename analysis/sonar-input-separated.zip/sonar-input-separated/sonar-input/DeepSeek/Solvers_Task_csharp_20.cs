namespace Benchmarks.csharp_20.DeepSeek
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static bool SameChars(string s0, string s1)
        {
            if (s0 == null || s1 == null)
                return false;

            var set0 = new HashSet<char>(s0);
            var set1 = new HashSet<char>(s1);

            return set0.SetEquals(set1);
        }
    }
}
