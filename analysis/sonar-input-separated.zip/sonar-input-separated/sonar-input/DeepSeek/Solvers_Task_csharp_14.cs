namespace Benchmarks.csharp_14.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static int Fib4(int n)
    {
        if (n == 0 || n == 1) return 0;
        if (n == 2) return 2;
        if (n == 3) return 0;
        
        int a = 0; // Fib4(0)
        int b = 0; // Fib4(1)
        int c = 2; // Fib4(2)
        int d = 0; // Fib4(3)
        int result = 0;
        
        for (int i = 4; i <= n; i++)
        {
            result = a + b + c + d;
            a = b;
            b = c;
            c = d;
            d = result;
        }
        
        return result;
    }
}
}
