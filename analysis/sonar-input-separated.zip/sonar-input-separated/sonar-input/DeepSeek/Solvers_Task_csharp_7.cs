namespace Benchmarks.csharp_7.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static string FlipCase(string string0)
    {
        if (string0 == null)
            return null;
        
        char[] result = new char[string0.Length];
        
        for (int i = 0; i < string0.Length; i++)
        {
            char c = string0[i];
            if (char.IsLower(c))
                result[i] = char.ToUpper(c);
            else if (char.IsUpper(c))
                result[i] = char.ToLower(c);
            else
                result[i] = c;
        }
        
        return new string(result);
    }
}
}
