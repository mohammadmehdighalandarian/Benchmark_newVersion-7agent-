namespace Benchmarks.csharp_30.DeepSeek
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static bool WillItFly(List<int> q, int w)
        {
            // Check if the list is a palindrome
            bool isPalindrome = true;
            for (int i = 0; i < q.Count / 2; i++)
            {
                if (q[i] != q[q.Count - 1 - i])
                {
                    isPalindrome = false;
                    break;
                }
            }

            // Check if the sum is less than or equal to w
            int sum = q.Sum();

            // Return true if both conditions are met
            return isPalindrome && sum <= w;
        }
    }
}
