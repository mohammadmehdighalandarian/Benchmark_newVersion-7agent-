namespace Benchmarks.csharp_49.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool MoveOneBall(List<int> arr)
    {
        if (arr == null || arr.Count == 0)
            return true;
        
        int n = arr.Count;
        int dropCount = 0;
        
        for (int i = 0; i < n; i++)
        {
            if (arr[i] > arr[(i + 1) % n])
                dropCount++;
        }
        
        return dropCount <= 1;
    }
}
}
