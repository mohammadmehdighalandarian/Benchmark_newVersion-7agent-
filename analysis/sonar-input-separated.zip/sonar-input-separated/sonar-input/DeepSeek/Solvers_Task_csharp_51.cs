namespace Benchmarks.csharp_51.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<object> ReverseDelete(string s, string c)
    {
        HashSet<char> charsToDelete = new HashSet<char>(c);
        string result = new string(s.Where(ch => !charsToDelete.Contains(ch)).ToArray());
        
        bool isPalindrome = IsPalindrome(result);
        
        return new List<object> { result, isPalindrome };
    }
    
    private static bool IsPalindrome(string str)
    {
        if (string.IsNullOrEmpty(str))
            return true;
            
        int left = 0;
        int right = str.Length - 1;
        
        while (left < right)
        {
            if (str[left] != str[right])
                return false;
            left++;
            right--;
        }
        
        return true;
    }
}
}
