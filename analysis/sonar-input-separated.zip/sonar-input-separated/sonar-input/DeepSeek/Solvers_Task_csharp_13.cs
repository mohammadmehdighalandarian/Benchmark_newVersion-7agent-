namespace Benchmarks.csharp_13.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool PairsSumToZero(List<int> l)
    {
        HashSet<int> seen = new HashSet<int>();
        
        foreach (int num in l)
        {
            if (seen.Contains(-num))
            {
                return true;
            }
            seen.Add(num);
        }
        
        return false;
    }
}
}
