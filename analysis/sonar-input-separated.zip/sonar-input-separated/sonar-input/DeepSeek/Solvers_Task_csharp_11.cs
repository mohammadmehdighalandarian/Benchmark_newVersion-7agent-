namespace Benchmarks.csharp_11.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static int PrimeFib(int n)
    {
        if (n <= 0) return 0;
        
        List<int> primeFibNumbers = new List<int>();
        int a = 0, b = 1;
        
        while (primeFibNumbers.Count < n)
        {
            int next = a + b;
            a = b;
            b = next;
            
            if (IsPrime(next) && next > 1)
            {
                primeFibNumbers.Add(next);
            }
        }
        
        return primeFibNumbers[n - 1];
    }
    
    private static bool IsPrime(int number)
    {
        if (number <= 1) return false;
        if (number == 2) return true;
        if (number % 2 == 0) return false;
        
        int limit = (int)Math.Sqrt(number);
        for (int i = 3; i <= limit; i += 2)
        {
            if (number % i == 0) return false;
        }
        
        return true;
    }
}
}
