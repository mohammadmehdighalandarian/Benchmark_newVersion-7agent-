namespace Benchmarks.csharp_77.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static string Solve(string s)
    {
        bool hasLetter = s.Any(char.IsLetter);
        
        if (!hasLetter)
        {
            return new string(s.Reverse().ToArray());
        }
        
        char[] result = new char[s.Length];
        
        for (int i = 0; i < s.Length; i++)
        {
            char c = s[i];
            if (char.IsLetter(c))
            {
                if (char.IsLower(c))
                    result[i] = char.ToUpper(c);
                else
                    result[i] = char.ToLower(c);
            }
            else
            {
                result[i] = c;
            }
        }
        
        return new string(result);
    }
}
}
