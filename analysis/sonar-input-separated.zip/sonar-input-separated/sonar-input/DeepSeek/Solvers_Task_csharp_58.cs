namespace Benchmarks.csharp_58.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static int Digits(int n)
    {
        int product = 1;
        bool hasOdd = false;
        
        while (n > 0)
        {
            int digit = n % 10;
            if (digit % 2 != 0)
            {
                product *= digit;
                hasOdd = true;
            }
            n /= 10;
        }
        
        return hasOdd ? product : 0;
    }
}
}
