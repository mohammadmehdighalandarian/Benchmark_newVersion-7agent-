namespace Benchmarks.csharp_75.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static string IntToMiniRoman(int number)
    {
        string[] thousands = { "", "M", "MM", "MMM" };
        string[] hundreds = { "", "C", "CC", "CCC", "CD", "D", "DC", "DCC", "DCCC", "CM" };
        string[] tens = { "", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC" };
        string[] ones = { "", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX" };
        
        string result = thousands[number / 1000] +
                        hundreds[(number % 1000) / 100] +
                        tens[(number % 100) / 10] +
                        ones[number % 10];
        
        return result.ToLower();
    }
}
}
