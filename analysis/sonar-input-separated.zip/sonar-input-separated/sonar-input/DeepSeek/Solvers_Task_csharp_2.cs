namespace Benchmarks.csharp_2.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static string StringXor(string a, string b)
    {
        char[] result = new char[a.Length];
        for (int i = 0; i < a.Length; i++)
        {
            result[i] = a[i] == b[i] ? '0' : '1';
        }
        return new string(result);
    }
}
}
