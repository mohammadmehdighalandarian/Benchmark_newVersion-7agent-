namespace Benchmarks.csharp_53.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<string> SelectWords(string s, int n)
    {
        if (string.IsNullOrEmpty(s))
        {
            return new List<string>();
        }
        
        string[] words = s.Split(' ');
        List<string> result = new List<string>();
        
        foreach (string word in words)
        {
            int consonantCount = 0;
            foreach (char c in word.ToLower())
            {
                if (IsConsonant(c))
                {
                    consonantCount++;
                }
            }
            
            if (consonantCount == n)
            {
                result.Add(word);
            }
        }
        
        return result;
    }
    
    private static bool IsConsonant(char c)
    {
        return c >= 'a' && c <= 'z' && !IsVowel(c);
    }
    
    private static bool IsVowel(char c)
    {
        return c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u';
    }
}
}
