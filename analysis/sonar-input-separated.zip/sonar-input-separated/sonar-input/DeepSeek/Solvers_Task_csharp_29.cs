namespace Benchmarks.csharp_29.DeepSeek
{
using System;

public class Solver
{
    public static object TriangleArea(int a, int b, int c)
    {
        // Check if the three sides form a valid triangle
        if (a + b > c && a + c > b && b + c > a)
        {
            // Calculate semi-perimeter
            double s = (a + b + c) / 2.0;
            
            // Calculate area using Heron's formula
            double area = Math.Sqrt(s * (s - a) * (s - b) * (s - c));
            
            // Round to 2 decimal places
            return Math.Round(area, 2);
        }
        
        return -1;
    }
}
}
