namespace Benchmarks.csharp_31.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool IsMultiplyPrime(int a)
    {
        if (a <= 0) return false;
        
        List<int> primes = GetPrimesUpTo(100);
        
        for (int i = 0; i < primes.Count; i++)
        {
            for (int j = i; j < primes.Count; j++)
            {
                for (int k = j; k < primes.Count; k++)
                {
                    if (primes[i] * primes[j] * primes[k] == a)
                    {
                        return true;
                    }
                }
            }
        }
        
        return false;
    }
    
    private static List<int> GetPrimesUpTo(int limit)
    {
        List<int> primes = new List<int>();
        bool[] isComposite = new bool[limit + 1];
        
        for (int i = 2; i <= limit; i++)
        {
            if (!isComposite[i])
            {
                primes.Add(i);
                for (int j = i * i; j <= limit; j += i)
                {
                    isComposite[j] = true;
                }
            }
        }
        
        return primes;
    }
}
}
