namespace Benchmarks.csharp_67.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static List<int> OrderByPoints(List<int> nums)
    {
        if (nums == null || nums.Count == 0)
            return new List<int>();
        
        var indexedNums = nums.Select((num, index) => new { Value = num, Index = index }).ToList();
        
        var sorted = indexedNums
            .OrderBy(x => DigitSum(x.Value))
            .ThenBy(x => x.Index)
            .Select(x => x.Value)
            .ToList();
        
        return sorted;
    }
    
    private static int DigitSum(int n)
    {
        n = Math.Abs(n);
        int sum = 0;
        while (n > 0)
        {
            sum += n % 10;
            n /= 10;
        }
        return sum;
    }
}
}
