namespace Benchmarks.csharp_66.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

public class Solver
{
    public static bool Simplify(string x, string n)
    {
        string[] xParts = x.Split('/');
        string[] nParts = n.Split('/');
        
        int xNumerator = int.Parse(xParts[0]);
        int xDenominator = int.Parse(xParts[1]);
        int nNumerator = int.Parse(nParts[0]);
        int nDenominator = int.Parse(nParts[1]);
        
        int productNumerator = xNumerator * nNumerator;
        int productDenominator = xDenominator * nDenominator;
        
        return productNumerator % productDenominator == 0;
    }
}
}
