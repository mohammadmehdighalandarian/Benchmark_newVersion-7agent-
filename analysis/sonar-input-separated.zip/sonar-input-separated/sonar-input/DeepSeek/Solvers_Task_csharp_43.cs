namespace Benchmarks.csharp_43.DeepSeek
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public class Solver
    {
        public static List<int> MakeAPile(int n)
        {
            List<int> result = new List<int>();
            int current = n;

            for (int i = 0; i < n; i++)
            {
                result.Add(current);
                current += 2;
            }

            return result;
        }
    }
}
