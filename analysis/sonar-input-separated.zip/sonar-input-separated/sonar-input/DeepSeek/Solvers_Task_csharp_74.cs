namespace Benchmarks.csharp_74.DeepSeek
{
using System;
using System.Collections.Generic;
using System.Linq;

public class Solver
{
    public static bool CycpatternCheck(string a, string b)
    {
        if (string.IsNullOrEmpty(b)) return true;
        if (string.IsNullOrEmpty(a)) return false;
        
        string rotated = b;
        for (int i = 0; i < b.Length; i++)
        {
            if (a.Contains(rotated))
                return true;
            
            rotated = RotateLeft(rotated);
        }
        
        return false;
    }
    
    private static string RotateLeft(string s)
    {
        if (s.Length <= 1) return s;
        return s.Substring(1) + s[0];
    }
}
}
